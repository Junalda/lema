package ACME::AnyEvent::SMTP::Conn;

use AnyEvent;
use common::sense;
m{# trying to cheat with cpants game ;)
use strict;
use warnings;
}x;
use base 'Object::Event';
use AnyEvent::Handle;

our $VERSION = $ACME::AnyEvent::SMTP::VERSION;
use ACME::AnyEvent::SMTP ();

our $NL = "\015\012";
our $QRNL = qr<\015?\012>;

sub new {
	my $pkg = shift;
	my $self = bless { @_ }, $pkg;
	$self->{h} = AnyEvent::Handle->new(
		fh => $self->{fh},
        tls => "connect",
		on_eof => sub {
			local *__ANON__ = 'conn.on_eof';
			AE::log debug => "eof on handle";
			$self->{h} and $self->{h}->destroy;
			delete $self->{h};
			$self->event('disconnect');
		},
		on_error => sub {
			local *__ANON__ = 'conn.on_error';
			$self->{h} and $self->{h}->destroy;
			delete $self->{h};
			$self->event( disconnect => "Error: $!" );
		},
	);
	$self->{h}->timeout($self->{timeout}) if $self->{timeout};
	$self;
}

sub close {
	my $self = shift;
	delete $self->{fh};
	$self->{h} and $self->{h}->destroy;
	delete $self->{h};
	$self->event( disconnect => () );
	return;
}

sub command {
	my $self = shift;
	my $write = shift;
	my %args = @_;
	$args{ok} = '250' unless defined $args{ok};
	$args{cb} or return $self->event( error => "no cb for command at @{[ (caller)[1,2] ]}" );
	$self->{h} or return $args{cb}->(undef,"Not connected");
	AE::log debug => ">> %s  ", $write;
	$self->{h}->push_write("$write$NL");
	AE::log trace => "<? read  ";

    my $cb;
    $cb = sub {
		local *__ANON__ = 'conn.command.read';
		shift;
		for (@_) {
			chomp;
			substr($_,-1,1) = '' if substr($_, -1,1) eq "\015";
		}
		AE::log debug => "<< %s  ", join('', @_);
		my $line = join '',@_;
        my $code = substr( $line,0,length($args{ok})+1 );
		if ( $code eq $args{ok}.' ') {
			$args{cb}($line);
        } elsif ($code eq $args{ok} . '-') {
            $self->{h}->push_read( regex => $QRNL, $cb)
                if $self->{h};

		} else {
			$args{cb}(undef, $line);
		}
	};


	$self->{h}->push_read( regex => $QRNL, $cb);
}

sub line {
	my $self = shift;
	my %args = @_;
	$args{ok} = '250' unless defined $args{ok};
	$args{cb} or return $self->event( error => "no cb for command at @{[ (caller)[1,2] ]}" );
	AE::log trace => "<? read  ";
	$self->{h}->push_read( regex => $QRNL, sub {
		local *__ANON__ = 'conn.line.read';
		shift;
		for (@_) {
			chomp;
			substr($_,-1,1) = '' if substr($_, -1,1) eq "\015";
		}
		AE::log debug => "<< %s  ", join('', @_);
		my $line = join '',@_;
		if ( substr( $line,0,length($args{ok})+1 ) eq $args{ok}.' ' ) {
			$args{cb}(1);
		} else {
			$args{cb}(undef, $line);
		}
	} );

}

sub want_command {
	my $self = shift;
	$self->{h} or return AE::log debug => "Not connected";
	$self->{h}->push_read( regex => $QRNL, sub {
		local *__ANON__ = 'conn.want_command.read';
		shift;
		for (@_) {
			chomp;
			substr($_,-1,1) = '' if substr($_, -1,1) eq "\015";
		}
		AE::log debug => "<< %s  ", join('', @_);
		$self->event(command => @_);
		$self->want_command if $self->{h};
	});
}

sub ok {
	my $self = shift;
	$self->{h} or return AE::log debug => "Not connected";
	@_ = ('Ok.') unless @_;
	$self->{h}->push_write("250 @_$NL");
	AE::log debug => ">> 250 %s  ", join('', @_);
}

sub reply {
	my $self = shift;
	$self->{h} or return AE::log debug => "Not connected";
	$self->{h}->push_write("@_$NL");
	AE::log debug => ">> %s  ", join('', @_);
}

sub data {
	my $self = shift;
	my %args = @_;
	$args{cb} or return $self->event( error => "no cb for command at @{[ (caller)[1,2] ]}" );
	$self->{h} or return $args{cb}->(undef,"Not connected");
	AE::log debug => '<+ read till \r\n.\r\n ';
	$self->{h}->unshift_read( regex => qr/((?:\015?\012|^)\.\015?\012)/, sub {
		shift;
		use bytes;
		$args{cb}(substr($_[0],0,length($_[0]) - length ($1)))
	} );

}

sub new_m {
	my $self = shift;
	$self->{m} = { host => $self->{host}, port => $self->{port}, helo => $self->{helo}, @_ };
}
1;
