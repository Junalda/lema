package Woof::_Validator;
use strict;
use warnings;
use Data::Dumper;
use Safe::Isa;
use Woof::ISA::boolean;
use Woof::ISA::num;
use Woof::ISA::int;
use Woof::ISA::str;
use Woof::ISA::str_ne;
use Woof::ISA::strnull;
use Woof::ISA::float;
use Woof::ISA::HASH;
use Woof::ISA::ARRAY;

$Carp::Internal{'Woof::_Validator'} = 1;

sub validate {
    Carp::croak('Must be called in setter')
        unless $_->$_isa('Woof::_Member');

    return unless $_->is_type_defined;
    return if     $_->referent_is_isa;

    Carp::croak("No native type reference")
        unless $_->has_reference;

    local $_->{deref} = $_->deref;

    unless (defined $_->deref) {
        $_->deref = $_->is_building ? 1 : 0;
    }

    my $deargs = $_->deref;
    if ($_->is_inwoof) {
        $deargs = 1;
    }

    my $class = $_->{class};
    my $type  = $_->{type};
    my $str   = ref $_->referent;

    no strict 'refs';

    ${$class . '::ERRORS'} &&
        (local ${$type  . '::ERRORS'} = ${$class . '::ERRORS'});

    my @args = Woof::INWOOF();

    if (@args == 1 && $_->{type} eq ref $args[0]) {
        $_->referent = $args[0];
        return ();
    }

    if (@args == 1 && !defined $args[0] && $_->{undefok}) {
        $_->referent = undef;
        return ();
    }

    if ($_->{inwoof_cb}) {
        @args = $_->{inwoof_cb}->(@args);
    }
    elsif (!defined $type || !length $type) {
        Carp::croak("Type is not set, but it can be only scalar")
            if ref $args[0];
        Carp::croak("Type is not set, but number of args must be 1")
            if @args > 1;
        $_->referent = $args[0];
        return ();
    }
    elsif (exists &{$type . '::INWOOF'}) {
        @args = &{$type . '::INWOOF'}(@args);
    }

    if ($_->is_referent_unset) {
        unless ($deargs) {
            Carp::croak("Type `$str' is not ISA of `$_->{type}'" .
                        ($_->deref ? " or its construction value" : ""));
        }

        my @object = $type->new(@args);

        Carp::croak("Object builder returned more than one value")
            if @object > 1;

        unless (@object) {
            $_->{reference} = undef;
            die "Couldn't create object `$class'";
        }

        ${$_->reference} = $object[0];
    }
    ()
}

sub is_building {
    Carp::croak('Must be called in setter')
        unless $_->$_isa('Woof::_Member');

    !!($_->{flags} & Woof::FLAG_BUILDING());
}

1;
