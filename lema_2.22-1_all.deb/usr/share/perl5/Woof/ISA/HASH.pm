package Woof::ISA::Hash;
use strict;
use warnings;
use Carp;

sub HASH::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid hashref for `$_->{name}': ",
            join(',', map { $_ // '<undef>' } @args))
        unless @args == 1 && ref $args[0] eq 'HASH';

    $_->referent = $args[0];

    ()
}

sub HASH::OUTWOOF { $_[0] }

1;
