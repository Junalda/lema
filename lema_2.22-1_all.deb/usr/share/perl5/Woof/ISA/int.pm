package Woof::ISA::int;
use strict;
use warnings;
use Carp;

sub int::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid number for `$_->{name}': ",
            join(',', map { $_ // '<undef>' } @args))
        unless @args == 1 && defined $args[0] && $args[0] =~ /^-?\d+$/;

    $_->referent = int($args[0]);

    ()
}

sub int::OUTWOOF { $_[0] }

1;
