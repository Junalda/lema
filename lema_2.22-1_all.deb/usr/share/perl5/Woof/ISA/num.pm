package Woof::ISA::num;
use strict;
use warnings;
use Carp;

sub num::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid number for `$_->{name}': ",
            join(',', map { $_ // '<undef>' } @args))
        unless @args == 1 && defined $args[0] && $args[0] =~ /^-?\d+(\.\d+)?$/;

    $_->referent = $1
                 ? unpack("d", pack("d", $args[0]))
                 : int($args[0]);

    ()
}

sub num::OUTWOOF { $_[0] }

1;
