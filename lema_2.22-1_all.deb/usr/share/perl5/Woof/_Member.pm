package Woof::_Member;
use strict;
use warnings;
use Safe::Isa;

sub new {
    my ($class) = @_;

    my $self = {
        class      => undef,
        name       => undef,
        private    => 0,
        public     => 0,
        const      => 0,
        undefok    => 0,
        type       => undef,
        default    => \&Woof::NOTSET,

        orig_cb    => undef,
        woof_cb    => undef,
        inwoof_cb  => undef,
        outwoof_cb => undef,

        flags      => 0,
        deref      => undef,
        reference  => undef,
        refset     => undef,
    };

    bless $self, $class
}

sub copy {
    my $self = shift;
    my %copy = %$self;

    $copy{reference} = undef;
    bless \%copy, ref $self
}

sub const          { $_[0]->{const} }
sub deref : lvalue { $_[0]->{deref} }
sub flags : lvalue { $_[0]->{flags} }

sub is_building    { $_[0]->{flags} & Woof::FLAG_BUILDING() }
sub is_inwoof      { $_[0]->{flags} & Woof::FLAG_INWOOF()   }

sub referent : lvalue {
    ${$_[0]->{reference}}
}

sub unset_referent {
    ${$_->{reference}} = Woof::NOTSET();
    ()
}

sub is_referent_unset {
    !!(ref ${$_->{reference}} eq 'CODE' && ${$_->{reference}} eq Woof::NOTSET())
}

sub is_default_not_set {
    ref $_[0]{default} eq 'CODE' && $_[0]{default} eq \&Woof::NOTSET;
}

sub is_type_defined {
    defined $_[0]{type}
}

sub is_type_isa {
    return '' if !$_[0]->is_type_defined;
    1
}

sub has_reference {
    !!$_[0]->{reference}
}

sub reference { $_[0]->{reference} }

sub referent_is_isa {
    return '' unless $_[0]->has_reference;
    return '' unless $_[0]->is_type_isa;

    ${$_[0]->{reference}}->$_isa($_[0]->{type})
}

sub referent_isa {
    return '' unless $_[0]->has_reference;
    ref ${$_[0]->{reference}}
}

1;
