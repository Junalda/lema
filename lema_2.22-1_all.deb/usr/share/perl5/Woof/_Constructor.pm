package Woof::_Constructor;
use strict;
use warnings;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Woof::_Wrapper;

$Carp::Internal{'Woof::_Constructor'} = 1;
sub new {
    my $class = shift;

    my $args;
    if (ref $_[0]) {
        Carp::croak("Reference can be only hashref in constructor: $_[0]")
            if ref $_[0] ne 'HASH';

        Carp::croak("Another argument is ignored")
            if @_ > 1;

        $args = $_[0];
    }
    elsif (@_ == 1) {
        Carp::croak("Only `undef' is supported as a single argument")
            if defined $_[0];

        $args = +{};
    }
    elsif (@_ > 1) {
        Carp::croak("Invalid number of param-value pair in constructor: ", scalar @_)
            if @_ % 2;

        $args = { @_ };
    }

    my $members = do {
        no strict 'refs';
        &{$class . '::MEMBERS'}
    };

    my %keys;
    @keys{keys %$args} = undef;

    my $self = bless +{}, $class;

    my $ret_ok = 1;

    my $curr_flags = 0;
    if ($_->$_isa('Woof::_Member')) {
        $curr_flags = $_->{flags};
    }

    for (@$members) {
        my $name = $_->{name};

        local $_->{flags} = $curr_flags & Woof::FLAG_INWOOF()
                          ? (Woof::FLAG_INWOOF() | Woof::FLAG_BUILDING())
                          : Woof::FLAG_BUILDING();


        my $count = -1;

        if (exists $args->{$name}) {
            delete $keys{$name};

            if (exists $self->{$name}) {
                Carp::croak("New value for `$name' already exists");#: $self->{$name}");
            }

            $count = () = $self->$name($args->{$name});
        }
        else {
            if (exists $self->{$name}) {
            }
            else {
                if ($_->is_default_not_set) {
                    my $errors = Woof::_Wrapper::errors($class);

                    if ($errors) {
                        $errors->levelup($name);
                        $errors->add("Item `$name' is not set in constructor");
                        $errors->leveldown;
                        $ret_ok = 0;
                    }
                    else {
                        Carp::croak("Item `$name' is not set in constructor");
                    }
                }
                else {
                    $count = () = $self->$name($_->{default});
                }
            }
        }

        if ($count == 0) {
            $ret_ok = 0;
        }
    }

    if (%keys) {
        for (keys %keys) {
            $self->{$_} = $args->{$_};
        }
    }

    return $ret_ok ? $self : ();
};

1;
