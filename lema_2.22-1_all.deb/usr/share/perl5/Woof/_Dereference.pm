package Woof::_Dereference;
use strict;
use warnings;
use Data::Dumper;
use Carp;
$Carp::Internal{'Woof::_Dereference'} = 1;

sub INWOOF() {
    unless ($_->deref && $_->referent_isa eq 'CODE') {
        my @args = $_->referent;
        $_->unset_referent;
        return @args;
    }

    my @args = $_->referent->();

    $_->unset_referent;
    return @args;
}

1;
