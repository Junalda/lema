package QuickBooks::Item;
use common::sense;
use Carp;
use Data::Dumper;
use Try::Tiny;
use Safe::Isa;
use QuickBooks::Globals;
use QuickBooks::Objects;
use parent qw(QuickBooks::parent);


sub create {
    my ($self, $in) = @_;
    my $href;
    die "Invalid object" unless $in->$_isa('QuickBooks::Objects::Item');
    my $obj = $in;
    AE::log trace => "Create item from object: %s", Dumper+$obj;
    $href = $self->qb->ua->http_post('item', $obj->OUTWOOF);

    return QuickBooks::Objects::Item->new($href->{Item});
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Item}}) {
        my $obj = new QuickBooks::Objects::Item $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Item STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_fqn {
    my ($self, $fqn) = @_;

    croak "Invalid fully qualified name"
        unless !ref $fqn && length $fqn;

    my @list = $self->_query(
        qq{select * from Item where FullyQualifiedName = '$fqn'});

    if (@list > 1) {
        AE::log fatal => "Server API error: more than one Item with fqn %s",
                         $fqn;
    }

    return $list[0];
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find vendor by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from Item where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Product with ID %s is not found", $id;
        return undef;
    }
    return $list[0];
}

sub upsert {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Vendor');

    $obj->Id(undef);
    my $exists = $self->query_by_fqn($obj->FullyQualifiedName);
    if ($exists) {
        $obj->SyncToken($exists->SyncToken);
        $obj->Id($exists->Id);
    }

    return $self->create_by_obj($obj);
}


sub update {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Item');
    die "No item ID" unless $obj->Id;

    my $exists = $self->query_by_id($obj->Id);
    die "No item found to update\n" unless $exists;

    $obj->SyncToken($exists->SyncToken);

    return $self->create($obj);
}

1;
