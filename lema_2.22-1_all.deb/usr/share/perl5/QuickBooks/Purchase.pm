package QuickBooks::Purchase;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use QuickBooks::Objects;
use QuickBooks::Globals;
use QuickBooks::Objects::Purchase;
use parent qw(QuickBooks::parent);

our $DOC_NUMBER_IS_UNIQUE = 1;

sub create {
    my ($self, $purchase, $update) = @_;

    croak "Invalid purchase in arguments"
        unless $purchase->$_isa('QuickBooks::Objects::Purchase');

    if (!$update && $DOC_NUMBER_IS_UNIQUE && defined $purchase->DocNumber) {

        my @list = $self->query_by_doc_number($purchase->DocNumber);
        if (@list) {
            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                    QB_ERROR_DUP_ON_CREATE,
                    'Duplicate purchase document number already exists',
                    sprintf('Cannot create purchase with document number %s',
                            $purchase->DocNumber);

            AE::log trace => "Local error JSON: %s", $fault->JSON;

            die $fault;
        }
    }

    my $href = $self->qb->ua->http_post('purchase', $purchase->OUTWOOF);

    return new QuickBooks::Objects::Purchase $href->{Purchase};
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Purchase}}) {
        my $obj = new QuickBooks::Objects::Purchase $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Purchase STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}


sub query_by_vendor_id {
    my ($self, $vendor_id) = @_;
    croak "No vendor ID" unless !ref $vendor_id && length $vendor_id;
    croak "Invalid vendor ID" unless $vendor_id =~ /^\d+$/;
    return $self->_query(qq{select * from Purchase where VendorRef = '$vendor_id'});
}

sub query_vvv {
    my ($self, $vendor_id) = @_;
    croak "No vendor ID" unless !ref $vendor_id && length $vendor_id;
    croak "Invalid vendor ID" unless $vendor_id =~ /^\d+$/;
    return $self->_query(qq{select * from VendorCredit});
}


sub query_by_doc_number {
    my ($self, $doc_number) = @_;

    croak "Invalid document number"
        unless !ref $doc_number && length $doc_number &&
               $doc_number !~ /(\s|\:|\')/;

    my @list = $self->_query(
        qq{select * from Purchase where DocNumber = '$doc_number'}
    );

    if ($DOC_NUMBER_IS_UNIQUE && @list > 1) {
        my @ids   = map { $_->Id } @list;
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_DUP_ON_QUERY,
            'Multiple number of purchases with the same document number',
            sprintf('Multiple purchases with the same document number: %s',
                    join(', ', @ids));

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    @list
}

sub find_by_doc_numbers {
    my $self = shift;
    my @res;

    croak "No document numbers to find purchases" unless @_;

    for my $doc_number (@_) {
        my @list = $self->query_by_doc_number($doc_number);

        unless (@list) {
            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_REC_NOT_FOUND,
                'Not found purchase by document number',
                'Not found purchase by document number ' . $doc_number;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        my $last_value;
        for (@list) {
            unless (defined $last_value) {
                $last_value = $_->CustomerRef->value;
                next;
            }

            next if $_->CustomerRef->value == $last_value;

            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_DATA_CONFLICT,
                'Different customers in purchase finding results',
                'Different customers in purchases: ' .
                join(', ', map({ $_->CustomerRef->value } @list))
            ;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        push @res, @list;
    }

    @res
}

sub find_or_insert {
    my ($self, $purchase) = @_;

    croak "Invalid purchase in arguments"
        unless $purchase->$_isa('QuickBooks::Objects::Purchase');

    croak "No document num of purchase to insert"
        unless defined $purchase->DocNumber;

    my $new_purchase = try {
        return $self->create($purchase);
    }
    catch {
        die $_ unless $_->$_isa('QuickBooks::Objects::Fault') &&
                      $_->is_duplicate;

        my @list = $self->query_by_doc_number($purchase->DocNumber);

        my $el = $list[0];



        return $list[0];
    };

    $new_purchase
}

sub read : method {
    my ($self, $purchase_id) = @_;

    croak "No valid purchase ID"
        unless length $purchase_id;

    my $href = $self->qb->ua->http_get("purchase/$purchase_id");

    return new QuickBooks::Objects::Purchase $href->{Purchase};
}

sub _delete_by {
    my ($self, $doc_num, $id) = @_;

    my @list = defined $doc_num
             ? $self->query_by_doc_number($doc_num)
             : $self->read($id);

    unless (@list) {
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_REC_NOT_FOUND,
            'Not found purchase by doc num or ID to delete',
            'Not found purchase by doc num or ID to delete: ' .
                ($doc_num // $id);

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    my @ret;
    for (@list) {
        my $href = $self->qb->ua->http_post(
            "purchase",
            { Id => $_->Id, SyncToken => $_->SyncToken },
            { operation => 'delete'}
        );

        $href->{Purchase}{PaymentType} = $_->PaymentType;
        $href->{Purchase}{EntityRef}   = $_->EntityRef;
        $href->{Purchase}{AccountRef}  = $_->AccountRef;

        my $obj = new QuickBooks::Objects::Purchase $href->{Purchase};
        push @ret, $obj;
    }

    @ret
}

sub delete_by_doc_num {
    my ($self, $doc_num) = @_;
    return $self->_delete_by($doc_num, undef);
}

sub delete_by_id {
    my ($self, $id) = @_;
    return $self->_delete_by(undef, $id);
}

1;
