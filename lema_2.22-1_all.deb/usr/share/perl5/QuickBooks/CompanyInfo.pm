package QuickBooks::CompanyInfo;
use common::sense;
use Carp;
use Data::Dumper;
use parent qw(QuickBooks::parent);

sub read : method {
    my $self = shift;
    my $resp = $self->qb->ua->http_get('companyinfo/{REALMID}');
    my $obj  = QuickBooks::Objects::CompanyInfo->new($resp->{CompanyInfo});
    return $obj;
}

1;
