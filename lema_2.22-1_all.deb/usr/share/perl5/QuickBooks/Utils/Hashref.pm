package Utils::Hashref;
use strict;
use warnings;
use Carp ();

sub opendot(\%$) {
    my ($hashref, $dotted_key) = @_;

    my @keys = split /\./, $dotted_key, -1;

    push @keys, '' unless @keys;

    my $ptr = $hashref;

    for my $k (@keys) {

        unless (exists $ptr->{$k}) {
            Carp::croak("Part `$k' of dotted key `$dotted_key' ",
                        "does not exist in hashref");
        }

        $ptr = $ptr->{$k};
    }

    return $ptr;
}

1;
