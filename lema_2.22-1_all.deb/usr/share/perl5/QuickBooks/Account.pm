package QuickBooks::Account;
use common::sense;
use Carp;
use Data::Dumper;
use QuickBooks::Globals;
use QuickBooks::Objects::Account;
use parent qw(QuickBooks::parent);


sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Account}}) {
        my $obj = new QuickBooks::Objects::Account $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Account STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_fqn {
    my ($self, $fqn) = @_;

    croak "Invalid fully qualified name"
        unless !ref $fqn && length $fqn;

    my @list = $self->_query(
        qq{select * from Account where FullyQualifiedName = '$fqn'});

    if (@list > 1) {
        my @ids   = map { $_->Id } @list;
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_DUP_ON_QUERY,
            'Multiple number of accounts with the same fully qualified name',
            sprintf('Multiple accounts with the same fully qualified name: %s',
                    join(', ', @ids));

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    return $list[0];
}

1;
