package QuickBooks::Objects::Preferences;
use common::sense;
use QuickBooks::Objects::CurrencyPrefs;
use Woof;

=head1
{
  "Preferences": {
    "EmailMessagesPrefs": {
      "InvoiceMessage": {
        "Message": "Your invoice is attached.  Please remit payment at your earliest convenience.\nThank you for your business - we appreciate it very much.\n\nSincerely,\nCraig's Design and Landscaping Services",
        "Subject": "Invoice from Craig's Design and Landscaping Services"
      },
      "EstimateMessage": {
        "Message": "Please review the estimate below.  Feel free to contact us if you have any questions.\nWe look forward to working with you.\n\nSincerely,\nCraig's Design and Landscaping Services",
        "Subject": "Estimate from Craig's Design and Landscaping Services"
      },
      "SalesReceiptMessage": {
        "Message": "Your sales receipt is attached.\nThank you for your business - we appreciate it very much.\n\nSincerely,\nCraig's Design and Landscaping Services",
        "Subject": "Sales Receipt from Craig's Design and Landscaping Services"
      },
      "StatementMessage": {
        "Message": "Your statement is attached.  Please remit payment at your earliest convenience.\nThank you for your business - we appreciate it very much.\n\nSincerely,\nCraig's Design and Landscaping Services",
        "Subject": "Statement from Craig's Design and Landscaping Services"
      }
    },
    "ProductAndServicesPrefs": {
      "QuantityWithPriceAndRate": true,
      "ForPurchase": true,
      "QuantityOnHand": true,
      "ForSales": true
    },
    "domain": "QBO",
    "SyncToken": "6",
    "ReportPrefs": {
      "ReportBasis": "Accrual",
      "CalcAgingReportFromTxnDate": false
    },
    "AccountingInfoPrefs": {
      "FirstMonthOfFiscalYear": "January",
      "UseAccountNumbers": true,
      "TaxYearMonth": "January",
      "ClassTrackingPerTxn": false,
      "TrackDepartments": true,
      "TaxForm": "6",
      "CustomerTerminology": "Customers",
      "BookCloseDate": "2018-12-31",
      "DepartmentTerminology": "Location",
      "ClassTrackingPerTxnLine": true
    },
    "SalesFormsPrefs": {
      "ETransactionPaymentEnabled": false,
      "CustomTxnNumbers": false,
      "AllowShipping": false,
      "AllowServiceDate": false,
      "ETransactionEnabledStatus": "NotApplicable",
      "DefaultCustomerMessage": "Thank you for your business and have a great day!",
      "EmailCopyToCompany": false,
      "AllowEstimates": true,
      "DefaultTerms": {
        "value": "3"
      },
      "AllowDiscount": true,
      "DefaultDiscountAccount": "86",
      "AllowDeposit": true,
      "AutoApplyPayments": true,
      "IPNSupportEnabled": false,
      "AutoApplyCredit": true,
      "CustomField": [
        {
          "CustomField": [
            {
              "BooleanValue": false,
              "Type": "BooleanType",
              "Name": "SalesFormsPrefs.UseSalesCustom3"
            },
            {
              "BooleanValue": false,
              "Type": "BooleanType",
              "Name": "SalesFormsPrefs.UseSalesCustom2"
            },
            {
              "BooleanValue": true,
              "Type": "BooleanType",
              "Name": "SalesFormsPrefs.UseSalesCustom1"
            }
          ]
        },
        {
          "CustomField": [
            {
              "StringValue": "Crew
              "Type": "StringType",
              "Name": "SalesFormsPrefs.SalesCustomName1"
            }
          ]
        }
      ],
      "UsingPriceLevels": false,
      "ETransactionAttachPDF": false
    },
    "VendorAndPurchasesPrefs": {
      "BillableExpenseTracking": true,
      "TrackingByCustomer": true,
      "POCustomField": [
        {
          "CustomField": [
            {
              "BooleanValue": false,
              "Type": "BooleanType",
              "Name": "PurchasePrefs.UsePurchaseCustom3"
            },
            {
              "BooleanValue": true,
              "Type": "BooleanType",
              "Name": "PurchasePrefs.UsePurchaseCustom2"
            },
            {
              "BooleanValue": true,
              "Type": "BooleanType",
              "Name": "PurchasePrefs.UsePurchaseCustom1"
            }
          ]
        },
        {
          "CustomField": [
            {
              "StringValue": "Sales Rep",
              "Type": "StringType",
              "Name": "PurchasePrefs.PurchaseCustomName2"
            },
            {
              "StringValue": "Crew
              "Type": "StringType",
              "Name": "PurchasePrefs.PurchaseCustomName1"
            }
          ]
        }
      ]
    },
    "TaxPrefs": {
      "TaxGroupCodeRef": {
        "value": "2"
      },
      "UsingSalesTax": true
    },
    "OtherPrefs": {
      "NameValue": [
        {
          "Name": "SalesFormsPrefs.DefaultCustomerMessage",
          "Value": "Thank you for your business and have a great day!"
        },
        {
          "Name": "SalesFormsPrefs.DefaultItem",
          "Value": "1"
        },
        {
          "Name": "DTXCopyMemo",
          "Value": "false"
        },
        {
          "Name": "UncategorizedAssetAccountId",
          "Value": "32"
        },
        {
          "Name": "UncategorizedIncomeAccountId",
          "Value": "30"
        },
        {
          "Name": "UncategorizedExpenseAccountId",
          "Value": "31"
        },
        {
          "Name": "SFCEnabled",
          "Value": "true"
        },
        {
          "Name": "DataPartner",
          "Value": "false"
        },
        {
          "Name": "Vendor1099Enabled",
          "Value": "true"
        },
        {
          "Name": "TimeTrackingFeatureEnabled",
          "Value": "true"
        },
        {
          "Name": "FDPEnabled",
          "Value": "false"
        },
        {
          "Name": "ProjectsEnabled",
          "Value": "false"
        },
        {
          "Name": "DateFormat",
          "Value": "Month Date Year separated by a slash"
        },
        {
          "Name": "DateFormatMnemonic",
          "Value": "MMDDYYYY_SEP_SLASH"
        },
        {
          "Name": "NumberFormat",
          "Value": "US Number Format"
        },
        {
          "Name": "NumberFormatMnemonic",
          "Value": "US_NB"
        },
        {
          "Name": "WarnDuplicateCheckNumber",
          "Value": "true"
        },
        {
          "Name": "WarnDuplicateBillNumber",
          "Value": "false"
        },
        {
          "Name": "SignoutInactiveMinutes",
          "Value": "60"
        },
        {
          "Name": "AccountingInfoPrefs.ShowAccountNumbers",
          "Value": "false"
        }
      ]
    },
    "sparse": false,
    "TimeTrackingPrefs": {
      "WorkWeekStartDate": "Monday",
      "MarkTimeEntriesBillable": true,
      "ShowBillRateToAll": false,
      "UseServices": true,
      "BillCustomers": true
    },
    "CurrencyPrefs": {
      "HomeCurrency": {
        "value": "USD"
      },
      "MultiCurrencyEnabled": false
    },
    "Id": "1",
    "MetaData": {
      "CreateTime": "2017-10-25T01:05:43-07:00",
      "LastUpdatedTime": "2018-03-08T13:24:26-08:00"
    }
  },
  "time": "2018-03-12T08:22:43.280-07:00"
}
=cut

PUBLIC (Id                 => OF 'num');
PUBLIC (CurrencyPrefs      => OF 'QuickBooks::Objects::CurrencyPrefs');

sub currency {
    my $self = shift;
    return $self->CurrencyPrefs->HomeCurrency->value;
}

=head1
2022-01-13 19:51:13 +0400 +             "SalesFormsPrefs" : {
2022-01-13 19:51:13 +0400 +                "EmailCopyToCompany" : false,
2022-01-13 19:51:13 +0400 +                "UsingProgressInvoicing" : false,
2022-01-13 19:51:13 +0400 +                "ETransactionPaymentEnabled" : false,
2022-01-13 19:51:13 +0400 +                "AllowServiceDate" : true,
2022-01-13 19:51:13 +0400 +                "AllowEstimates" : true,
2022-01-13 19:51:13 +0400 +                "AllowShipping" : false,
2022-01-13 19:51:13 +0400 +                "DefaultTerms" : {
2022-01-13 19:51:13 +0400 +                   "value" : "3"
2022-01-13 19:51:13 +0400 +                },
2022-01-13 19:51:13 +0400 +                "AllowDiscount" : true,
2022-01-13 19:51:13 +0400 +                "CustomTxnNumbers" : true,
2022-01-13 19:51:13 +0400 +                "AutoApplyCredit" : false,
2022-01-13 19:51:13 +0400 +                "UsingPriceLevels" : false,
2022-01-13 19:51:13 +0400 +                "IPNSupportEnabled" : false,
2022-01-13 19:51:13 +0400 +                "ETransactionEnabledStatus" : "Enabled",
2022-01-13 19:51:13 +0400 +                "CustomField" : [
2022-01-13 19:51:13 +0400 +                   {
2022-01-13 19:51:13 +0400 +                      "CustomField" : [
2022-01-13 19:51:13 +0400 +                         {
2022-01-13 19:51:13 +0400 +                            "Type" : "BooleanType",
2022-01-13 19:51:13 +0400 +                            "Name" : "SalesFormsPrefs.UseSalesCustom3",
2022-01-13 19:51:13 +0400 +                            "BooleanValue" : false
2022-01-13 19:51:13 +0400 +                         },
2022-01-13 19:51:13 +0400 +                         {
2022-01-13 19:51:13 +0400 +                            "BooleanValue" : false,
2022-01-13 19:51:13 +0400 +                            "Name" : "SalesFormsPrefs.UseSalesCustom1",
2022-01-13 19:51:13 +0400 +                            "Type" : "BooleanType"
2022-01-13 19:51:13 +0400 +                         },
2022-01-13 19:51:13 +0400 +                         {
2022-01-13 19:51:13 +0400 +                            "Type" : "BooleanType",
2022-01-13 19:51:13 +0400 +                            "BooleanValue" : true,
2022-01-13 19:51:13 +0400 +                            "Name" : "SalesFormsPrefs.UseSalesCustom2"
2022-01-13 19:51:13 +0400 +                         }
2022-01-13 19:51:13 +0400 +                      ]
2022-01-13 19:51:13 +0400 +                   },
2022-01-13 19:51:13 +0400 +                   {
2022-01-13 19:51:13 +0400 +                      "CustomField" : [
2022-01-13 19:51:13 +0400 +                         {
2022-01-13 19:51:13 +0400 +                            "StringValue" : "Your Reference",
2022-01-13 19:51:13 +0400 +                            "Name" : "SalesFormsPrefs.SalesCustomName2",
2022-01-13 19:51:13 +0400 +                            "Type" : "StringType"
2022-01-13 19:51:13 +0400 +                         },
2022-01-13 19:51:13 +0400 +                         {
2022-01-13 19:51:13 +0400 +                            "Name" : "SalesFormsPrefs.SalesCustomName1",
2022-01-13 19:51:13 +0400 +                            "StringValue" : "Our Order (inactive)",
2022-01-13 19:51:13 +0400 +                            "Type" : "StringType"
2022-01-13 19:51:13 +0400 +                         }
2022-01-13 19:51:13 +0400 +                      ]
2022-01-13 19:51:13 +0400 +                   }
2022-01-13 19:51:13 +0400 +                ],
2022-01-13 19:51:13 +0400 +                "AllowDeposit" : false,
2022-01-13 19:51:13 +0400 +                "DefaultDiscountAccount" : "96",
2022-01-13 19:51:13 +0400 +                "ETransactionAttachPDF" : true,
2022-01-13 19:51:13 +0400 +                "AutoApplyPayments" : true
2022-01-13 19:51:13 +0400 +             },
=cut
sub invoice_custom_field_id {
    my ($self, $name) = @_;
    die "Custom field name is not defined\n" unless length $name;

    return undef unless $self->{SalesFormsPrefs};
    my $aref = $self->{SalesFormsPrefs}{CustomField};
    return undef unless ref $aref eq 'ARRAY';

    for my $href (@$aref) {
        my $cf = $href->{CustomField};
        next unless ref $cf eq 'ARRAY';

        for my $href2 (@$cf) {
            next unless lc($href2->{StringValue}) eq lc $name;
            next unless $href2->{Name} =~ /^SalesFormsPrefs\.SalesCustomName(\d+)/;

            return $1;
        }
    }
}

1;
