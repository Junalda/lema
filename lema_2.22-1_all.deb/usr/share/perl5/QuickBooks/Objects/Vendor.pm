package QuickBooks::Objects::Vendor;
use common::sense;
use QuickBooks::Objects::VendorRef;
use QuickBooks::Objects::EntityRef;
use QuickBooks::Objects::TermRef;
use QuickBooks::Objects::Addr;
use Woof;

PUBLIC (DisplayName => OF 'str_ne');
PUBLIC (Id          => UNDEFOK OF 'num')   = undef;
PUBLIC (Balance     => UNDEFOK OF 'float') = undef;

PUBLIC (CompanyName => UNDEFOK OF 'strnull') = undef;

PUBLIC (GivenName   => UNDEFOK OF 'strnull') = undef;
PUBLIC (FamilyName  => UNDEFOK OF 'strnull') = undef;
PUBLIC (BillAddr    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;


PUBLIC (Notes       => UNDEFOK OF 'strnull') = undef;
PUBLIC (Mobile      => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (PrimaryPhone   => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (AlternatePhone => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (Fax => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (PrimaryEmailAddr => UNDEFOK OF 'QuickBooks::Objects::Email') = undef;

PUBLIC (AcctNum   => UNDEFOK OF 'strnull') = undef;
PUBLIC (TermRef => UNDEFOK OF 'QuickBooks::Objects::TermRef') = undef;
PUBLIC (TaxIdentifier => UNDEFOK OF 'strnull') = undef;
PUBLIC (PrintOnCheckName => UNDEFOK OF 'strnull') = undef;


PUBLIC (WebAddr  => UNDEFOK OF 'QuickBooks::Objects::WebAddr') = undef;
PUBLIC (BillRate => UNDEFOK OF 'num')   = undef;


PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;

sub new_mod {
    my ($class, $href) = @_;

    my $primary_email_addr = delete $href->{PrimaryEmailAddr};
    if (defined $primary_email_addr) {
        $href->{PrimaryEmailAddr} = QuickBooks::Objects::Email
                                                 ->new_mod($primary_email_addr);
    }

    my $bill_addr = delete $href->{BillAddr};
    if (defined $bill_addr) {
        $href->{BillAddr} = QuickBooks::Objects::Addr->new_mod($bill_addr);
    }

    return $class->new($href);
}

sub _DisplayName_ {
    my $self = shift;
    die "Display Name must be defined\n" unless length $_[0];
    VALIDATE;
    return $_[0];
}


sub make_ref {
    my $self = shift;
    return new QuickBooks::Objects::VendorRef
               value => $self->Id,
               name  => $self->DisplayName;
}

sub make_entity_ref {
    my $self = shift;
    return new QuickBooks::Objects::EntityRef
               value => $self->Id,
               type  => 'Vendor',
               name  => $self->DisplayName;
}

sub person {
    my $self = shift;
    die "Not setter" if @_;
    return join ' ', grep { length } $self->GivenName, $self->FamilyName;
}

sub phone {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryPhone) {
        return $self->PrimaryPhone->FreeFormNumber;
    }
    return undef;
}

sub fax {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->Fax) {
        return $self->Fax->FreeFormNumber;
    }
    return undef;
}

sub alternate {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->AlternatePhone) {
        return $self->AlternatePhone->FreeFormNumber;
    }
    return undef;
}

sub mobile {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->Mobile) {
        return $self->Mobile->FreeFormNumber;
    }
    return undef;
}

sub email {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryEmailAddr) {
        return $self->PrimaryEmailAddr->Address;
    }
    return undef;
}

sub country {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->Country;
    }
    return undef;
}

sub webaddr {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->WebAddr) {
        return $self->WebAddr->URI;
    }
    return undef;
}

sub address {
    my $self = shift;
    die "Not setter" if @_;
    return undef unless $self->BillAddr;
    return $self->BillAddr->address;
}

sub address_comma_fmt {
    my $self = shift;
    die "Not setter" if @_;
    return undef unless $self->BillAddr;
    return $self->BillAddr->address_comma_fmt;
}

sub reserved { $_[0]{reserved} }

sub TO_JSON {
    my $reserved = $_[0]->reserved;

    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{person}    = $_[0]->person;
    $res->{country}   = $_[0]->country;
    $res->{email}     = $_[0]->email;
    $res->{phone}     = $_[0]->phone;
    $res->{fax}       = $_[0]->fax;
    $res->{alternate} = $_[0]->alternate;
    $res->{mobile}    = $_[0]->mobile;
    $res->{webaddr}   = $_[0]->webaddr;
    $res->{address}   = $_[0]->address;

    $res->{reserved} = $reserved;

    return $res;
}

1;
