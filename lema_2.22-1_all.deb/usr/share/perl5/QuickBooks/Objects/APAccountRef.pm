package QuickBooks::Objects::APAccountRef;
use common::sense;
use Woof;

=head1 EXAMPLE
2021-10-16 19:47:32 +0400 +                                              'APAccountRef' => {
2021-10-16 19:47:32 +0400 +                                                                  'name' => 'Accounts Payable (A/P)',
2021-10-16 19:47:32 +0400 +                                                                  'value' => '123'
2021-10-16 19:47:32 +0400 +                                                                },
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

1;
