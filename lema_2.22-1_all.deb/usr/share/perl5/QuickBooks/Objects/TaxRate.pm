package QuickBooks::Objects::TaxRate;
use common::sense;
use Safe::Isa;
use QuickBooks::Objects::AgencyRef;
use QuickBooks::Objects::TaxReturnLineRef;
use QuickBooks::Objects::EffectiveTaxRate;
use Woof;

=head1
      {
        "RateValue": 7.1,
        "AgencyRef": {
          "value": "1"
        },
        "domain": "QBO",
        "Name": "AZ State tax",
        "SyncToken": "0",
        "SpecialTaxType": "NONE",
        "DisplayType": "ReadOnly",
        "sparse": false,
        "Active": true,
        "MetaData": {
          "CreateTime": "2014-09-18T12:17:04-07:00",
          "LastUpdatedTime": "2014-09-18T12:17:04-07:00"
        },
        "Id": "1",
        "Description": "Sales Tax",


        'EffectiveTaxRate' => [
                               {
                                 'EndDate' => '2022-01-25T00:00:00-08:00',
                                 'RateValue' => 9,
                                 'EffectiveDate' => '1970-01-01T00:00:00-08:00'
                               },
                               {
                                 'EffectiveDate' => '2022-01-26T00:00:00-08:00',
                                 'RateValue' => 8
                               }
                             ],

      },
=cut

PUBLIC (Id                 => OF 'num');
PUBLIC (RateValue          => UNDEFOK OF 'num')     = undef;
PUBLIC (AgencyRef          => OF 'QuickBooks::Objects::AgencyRef');
PUBLIC (Name               => UNDEFOK OF 'strnull') = undef;
PUBLIC (SpecialTaxType     => UNDEFOK OF 'strnull') = undef;
PUBLIC (DisplayType        => UNDEFOK OF 'strnull') = undef;
PUBLIC (Description        => UNDEFOK OF 'strnull') = undef;
PUBLIC (TaxReturnLineRef   => UNDEFOK OF 'QuickBooks::Objects::TaxReturnLineRef') = undef;
PUBLIC (Active             => OF 'boolean');
PUBLIC (Taxable            => UNDEFOK OF 'boolean') = undef;
PUBLIC (EffectiveTaxRate   => UNDEFOK OF 'ARRAY') = undef;

sub _EffectiveTaxRate_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    die "Invalid effective tax rates list\n" unless ref $in eq 'ARRAY';

    my @copy;
    for my $el (@$in) {
        if ($el->$_isa('QuickBooks::Objects::EffectiveTaxRate')) {
            push @copy, $el;
            next;
        }

        unless (BUILDING) {
            die "Element of array `EffectiveTaxRate` is not " .
                "QuickBooks::Objects::EffectiveTaxRate\n";
        }
        else {
            push @copy, QuickBooks::Objects::EffectiveTaxRate->new($el);
            next;
        }
    }

    return @copy ? \@copy : undef;
}

sub effective_rate_now {
    my ($self) = @_;
    if (defined $self->RateValue) {
        return $self->RateValue;
    }

    my $aref = $self->EffectiveTaxRate;
    return undef unless $aref;

    my $now = AE::time;
    for (@$aref) {
        if (defined $_->end_date_epoch) {
            next if $now >= $_->end_date_epoch;
        }

        if ($now >= $_->effective_date_epoch) {
            return $_->RateValue if defined $_->RateValue;
        }
    }

    return undef;
}

sub agency_id {
    my $self = shift;
    my $ref = $self->AgencyRef;
    if ($ref && $ref->value > 0) {
        return 0+$ref->value;
    }
    return undef;
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{effective_rate_now} = $_[0]->effective_rate_now;
    $res->{agency_id} = $_[0]->agency_id;

    return $res;
}

1;
