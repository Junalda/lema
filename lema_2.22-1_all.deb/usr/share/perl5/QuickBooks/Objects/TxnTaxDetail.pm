package QuickBooks::Objects::TxnTaxDetail;
use common::sense;
use Carp;
use Safe::Isa;
use QuickBooks::Objects::TaxRateRef;
use Woof;

PUBLIC (TaxLine  => OF 'ARRAY') = sub { +[] };
PUBLIC (TotalTax => OF 'float') = 0;

sub _TotalTax_ {
    my $self = shift;
    return 0 unless length $_[0];
    VALIDATE;
    return $_[0];
}

sub _TaxLine_ {
    my ($self, $in) = @_;
    VALIDATE;

    my @copy;
    $in = [] unless ref $in eq 'ARRAY';
    for my $el (@$in) {
        if ($el->$_isa('QuickBooks::Objects::Detail')) {
            push @copy, $el;
            next;
        }

        unless (BUILDING) {
            croak "Element of array `TaxLine` is not " .
                  "QuickBooks::Objects::Detail";
        }
        else {
            push @copy, QuickBooks::Objects::Detail->new($el);
            next;
        }
    }

    return \@copy;
}

sub tax_line_count {
    my $self = shift;
    my $tl = $self->TaxLine;
    return scalar @$tl;
}

sub add_to_tax_line {
    my ($self, $detail) = @_;
    die "Invalid detail in arguments: $detail"
        unless $detail->$_isa('QuickBooks::Objects::Detail');

    push @{$self->_TaxLine_}, $detail;
    ()
}

1;
