package QuickBooks::Objects::Account;
use common::sense;
use QuickBooks::Objects::AccountRef;
use QuickBooks::Objects::ItemAccountRef;
use QuickBooks::Objects::DepositToAccountRef;
use Woof;

PUBLIC (FullyQualifiedName => OF 'str_ne');
PUBLIC (AccountSubType     => OF 'str_ne');
PUBLIC (Classification     => OF 'str_ne');
PUBLIC (AccountType        => OF 'str_ne');
PUBLIC (CurrentBalance     => OF 'float');
PUBLIC (Id                 => OF 'num');
PUBLIC (CurrencyRef        => OF 'QuickBooks::Objects::CurrencyRef');
PUBLIC (Active             => OF 'boolean');

PUBLIC (DisplayName => UNDEFOK OF 'str_ne') = undef;

sub _FullyQualifiedName {
    my ($self, $fqn) = @_;
    $self->DisplayName($fqn);
    return $fqn;
}

sub make_account_ref {
    my $self = shift;
    return new QuickBooks::Objects::AccountRef
               name  => $self->FullyQualifiedName,
               value => $self->Id;
}

sub make_item_account_ref {
    my $self = shift;
    return new QuickBooks::Objects::ItemAccountRef
               name  => $self->FullyQualifiedName,
               value => $self->Id;
}

sub make_income_account_ref {
    my $self = shift;
    return new QuickBooks::Objects::AccountRef
               name  => $self->FullyQualifiedName,
               value => $self->Id;
}

sub make_deposit_to_account_ref {
    my $self = shift;
    return new QuickBooks::Objects::DepositToAccountRef
               name  => $self->FullyQualifiedName,
               value => $self->Id;
}

1;
