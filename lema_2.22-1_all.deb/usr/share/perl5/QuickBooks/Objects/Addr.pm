package QuickBooks::Objects::Addr;
use common::sense;
use Woof;

=head1 EXAMPLE
    {
          "City": "Bayshore",
          "Line1": "4581 Finch St.",
          "PostalCode": "94326",
          "Lat": "INVALID",
          "Long": "INVALID",
          "CountrySubDivisionCode": "CA",
          "Id": "2"
    }
=cut

PUBLIC (Id         => UNDEFOK OF 'num')     = undef;
PUBLIC (City       => UNDEFOK OF 'strnull') = undef;
PUBLIC (Line1      => UNDEFOK OF 'strnull') = undef;
PUBLIC (Line2      => UNDEFOK OF 'strnull') = undef;
PUBLIC (Line3      => UNDEFOK OF 'strnull') = undef;
PUBLIC (Line4      => UNDEFOK OF 'strnull') = undef;
PUBLIC (Line5      => UNDEFOK OF 'strnull') = undef;
PUBLIC (PostalCode => UNDEFOK OF 'strnull') = undef;
PUBLIC (Country    => UNDEFOK OF 'strnull') = undef;
PUBLIC (CountrySubDivisionCode => UNDEFOK OF 'strnull') = undef;

sub new_mod {
    my ($class, $href) = @_;

    my $address_lines = delete $href->{address_lines};
    if (length $address_lines) {
        my @lines       = split /\r?\n/, $address_lines;
        my $n           = 1;
        my $filled_last = 0;

        for (my $i = 0; $i < @lines; $i++) {
            my $key = 'Line' . $n;

            unless ($filled_last) {
                die "Billing address $key already exists\n"
                    if length $href->{$key};
            }

            $lines[$i] =~ s/^\s+//;
            $lines[$i] =~ s/\s+$//;
            next unless length $lines[$i];

            $href->{$key} .= ", " if length $href->{$key};
            $href->{$key} .= $lines[$i];

            $filled_last = 1 if $n == 5;
            $n++ if $n < 5;
        }
    }

    my $reserved = $href->{reserved};
    my $self = $class->new($href);
    $self->{reserved} = $reserved;
    return $self;
}

sub address {
    my $self = shift;
    my $address;
    my $has_zip;
    for (qw(Line1 Line2 Line3 Line4 Line5 PostalCode)) {
        my $part = $self->$_();
        next unless length $part;
        $address .= "\n" if length $address;
        $address .= $part;
        $has_zip = 1 if $_ eq 'PostalCode';
    }

    my $part = $self->CountrySubDivisionCode;
    if (length $part) {
        if ($has_zip) {
            $address .= " ";
        } else {
            $address .= "\n" if length $address;
        }
        $address .= $part;
    }

    my $has_city = length $self->City;
    if ($has_city) {
        $address .= "\n" if length $address;
        $address .= $self->City;
    }

    my $part = $self->Country;
    if (length $part == 2) {
        my $name = QuickBooks::Globals::country_code_to_name($part);
        $part = $name if length $name;
    }

    if ($has_city) {
        $address .= ", " if length $address;
    } else {
        $address .= "\n" if length $address;
    }

    $address .= $part;

    $address = undef unless length $address;
    return $address;
}

sub address_lines {
    my ($self) = @_;
    my $address_lines;
    for (qw(Line1 Line2 Line3 Line4 Line5)) {
        my $part = $self->$_();
        next unless length $part;
        $address_lines .= "\n" if length $address_lines;
        $address_lines .= $part;
    }
    return $address_lines;
}

sub address_lines_fmt {
    my ($self) = @_;
    my $address = $self->address_lines;
    return undef unless defined $address;
    $address =~ s/\r?\n/|/g;
    return $address;
}

sub address_fmt {
    my ($self) = @_;
    my $address = $self->address;
    return undef unless defined $address;
    $address =~ s/\r?\n/|/g;
    return $address;
}

sub address_comma_fmt {
    my ($self) = @_;
    my $address = $self->address;
    return undef unless defined $address;
    $address =~ s/\r?\n/, /g;
    return $address;
}

sub has_any_defined {
    my $self = shift;
    for (qw(Line1 Line2 Line3 Line4 Line5 PostalCode
            City Country CountrySubDivisionCode)) {
        return 1 if length $self->$_();
    }
    return 0;
}

sub reserved { $_[0]{reserved} }


1;
