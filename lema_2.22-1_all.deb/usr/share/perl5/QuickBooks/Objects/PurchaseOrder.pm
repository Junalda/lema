package QuickBooks::Objects::PurchaseOrder;
use common::sense;
use Carp;
use Safe::Isa;
use Data::Dumper;
use QuickBooks::Objects;
use QuickBooks::Objects::Detail;
use QuickBooks::Objects::AccountRef;
use QuickBooks::Objects::Txn;
use QuickBooks::Globals;
use parent qw(QuickBooks::Objects::_TxnDateMethods);
use Woof;

=head1 EXAMPLE
=cut

PUBLIC (Id   => UNDEFOK OF 'num') = undef;
PUBLIC (Line => OF 'ARRAY') = sub { [] };
PUBLIC (TxnDate => UNDEFOK OF 'dateYYYYMMDD') = undef;

PUBLIC (CurrencyRef => UNDEFOK OF 'QuickBooks::Objects::CurrencyRef') = undef;
PUBLIC (TotalAmt    => UNDEFOK OF 'float') = undef;
PUBLIC (DocNumber   => UNDEFOK OF 'str')   = undef;
PUBLIC (LinkedTxn   => OF 'ARRAY') = sub { [] };
PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;
PUBLIC (PrivateNote => UNDEFOK OF 'strnull') = undef;
PUBLIC (Memo => UNDEFOK OF 'strnull') = undef;
PUBLIC (VendorRef => OF 'QuickBooks::Objects::VendorRef');

PUBLIC (domain => UNDEFOK OF 'strnull') = undef;


sub _DocNumber {
    my $self = shift;

    VALIDATE;
    my $len = length $_[0];

    return undef unless $len;

    croak "Document number length must be not greater 21 chars"
       unless $len <= 21;

    $_[0]
}

sub _Line {
    my $self = shift;

    VALIDATE;

    my @copy;

    for my $el (@{$_[0]}) {
        unless ($el->$_isa('QuickBooks::Objects::Detail')) {
            unless (BUILDING) {
                croak "Element of array `Line` is not " .
                      "QuickBooks::Objects::Detail";
            }
            else {
                push @copy, QuickBooks::Objects::Detail->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}


sub make_txn {
    my $self = shift;

    croak "Couldn't make invoice Txn as invoice ID is not defined"
        unless defined $self->Id;

    return new QuickBooks::Objects::Txn TxnId   => $self->Id,
                                        TxnType => 'Invoice';
}




=head1 EXAMPLE
=cut
sub get_accounts_payable {
    my ($self) = @_;
    my $count  = 0;
    my $amount = 0;

    for my $line (@{$self->Line}) {
        next unless $line->$_isa('QuickBooks::Objects::Detail');
        next unless my $abel = $line->AccountBasedExpenseLineDetail;

        if ($abel->AccountRef->value == 189) {
            $count++;
            $amount += $line->Amount;
        }
    }

    return undef unless $count;

    return [ $amount => $count ];
}

sub doc_num_autogen {
    my $self = shift;

    return $self->DocNumber if $self->DocNumber =~ /^PS\d+/;

    my $extra_num = QuickBooks::Globals::seq_extra_on ? '0' : '';
    my $seq       = QuickBooks::Globals::seq_inc;

    croak "Invalid seq number in arguments"
        unless !ref $seq && $seq =~ /^\d+$/ && $seq >= 1;

    croak "DocNumber is already generated: ", $self->DocNumber
        if defined $self->DocNumber;

    my $chksum_char = QuickBooks::Globals::doc_chksum(
                            $self->EntityRef->value,
                            $seq,
                            $self->get_txndate_lyr,
                            $self->get_txndate_doy);

    my $docnum = sprintf "%s%02d%03d-%03d-%03d%s%s",
                "PS",
                $self->get_txndate_lyr,
                $self->get_txndate_doy,
                $self->EntityRef->value,
                $seq,
                $chksum_char,
                $extra_num;

    $self->DocNumber($docnum);

    ()
}

sub enum_details {
    my ($self, $cb) = @_;
    for (@{$self->Line}) {
        $cb->($_);
    }

    ()
}

sub line_details {
    my $self = shift;

    my @lines;
    $self->enum_details(sub {
        my $detail = shift;
        push @lines, $detail->line;
    });

    @lines
}

sub line {
    my $self = shift;

    return sprintf "%s,%s,%s,%s,%s",#Net 30,,My Memo,%s,%s,%s,%s,%s\r\n",
            $self->DocNumber,
            $self->Id,
            $self->CustomerRef->value,
            $self->TxnDate,
            $self->TotalAmt,
    ;
}


sub get_linked_bill_ids {
    my $self = shift;
    my $link = $self->LinkedTxn;
    return undef unless ref $link eq 'ARRAY';

    my @bill_ids;
    for (@$link) {
        if ($_->{TxnType} eq 'Bill' && defined $_->{TxnId}) {
            push @bill_ids, $_->{TxnId};
        }
    }
    return @bill_ids ? \@bill_ids : undef;
}


sub has_linked_bill_id {
    my ($self) = @_;
    return defined $self->get_linked_bill_ids;
}

sub enum_item_qty {
    my ($self, $cb) = @_;
    die "No callback" unless ref $cb eq 'CODE';

    my $line = $self->Line;
    return unless @$line;

    for my $detail (@$line) {
        next unless $detail->DetailType eq 'ItemBasedExpenseLineDetail';
        my $expense = $detail->ItemBasedExpenseLineDetail;
        next unless $expense;
        my $item_ref = $expense->ItemRef;
        next unless $item_ref;

        $cb->($detail, $expense, $item_ref);
    }
}

1;
