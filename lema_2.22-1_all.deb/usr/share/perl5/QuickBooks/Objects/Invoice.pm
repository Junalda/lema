package QuickBooks::Objects::Invoice;
use common::sense;
use Carp;
use Safe::Isa;
use Data::Dumper;
use QuickBooks::Objects::MetaData;
use QuickBooks::Objects::Detail;
use QuickBooks::Objects::CustomerRef;
use QuickBooks::Objects::CurrencyRef;
use QuickBooks::Objects::ItemRef;
use QuickBooks::Objects::ItemAccountRef;
use QuickBooks::Objects::Txn;
use QuickBooks::Objects::CustomerMemo;
use QuickBooks::Objects::SalesTermRef;
use QuickBooks::Objects::Addr;
use QuickBooks::Objects::CustomFieldElement;
use QuickBooks::Globals;
use parent qw(QuickBooks::Objects::_TxnDateMethods);
use Woof;

PUBLIC (Id   => UNDEFOK OF 'num') = undef;
PUBLIC (Line => OF 'ARRAY') = sub { [] };
PUBLIC (TxnTaxDetail => UNDEFOK OF 'QuickBooks::Objects::TxnTaxDetail') = undef;
PUBLIC (TxnDate => UNDEFOK OF 'dateYYYYMMDD') = undef;
PUBLIC (DueDate => UNDEFOK OF 'dateYYYYMMDD') = undef;

PUBLIC (CustomerRef => UNDEFOK OF 'QuickBooks::Objects::CustomerRef');
PUBLIC (CurrencyRef => UNDEFOK OF 'QuickBooks::Objects::CurrencyRef') = undef;
PUBLIC (Balance     => UNDEFOK OF 'float') = undef;
PUBLIC (TotalAmt    => UNDEFOK OF 'float') = undef;
PUBLIC (DocNumber   => UNDEFOK OF 'strnull') = undef;
PUBLIC (SalesTermRef => UNDEFOK OF 'QuickBooks::Objects::SalesTermRef') = undef;
PUBLIC (LinkedTxn   => OF 'ARRAY') = sub { [] };
PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;
PUBLIC (PrivateNote => UNDEFOK OF 'strnull') = undef;
PUBLIC (BillAddr    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (ShipAddr    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (CustomerMemo => UNDEFOK OF 'QuickBooks::Objects::CustomerMemo') = undef;
PUBLIC (MetaData => UNDEFOK OF 'QuickBooks::Objects::MetaData') = undef;

PUBLIC (CustomField => UNDEFOK OF 'ARRAY') = sub { [] };

PUBLIC (BillEmail => UNDEFOK OF 'QuickBooks::Objects::Email') = undef;
PUBLIC (BillEmailCc => UNDEFOK OF 'QuickBooks::Objects::Email') = undef;
PUBLIC (BillEmailBcc => UNDEFOK OF 'QuickBooks::Objects::Email') = undef;

PUBLIC (GlobalTaxCalculation => UNDEFOK OF 'strnull') = undef;

sub doc_code {
    my $self = shift;
    croak "QBO ID is not known"
        unless length $self->Id;
    die "Document code is not greater than 0\n"
        unless $self->Id > 0;

    return LEMA::make_doc_code($self->Id, $self->DocNumber);
}

sub new_mod {
    my ($class, $href) = @_;

    my $ship_addr = delete $href->{ShipAddr};
    if (defined $ship_addr) {
        $href->{ShipAddr} = QuickBooks::Objects::Addr->new_mod($ship_addr);
    }

    return $class->new($href);
}


sub _CustomField_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    $in = $in->() if ref $in eq 'CODE';
    die "Invalid custom field array" unless ref $in eq 'ARRAY';
    return [] unless @$in;

    my @val;
    for (@$in) {
        my $field = QuickBooks::Objects::CustomFieldElement->new($_);
        push @val, $field;
    }

    return \@val;
}

sub merge_custom_fields {
    my ($self, $new_fields) = @_;
    return unless defined $new_fields;
    die "Invalid new custom fields to merge" unless ref $new_fields eq 'ARRAY';
    return unless @$new_fields;

    my $out = $self->CustomField;
    $out //= [];
    for my $new_field (@$new_fields) {
        my $replaced = 0;
        for (@$out) {
            if ($_->DefinitionId == $new_field) {
                if (ref $new_field eq 'HASH') {
                    $_ = QuickBooks::Objects::CustomFieldElement->new($new_field);
                } else {
                    $_ = $new_field;
                }
                $replaced = 1;
                next;
            }
        }

        unless ($replaced) {
            if (ref $new_field eq 'HASH') {
                push @$out, QuickBooks::Objects::CustomFieldElement->new($new_field);
            } else {
                push @$out, $new_field;
            }
        }
    }
    ()
}

sub _MetaData_ {
    my $self = shift;
    return $_[0] if defined $_[0];
    return QuickBooks::Objects::MetaData->new(+{});
}

sub _DocNumber {
    my $self = shift;

    VALIDATE;
    my $len = length $_[0];

    return undef unless $len;

    croak "Document number length must be not greater 21 chars"
       unless $len <= 21;

    $_[0]
}

sub _Line {
    my $self = shift;

    VALIDATE;

    my @copy;

    for my $el (@{$_[0]}) {
        unless ($el->$_isa('QuickBooks::Objects::Detail')) {
            unless (BUILDING) {
                croak "Element of array `Line` is not " .
                      "QuickBooks::Objects::Detail";
            }
            else {
                push @copy, QuickBooks::Objects::Detail->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}

sub _LinkedTxn {
    my $self = shift;

    VALIDATE;

    my @copy;

    for my $el (@{$_[0]}) {
        unless ($el->$_isa('QuickBooks::Objects::Txn')) {
            unless (BUILDING) {
                croak "Element of array `LinkedTxn` is not " .
                      "QuickBooks::Objects::Txn";
            }
            else {
                push @copy, QuickBooks::Objects::Txn->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}

sub make_txn {
    my $self = shift;

    croak "Couldn't make invoice Txn as invoice ID is not defined"
        unless defined $self->Id;

    return new QuickBooks::Objects::Txn TxnId   => $self->Id,
                                        TxnType => 'Invoice';
}

sub get_payment_ids {
    my $self = shift;

    my @ids;
    for (@{$self->LinkedTxn}) {
        if ($_->is_payment) {
            push @ids, $_->TxnId;
        }
    }

    @ids
}

sub is_paid {
    my $self = shift;
    croak "Invoice total amount is not greater 0"
        unless $self->TotalAmt > 0;

    return $self->Balance == 0 ? 1 : 0
}

sub is_partial_paid {
    my $self = shift;

    croak "Invoice total amount is not greater 0"
        unless $self->TotalAmt > 0;

    return 0 if $self->Balance == 0;

    return ($self->Balance < $self->TotalAmt) ? 1 : 0;
}

sub doc_num_autogen {
    my $self = shift;

    return $self->DocNumber if $self->DocNumber =~ /^IN\d+/;

    my $extra_num = QuickBooks::Globals::seq_extra_on ? '0' : '';
    my $seq       = QuickBooks::Globals::seq_inc;

    croak "Invalid seq number in arguments"
        unless !ref $seq && $seq =~ /^\d+$/ && $seq >= 1;

    croak "DocNumber is already generated: ", $self->DocNumber
        if defined $self->DocNumber;

    my $chksum_char = QuickBooks::Globals::doc_chksum(
                            $self->CustomerRef->value,
                            $seq,
                            $self->get_txndate_lyr,
                            $self->get_txndate_doy);

    my $docnum = sprintf "%s%02d%03d-%03d-%03d%s%s",
                "IN",
                $self->get_txndate_lyr,
                $self->get_txndate_doy,
                $self->CustomerRef->value,
                $seq,
                $chksum_char,
                $extra_num;

    $self->DocNumber($docnum);

    ()
}

sub enum_details {
    my ($self, $cb) = @_;
    for (@{$self->Line}) {
        $cb->($_);
    }

    ()
}

sub line_details {
    my $self = shift;

    my @lines;
    $self->enum_details(sub {
        my $detail = shift;
        push @lines, $detail->line;
    });

    @lines
}

sub line {
    my $self = shift;

    return sprintf "%s,%s,%s,%s,%s",#Net 30,,My Memo,%s,%s,%s,%s,%s\r\n",
            $self->DocNumber,
            $self->Id,
            $self->CustomerRef->value,
            $self->TxnDate,
            $self->TotalAmt,
    ;
}

sub docnumber_no_dash_fmt {
    my $self = shift;
    my $docnum = $self->DocNumber;
    return $docnum;
}


sub enum_item_qty {
    my ($self, $cb) = @_;
    die "No callback" unless ref $cb eq 'CODE';

    my $line = $self->Line;
    return unless @$line;

    for my $detail (@$line) {
        next unless $detail->DetailType eq 'SalesItemLineDetail';
        my $sale = $detail->SalesItemLineDetail;
        next unless $sale;
        my $item_ref = $sale->ItemRef;
        next unless $item_ref;

        $cb->($detail, $sale, $item_ref);
    }
}

sub item_id_qty_href {
    my $self = shift;
    my %hash;
    $self->enum_item_qty(sub {

        my ($detail, $sale, $item_ref) = @_;
        $hash{$item_ref->value} += $sale->Qty;
        ()
    });

    return \%hash;
}

sub email_aref_href {
    my $self = shift;

    my %uniq;
    my @array;
    for my $method (qw(BillEmail BillEmailBcc BillEmailCc)) {
        my $addr = $self->$method;
        next unless $addr;
        my $aref = $addr->email_aref;
        next unless $aref;
        for my $email (@$aref) {
            my $new_method;
            if ($method eq 'BillEmail' || $method eq 'BillEmailCc') {
                $new_method = 'TO/CC';
            } else {
                $new_method = 'BCC';
            }

            next if $uniq{$new_method . '.' . $email};
            $uniq{$new_method . '.' . $email}++;

            push @array, { email => $email, method => $new_method };
        }
    }

    return @array ? \@array : undef;
}

=head1
sub get_items_with_taxes {
    my $self = shift;
    my %hash;
    my @tax_codes_per_lines;
    $self->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;
        push @tax_codes_per_lines, { code => $sale->TaxCodeRef->value,
                                     candidates => [] };
    });

    return undef unless @tax_codes_per_lines;

    my $detail = $self->TxnTaxDetail;
    return undef $detail;

    my $aref = $detail->TaxLine;
    return unless $aref && @$aref;

    for $el (@$aref) {
        my $line = $el->TaxLineDetail;
        next unless $line;

        for (@tax_codes_per_lines) {
            push @{$_->{candidates}}, [ $line->TaxRateRef->value, $line->TaxPercent ];
        }
    }

    return @tax_codes_per_lines;
}
=cut

1;
