package QuickBooks::Objects::Email;
use common::sense;
use Woof;

=head1 EXAMPLE
{
"Address": "abc@abc.com"
}
=cut

PUBLIC (Address => UNDEFOK OF 'strnull') = undef;

sub new_mod {
    my ($class, $href) = @_;

    my $email_lines = delete $href->{email_lines};
    if (length $email_lines) {
        die "Email address is already defined\n"
            if length $href->{Address};
    }

    my $self = $class->new($href);

    $self->push_emails($email_lines)
        if $email_lines =~ /\S/;

    return $self;
}

sub _Address_ {
    my $self = shift;
    return undef unless length $_[0];
    unless (BUILDING) {
        die "Invalid email address\n" if length $_[0] > 100;
    }
    return $_[0];
}

sub push_emails {
    my ($self, $emails) = @_;
    die "No email address to store\n" unless $emails =~ /\S/;

    my $strlist = $self->Address;
    my %uniq;
    my @new;

    my @all;
    push @all, split /\s*,\s*/,     $strlist;
    push @all, split /\s*[,\n]\s*/, $emails;

    for my $email (@all) {
        next unless $email =~ /\S/;
        $email =~ s/^\s+//;
        $email =~ s/\s+$//;
        unless (exists $uniq{lc($email)}) {
            push @new, $email;
        }
        $uniq{lc($email)}++;
    }

    $strlist = @new ? join(', ', @new) : undef;
    $self->Address($strlist);
    ()
}

sub email_lines {
    my ($self) = @_;
    my $strlist = $self->Address;
    return undef unless length $strlist;

    my $lines;
    for my $email (split /\s*,\s*/, $strlist) {
        next unless $email =~ /\S/;
        $lines .= $email . "\n";
    }

    return $lines;
}

sub email_aref {
    my ($self) = @_;

    my ($self) = @_;
    my $strlist = $self->Address;
    return undef unless length $strlist;

    my %uniq;
    for my $email (split /\s*,\s*/, $strlist) {
        next unless $email =~ /\S/;
        $uniq{$email}++;
    }

    return %uniq ? [ keys %uniq ] : undef;
}

1;
