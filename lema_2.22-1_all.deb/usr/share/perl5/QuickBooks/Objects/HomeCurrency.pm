package QuickBooks::Objects::HomeCurrency;
use common::sense;
use Woof;

=head1 EXAMPLE
"HomeCurrency" : {
    "value" : "USD"
}
=cut

PUBLIC (value => OF 'str_ne');

1;
