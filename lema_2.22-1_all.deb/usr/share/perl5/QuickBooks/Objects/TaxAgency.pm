package QuickBooks::Objects::TaxAgency;
use common::sense;
use Woof;

=head1
{
    "TaxAgency": [
      {
        "SyncToken": "0", 
        "domain": "QBO", 
        "DisplayName": "Arizona Dept. of Revenue", 
        "TaxTrackedOnSales": true, 
        "TaxTrackedOnPurchases": false, 
        "sparse": false, 
        "Id": "1", 
        "MetaData": {
          "CreateTime": "2014-09-18T12:17:04-07:00", 
          "LastUpdatedTime": "2014-09-18T12:17:04-07:00"
        }
      }, 
      {
        "SyncToken": "0", 
        "domain": "QBO", 
        "DisplayName": "Board of Equalization", 
        "TaxTrackedOnSales": true, 
        "TaxTrackedOnPurchases": false, 
        "sparse": false, 
        "Id": "2", 
        "MetaData": {
          "CreateTime": "2014-09-18T12:17:04-07:00", 
          "LastUpdatedTime": "2014-09-18T12:17:04-07:00"
        }
      }
    ]
  }, 
}

=cut

PUBLIC (Id                 => OF 'num');
PUBLIC (DisplayName        => UNDEFOK OF 'strnull') = undef;

1;
