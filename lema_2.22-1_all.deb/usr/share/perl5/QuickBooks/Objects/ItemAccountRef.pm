package QuickBooks::Objects::ItemAccountRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"ItemAccountRef" : {
    "name" : "Super puper sales",
    "value" : "123"
}
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => OF 'str_ne');

1;
