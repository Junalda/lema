package QuickBooks::Objects::SalesTermRef;
use common::sense;
use Woof;

=head1 EXAMPLE
'ParentRef' => {
                      'value' => '177'
                    },
=cut

PUBLIC (value => UNDEFOK OF 'int') = undef;

sub _value_ {
    my $self = shift;
    $_[0] = undef unless length $_[0];
    VALIDATE;
    return $_[0];
}

1;
