package QuickBooks::Objects::ItemRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"ItemRef"=> {
    "value"=> "23",
    "name"=> "Services",
}
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

sub line {
    my $self = shift;
    return sprintf "%s,%s",
                   $self->value,
                   $self->name;
}

1;
