package QuickBooks::Objects::Customer;
use common::sense;
use Data::Dumper;
use QuickBooks::Objects::CustomerRef;
use QuickBooks::Objects::CustomerTypeRef;
use QuickBooks::Objects::Addr;
use QuickBooks::Objects::ParentRef;
use QuickBooks::Objects::Phone;
use QuickBooks::Objects::Email;
use QuickBooks::Objects::WebAddr;
use QuickBooks::Objects::SalesTermRef;
use Woof;

=head
{
  "QueryResponse": {
    "Customer": [
      {
        "domain": "QBO",
        "FamilyName": "Lauterbach",
        "DisplayName": "Amy's Bird Sanctuary",
        "DefaultTaxCodeRef": {
          "value": "2"
        },
        "PrimaryEmailAddr": {
          "Address": "Birds@Intuit.com"
        },
        "PreferredDeliveryMethod": "Print",
        "GivenName": "Amy",
        "FullyQualifiedName": "Amy's Bird Sanctuary",
        "BillWithParent": false,
        "Job": false,
        "BalanceWithJobs": 274.0,
        "PrimaryPhone": {
          "FreeFormNumber": "(650) 555-3311"
        },
        "Active": true,
        "MetaData": {
          "CreateTime": "2014-09-11T16:48:43-07:00",
          "LastUpdatedTime": "2015-07-01T10:14:15-07:00"
        },
        "BillAddr": {
          "City": "Bayshore",
          "Line1": "4581 Finch St.",
          "PostalCode": "94326",
          "Lat": "INVALID",
          "Long": "INVALID",
          "CountrySubDivisionCode": "CA",
          "Id": "2"
        },
        "MiddleName": "Michelle",
        "Notes": "Note added via Update operation.",
        "Taxable": true,
        "Balance": 274.0,
        "SyncToken": "5",
        "CompanyName": "Amy's Bird Sanctuary",
        "ShipAddr": {
          "City": "Bayshore",
          "Line1": "4581 Finch St.",
          "PostalCode": "94326",
          "Lat": "INVALID",
          "Long": "INVALID",
          "CountrySubDivisionCode": "CA",
          "Id": "109"
        },
        "PrintOnCheckName": "Amy's Bird Sanctuary",
        "sparse": false,
        "Id": "1"
      },
      {
        "domain": "QBO",
        "PrimaryEmailAddr": {
          "Address": "Consulting@intuit.com"
        },
        "DisplayName": "Weiskopf Consulting",
        "FamilyName": "Weiskopf",
        "PreferredDeliveryMethod": "Print",
        "GivenName": "Nicola",
        "FullyQualifiedName": "Weiskopf Consulting",
        "BillWithParent": false,
        "Job": false,
        "BalanceWithJobs": 390.0,
        "PrimaryPhone": {
          "FreeFormNumber": "(650) 555-1423"
        },
        "Active": true,
        "MetaData": {
          "CreateTime": "2014-09-11T17:29:04-07:00",
          "LastUpdatedTime": "2015-06-24T15:54:02-07:00"
        },
        "BillAddr": {
          "City": "Bayshore",
          "Line1": "45612 Main St.",
          "PostalCode": "94326",
          "Lat": "45.256574",
          "Long": "-66.0943698",
          "CountrySubDivisionCode": "CA",
          "Id": "30"
        },
        "Taxable": false,
        "Balance": 390.0,
        "SyncToken": "0",
        "CompanyName": "Weiskopf Consulting",
        "ShipAddr": {
          "City": "Bayshore",
          "Line1": "45612 Main St.",
          "PostalCode": "94326",
          "Lat": "45.256574",
          "Long": "-66.0943698",
          "CountrySubDivisionCode": "CA",
          "Id": "30"
        },
        "PrintOnCheckName": "Weiskopf Consulting",
        "sparse": false,
        "Id": "29"
      }
    ],
    "startPosition": 1,
    "maxResults": 6
  },
  "time": "2015-07-23T11:02:25.149-07:00"
}
=cut


PUBLIC (DisplayName => OF 'str_ne');
PUBLIC (Id          => UNDEFOK OF 'num')   = undef;
PUBLIC (UserId      => UNDEFOK OF 'num')   = undef;
PUBLIC (ClientCompanyId => UNDEFOK OF 'num')   = undef;
PUBLIC (Balance     => UNDEFOK OF 'float') = undef;
PUBLIC (BillWithParent => UNDEFOK OF 'boolean') = undef;
PUBLIC (Job => UNDEFOK OF 'boolean') = undef;
PUBLIC (Taxable     => UNDEFOK OF 'boolean') = undef;
PUBLIC (PrimaryTaxIdentifier => UNDEFOK OF 'strnull') = undef;
PUBLIC (CompanyName => UNDEFOK OF 'strnull') = undef;
PUBLIC (GivenName   => UNDEFOK OF 'strnull') = undef;
PUBLIC (FamilyName  => UNDEFOK OF 'strnull') = undef;
PUBLIC (BillAddr    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (ShipAddr    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (Notes       => UNDEFOK OF 'strnull') = undef;
PUBLIC (Mobile      => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (PrimaryPhone    => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (AlternatePhone => UNDEFOK OF 'QuickBooks::Objects::Phone') = undef;
PUBLIC (PrimaryEmailAddr => UNDEFOK OF 'QuickBooks::Objects::Email') = undef;
PUBLIC (SalesTermRef => UNDEFOK OF 'QuickBooks::Objects::SalesTermRef') = undef;
PUBLIC (PrintOnCheckName => OF 'str') = "";
PUBLIC (PreferredDeliveryMethod => OF 'strnull') = "None";

PUBLIC (CustomerEx => UNDEFOK OF 'str') = undef;

PUBLIC (TaxExemptionReasonId => UNDEFOK OF 'num')   = undef;

PUBLIC (BusinessNumber => UNDEFOK OF 'str') = undef;

PUBLIC (WebAddr     => UNDEFOK OF 'QuickBooks::Objects::WebAddr') = undef;

PUBLIC (ParentRef   => UNDEFOK OF 'QuickBooks::Objects::ParentRef') = undef;
PUBLIC (CustomerTypeRef   => UNDEFOK OF 'QuickBooks::Objects::CustomerTypeRef') = undef;

PUBLIC (CustomField => OF 'ARRAY') = sub { +[] };



PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;

PUBLIC (ResaleNum => UNDEFOK OF 'strnull') = undef;

PUBLIC (FullyQualifiedName => UNDEFOK OF 'strnull') = undef;


sub new_mod {
    my ($class, $href) = @_;

    my $primary_email_addr = delete $href->{PrimaryEmailAddr};
    if (defined $primary_email_addr) {
        $href->{PrimaryEmailAddr} = QuickBooks::Objects::Email
                                                 ->new_mod($primary_email_addr);
    }

    my $bill_addr = delete $href->{BillAddr};
    if (defined $bill_addr) {
        $href->{BillAddr} = QuickBooks::Objects::Addr->new_mod($bill_addr);
    }

    my $ship_addr = delete $href->{ShipAddr};
    if (defined $ship_addr) {
        $href->{ShipAddr} = QuickBooks::Objects::Addr->new_mod($ship_addr);
    }

    return $class->new($href);
}


sub make_ref {
    my $self = shift;
    return new QuickBooks::Objects::CustomerRef value => $self->Id;
}

sub person {
    my $self = shift;
    die "Not setter" if @_;
    return join ' ', grep { length } $self->GivenName, $self->FamilyName;
}

sub phone {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryPhone) {
        return $self->PrimaryPhone->FreeFormNumber;
    }
    return undef;
}

sub email {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryEmailAddr) {
        return $self->PrimaryEmailAddr->Address;
    }
    return undef;
}

sub billing_country {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->Country;
    }
    return undef;
}

sub shipping_country {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->Country;
    }
    return undef;
}

sub shipping_address {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->address;
    }
    return undef;
}

sub shipping_address_fmt {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->address_fmt;
    }
    return undef;
}

sub billing_address {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->address;
    }
    return undef;
}

sub billing_address_fmt {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->address_fmt;
    }
    return undef;
}

sub reserved { $_[0]{reserved} }

sub TO_JSON {
    my $reserved = $_[0]->reserved;

    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{person} = $_[0]->person;
    $res->{email}  = $_[0]->email;
    $res->{phone}  = $_[0]->phone;
    $res->{shipping_country} = $_[0]->shipping_country;
    $res->{billing_country}  = $_[0]->billing_country;

    $res->{billing_address}      = $_[0]->billing_address;
    $res->{billing_address_fmt}  = $_[0]->billing_address_fmt;
    $res->{shipping_address}     = $_[0]->shipping_address;
    $res->{shipping_address_fmt} = $_[0]->shipping_address_fmt;

    $res->{reserved} = $reserved;

    return $res;
}

1;
