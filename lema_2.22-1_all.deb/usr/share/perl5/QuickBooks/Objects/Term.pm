package QuickBooks::Objects::Term;
use common::sense;
use Woof;

=head1 EXAMPLE
{
  "Term": {
    "SyncToken": "0", 
    "domain": "QBO", 
    "Name": "Net 60", 
    "DiscountPercent": 0, 
    "DiscountDays": 0, 
    "Type": "STANDARD", 
    "sparse": false, 
    "Active": true, 
    "DueDays": 60, 
    "Id": "4", 
    "MetaData": {
      "CreateTime": "2014-09-11T14:41:49-07:00", 
      "LastUpdatedTime": "2014-09-11T14:41:49-07:00"
    }
  }, 
  "time": "2015-07-28T08:52:57.63-07:00"
}
=cut

PUBLIC (Id => UNDEFOK OF 'num') = undef;
PUBLIC (DueDays => UNDEFOK OF 'num') = undef;
PUBLIC (Active => UNDEFOK OF 'boolean') = undef;
PUBLIC (Name => UNDEFOK OF 'strnull') = undef;

1;
