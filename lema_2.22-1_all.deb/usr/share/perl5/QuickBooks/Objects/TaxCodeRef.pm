package QuickBooks::Objects::TaxCodeRef;
use common::sense;
use Woof;

PUBLIC (value => OF 'str');
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

1;
