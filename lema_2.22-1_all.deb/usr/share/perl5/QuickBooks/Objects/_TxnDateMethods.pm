package QuickBooks::Objects::_TxnDateMethods;
use common::sense;
use Carp;
use Safe::Isa;
use Data::Dumper;
use Date::Calc qw(Day_of_Year);
$Carp::Internal{'QuickBooks::Objects::_TxnDateMethods'} = 1;

sub __validate_txndate_format($) {
    my $txn_date = shift;

    croak "TxnDate is not defined"
        unless defined $txn_date;

    croak "TxnDate is not set"
        unless length $txn_date;

    croak "TxnDate is not scalar"
        unless !ref $txn_date;

    croak "TxnDate is bad format (required YYYY-MM-DD)"
        unless $txn_date =~ /^(\d{4})-(\d{2})-(\d{2})$/;

    croak "TxnDate invalid date year"
        unless $1 >= 1900 && $1 < 2100;

    croak "TxnDate invalid date month"
        unless $2 >= 1 && $2 <= 12;

    croak "TxnDate invalid date day"
        unless $3 >= 1 && $3 <= 31;

    ()
}

sub get_txndate_lyr {
    my $self = shift;
    __validate_txndate_format($self->TxnDate);
    return int substr $self->TxnDate, 2, 2;
}

sub get_txndate_year {
    my $self = shift;
    __validate_txndate_format($self->TxnDate);
    return int substr $self->TxnDate, 0, 4;
}

sub get_txndate_month {
    my $self = shift;
    __validate_txndate_format($self->TxnDate);
    return int substr $self->TxnDate, 5, 2;
}

sub get_txndate_day {
    my $self = shift;
    __validate_txndate_format($self->TxnDate);
    return int substr $self->TxnDate, 8, 2;
}

sub get_txndate_doy {
    my $self = shift;
    my $doy  = Day_of_Year($self->get_txndate_year,
                           $self->get_txndate_month,
                           $self->get_txndate_day);
    return int $doy;
}

sub get_txndate_int {
    my $self = shift;
    __validate_txndate_format($self->TxnDate);

    my $int = $self->TxnDate;
    $int =~ s/\-//g;

    return int $int;
}

1;
