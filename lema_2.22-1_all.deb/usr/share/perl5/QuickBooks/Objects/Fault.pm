package QuickBooks::Objects::Error;
use common::sense;
use QuickBooks::Globals;
use Woof;

=head1 EXAMPLE
{
    "Message": "Duplicate Name Exists Error",
    "Detail": "The name supplied already exists. : null",
    "code": "6240"
}
=cut

PUBLIC (Message => OF 'str_ne');
PUBLIC (Detail  => OF 'str_ne');
PUBLIC (code    => OF 'num');

package QuickBooks::Objects::Fault;
use common::sense;
use Woof;
use Data::Dumper;
use QuickBooks::Globals;
use Carp;
use Safe::Isa;
use JSON::XS;

our $JSON = JSON::XS->new->utf8(1);

=head1 EXAMPLE
{
  "Fault": {
    "Error": [
      {
        "Message": "Duplicate Name Exists Error",
        "Detail": "The name supplied already exists. : null",
        "code": "6240"
      }
    ],
    "type": "ValidationFault"
  },
  "time": "2021-10-23T10:12:54.750-09:00"
}
=cut

PUBLIC (Error => OF 'ARRAY');
PUBLIC (type  => OF 'str_ne');

sub _Error {
    my ($self, $aref) = @_;

    VALIDATE;

    my @copy;

    for my $el (@$aref) {
        unless ($el->$_isa('QuickBooks::Objects::Error')) {
            unless (BUILDING) {
                die "Element of array `Error` is not " .
                    "QuickBooks::Objects::Error\n";
            }
            else {
                push @copy, QuickBooks::Objects::Error->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}

sub is_duplicate {
    my $self = shift;

    return 0 if $self->type eq 'HTTPError';

    for (@{$self->Error}) {
        return 1 if $_->code == 6240;
        return 1 if $_->code == QB_ERROR_DUP_ON_CREATE;
        return 1 if $_->code == QB_ERROR_DUP_ON_QUERY;
    }

    0
}

sub is_not_found {
    my $self = shift;

    return 0 if $self->type eq 'HTTPError';

    for (@{$self->Error}) {
        return 1 if $_->code == 610;
        return 1 if $_->code == QB_ERROR_REC_NOT_FOUND;
    }

    0
}

sub HTTP_ERROR($$$) {
    croak "HTTP error code cannot be less than 600000"
        unless $_[0] >= 600000;

    my $detail = $_[2];
    if ($detail =~ /^\{/) {
        my $j = $JSON->decode($detail);
        $detail = $j->{error_description} || "Unknown error - please try again later";
    }

    return new QuickBooks::Objects::Fault {
        Error => [
          {
            "code"    => $_[0],
            "Message" => $_[1],
            "Detail"  => $detail,
          }
        ],
        type => 'HTTPError',
    };
}

sub LOCAL_ERROR($$$) {
    croak "Local error code cannot be less than 500000"
        unless $_[0] >= 500000;

    return new QuickBooks::Objects::Fault {
        Error => [
          {
            "code"    => $_[0],
            "Message" => $_[1],
            "Detail"  => $_[2],
          }
        ],
        type => 'LocalError',
    };
}

sub stringify {
    my $self = shift;
    return Dumper+$self;
}

1;
