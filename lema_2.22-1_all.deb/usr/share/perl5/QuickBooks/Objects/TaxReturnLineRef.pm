package QuickBooks::Objects::TaxReturnLineRef;
use common::sense;
use Woof;

=head1 EXAMPLE
2021-12-25 12:19:55 +0400 +                  'TaxReturnLineRef' => {
2021-12-25 12:19:55 +0400 +                                          'value' => '3'
2021-12-25 12:19:55 +0400 +                                        },
=cut

PUBLIC (value => OF 'num');

1;
