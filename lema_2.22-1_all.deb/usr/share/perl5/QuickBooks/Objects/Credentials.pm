package QuickBooks::Objects::Credentials;
use common::sense;
use boolean;
use Woof;
use Safe::Isa;
use Data::Dumper;
our $VERSION = 0.01;

PUBLIC (package       => OF 'str_ne')  = __PACKAGE__;
PUBLIC (version       => OF 'float')   = $VERSION;
PUBLIC (sandbox       => OF 'boolean') = sub { boolean::false };

PUBLIC (company_name  => UNDEFOK OF 'strnull') = undef;

PUBLIC (AppClientID   => OF 'str_ne');
PUBLIC (AppSecret     => OF 'str_ne');
PUBLIC (RealmID       => OF 'str_ne');
PUBLIC (AuthCode      => OF 'str_ne');

PUBLIC (AppScope      => OF 'str_ne') = 'com.intuit.quickbooks.accounting';
PUBLIC (RedirectURI   => UNDEFOK OF 'str_ne') = undef;
PUBLIC (TransID       => UNDEFOK OF 'str_ne') = undef;

PUBLIC (refresh_token => UNDEFOK OF 'str_ne') = undef;
PUBLIC (access_token  => UNDEFOK OF 'str_ne') = undef;
PUBLIC (cookie_jar    => OF 'HASH')           = sub { +{} };

sub _package_ {
    VALIDATE;
    die "Package is not handled: $_[1]" unless $_[0]->$_isa($_[1]);
    return $_[1];
}

sub _version_ {
    VALIDATE;
    die "Package is handled for versions not greater than $VERSION"
        unless $_[1] <= $VERSION;
    return $_[1];
}

sub _AppClientID_ {
    my $self = shift;
    die "No AppClientID value\n" unless length $_[0];
    VALIDATE;
    die "Invalid AppClientID value\n" unless $_[0] =~ /^\S+$/;
    return $_[0];
}

sub _AppSecret_ {
    my $self = shift;
    die "No AppSecret value\n" unless length $_[0];
    VALIDATE;
    die "Invalid AppSecret value\n" unless $_[0] =~ /^\S+$/;
    return $_[0];
}

sub _AuthCode_ {
    my $self = shift;
    die "No AppAuthCode value\n" unless length $_[0];
    VALIDATE;
    die "Invalid AppAuthCode value\n" unless $_[0] =~ /^\S+$/;
    return $_[0];
}

sub _RealmID_ {
    my $self = shift;
    die "No RealmID value\n" unless length $_[0];
    VALIDATE;
    die "Invalid RealmID value\n" unless $_[0] =~ /^\S+$/;
    return $_[0];
}

sub _refresh_token_ {
    my $self = shift;
    VALIDATE;
    if (defined $_[0]) {
        die "Invalid refresh token\n" unless $_[0] =~ /^\S+$/;
    }
    return $_[0];
}

sub _access_token_ {
    my $self = shift;
    VALIDATE;
    if (defined $_[0]) {
        die "Invalid access token\n" unless $_[0] =~ /^\S+$/;
    }
    return $_[0];
}

sub _cookie_jar_ {
    my ($self, $in) = @_;
    VALIDATE;
    if (ref $in eq 'CODE') { $in = $in->(); }
    die "Invalid cookie hashref\n" unless ref $in eq 'HASH';
    return $in;
}

sub are_same_tokens {
    my ($self, $creds) = @_;
    die "Invalid QBO credentials object"
        unless $creds->$_isa('QuickBooks::Objects::Credentials');

    return 0 if $self->AppClientID ne $creds->AppClientID;
    return 0 if $self->AppSecret   ne $creds->AppSecret;
    return 0 if $self->RealmID     ne $creds->RealmID;
    return 0 if $self->AuthCode    ne $creds->AuthCode;
    return 0 if $self->sandbox     != $creds->sandbox;

    return 1;
}

1;
