package QuickBooks::useragent;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Scalar::Util;
use AnyEvent::Log;
use JSON::XS;# qw(encode_json decode_json);
use MIME::Base64;
use LWP::UserAgent;
use ACME::Claim;
use QuickBooks::Globals;
use QuickBooks::Objects::Fault;

our $MINORVERSION = 62;

sub new {
    my ($class, %args) = @_;

    die "No credentials"
        unless $args{-credentials}->$_isa('QuickBooks::Objects::Credentials');

    my $write_cb = delete $args{-write_cb};
    die "No callback to write QBO data"
        unless ref $write_cb eq 'CODE';
    $args{_write_cb} = $write_cb;


    $args{_ua}           = undef;
    $args{_unauth_count} = 0;
    $args{_json}         = JSON::XS->new->utf8(1)
                                        ->pretty(1)
                                        ->allow_blessed(1)
                                        ->convert_blessed(1);
    my $self = bless \%args, $class;
    $self->_credentials->access_token(undef);
    return $self;
}

sub write_cb {
    if (@_ > 1) {
        die "Invalid QBO write callback"
            unless ref $_[1] eq 'CODE';

        return $_[0]{_write_cb} = $_[1];
    }
    return $_[0]{_write_cb};
}

sub _credentials { $_[0]{-credentials} }
sub _json        { $_[0]{_json}        }
sub _ua {
    return $_[0]{_ua} if $_[0]{_ua};

    my $ua = LWP::UserAgent->new(keep_alive   => 1,
                                 max_redirect => 0);
    $ua->agent("Mozilla/8.0");
    $ua->timeout(25);

    my $cookie_jar = $_[0]->_credentials->cookie_jar;
    die "No cookie hash\n" unless $cookie_jar;
    $ua->cookie_jar($cookie_jar);

    $_[0]{_ua} = $ua;
    $_[0]->_authorize;
    return $_[0]{_ua};
}
sub _unauth_count : lvalue { $_[0]{_unauth_count} }

sub _build_headers {
    my ($self, %args) = @_;
    my %hdr = (
        Accept => 'application/json',
    );

    $hdr{'Content-Type'} = $args{-json}
                         ? 'application/json;charset=utf-8'
                         : 'application/x-www-form-urlencoded';

    if ($args{-auth_api_key}) {
        die "Not implemented: cookie required";
    }
    elsif ($args{-auth_token}) {
        claim { length $self->_credentials->access_token } "Access token is not defined\n";
        $hdr{Authorization} = "Bearer " . $self->_credentials->access_token;
    } else {
        $hdr{Authorization} = "Basic " . $self->_build_basic_auth;
    }

    return %hdr;
}

sub _build_basic_auth {
    my $self = shift;
    AE::log trace => "Build basic auth from AppClientID (%s) and AppSecret (%s)",
                     $self->_credentials->AppClientID,
                     $self->_credentials->AppSecret;
    my $auth = encode_base64($self->_credentials->AppClientID . ':' .
                             $self->_credentials->AppSecret, '');
    AE::log debug => "Basic auth is %s", $auth;
    return $auth;
}

sub _authorize {
    my $self = shift;

    if (defined $self->_credentials->refresh_token) {
        $self->_refresh_token;
    }
    else {
        $self->_request_refresh_and_access_token;
    }
    ()
}

sub _request_refresh_and_access_token {
    my $self = shift;
    claim { !defined $self->_credentials->refresh_token },
          "Refresh token is already known";

    my $url = q{https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer};

    my %form = (
        redirect_uri  => 'https://developer.intuit.com/v2/OAuth2Playground/RedirectUrl',
        state         => $self->_credentials->TransID,
        code          => $self->_credentials->AuthCode,
        grant_type    => 'authorization_code',
    );

    my @hdr = $self->_build_headers(-json => 0, -auth_token => 0);
    my $res = $self->_ua->post($url, \%form, @hdr);

    unless ($res->is_success) {
        my $fault = QuickBooks::Objects::Fault::HTTP_ERROR
                    $res->code + QB_ERROR_HTTP_GROUP,
                    $res->message,
                    $res->decoded_content;

        AE::log trace => "HTTP response not JSON (1): %s", $fault->JSON;
        die $fault;
    }

    my $access = $self->_json->decode($res->decoded_content);

    $self->_credentials->access_token($access->{access_token});
    $self->_credentials->refresh_token($access->{refresh_token});

    $self->write_cb->($self->_credentials);
    ()
}

sub _refresh_token {
    my $self = shift;
    claim { length $self->_credentials->refresh_token },
          "Refresh Token must be set for refresh";

    AE::log debug => "Getting new Refresh Token...";

    my $url = q{https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer};

    my %form = (
        refresh_token => $self->_credentials->refresh_token,
        grant_type    => 'refresh_token'
    );

    my @hdr = $self->_build_headers(-json => 0, -auth_token => 0);
    my $res = $self->_ua->post($url, \%form, @hdr);

    unless ($res->is_success) {
        my $fault = QuickBooks::Objects::Fault::HTTP_ERROR
                    $res->code + QB_ERROR_HTTP_GROUP,
                    $res->message,
                    $res->decoded_content;

        AE::log trace => "HTTP response not JSON (2): %s", $fault->JSON;
        die $fault;
    }

    my $access = $self->_json->decode($res->decoded_content);

    $self->_credentials->access_token($access->{access_token});
    $self->_credentials->refresh_token($access->{refresh_token});

    $self->write_cb->($self->_credentials);
    ()
}

sub _base_url {
    my $self = shift;
    my $url = $self->_credentials->sandbox
            ? 'https://sandbox-quickbooks.api.intuit.com'
            : 'https://quickbooks.api.intuit.com';

    return $url . "/v3/company/" . $self->_credentials->RealmID . "/";
}

sub http_get {
    my @args = @_;
    my ($self, $path, $form) = @args;
    claim { !ref $path && length $path && $path !~ /\s/ },
          "No valid path for HTTP GET: `$path`";

    $path =~ s!^/+!!;
    $path =~ s!\{REALMID\}!$self->_credentials->RealmID!ge;

    my $uri  = URI->new($self->_base_url . $path);
    my %base = (minorversion => $MINORVERSION);

    $uri->query_form($form ? (%$form, %base) : (%base));

    $self->_ua;

    my @hdr = $self->_build_headers(-json => 1, -auth_token => 1);

    AE::log debug => "HTTP GET request to %s", $uri;
    AE::log trace => "HTTP GET request with headers: %s", Dumper+\@hdr;

    my $res = $self->_ua->get($uri, @hdr);
    $self->write_cb->($self->_credentials);

    AE::log debug => "Response code is %u, response message is %s",
                     $res->code, $res->message;

    $self->_handle_http_error($res, sub { http_get(@args) })
        unless $res->is_success;

    $self->_unauth_count = 0;

    my $href = $self->_json->decode($res->decoded_content);

    if ($href->{Fault}) {
        my $fault = new QuickBooks::Objects::Fault $href->{Fault};
        AE::log trace => "HTTP response JSON (1): %s", $fault->JSON;
        die $fault;
    }

    AE::log trace => "HTTP response JSON (2): %s",
                     $self->_json->encode($href);

    return $href;
}

sub http_post {
    my @args = @_;
    my ($self, $path, $form, $form_get) = @args;

    croak "No valid path for HTTP POST: `$path`"
        unless !ref $path && length $path && $path !~ /\s/;

    $path =~ s/\{REALMID\}/$self->_credentials->RealmID/ge;

    my $uri  = URI->new($self->_base_url . $path);
    my %base = (minorversion => $MINORVERSION);

    $uri->query_form($form_get ? (%$form_get, %base) : (%base));

    $self->_ua;

    my @hdr = $self->_build_headers(-json => 1, -auth_token => 1);

    AE::log debug => "HTTP POST request to %s", $uri;
    AE::log trace => "HTTP POST request with headers: %s", Dumper+\@hdr;

    my $json = $self->_json->encode($form);
    AE::log trace => "HTTP POST request with JSON: %s", $json;

    my $res = $self->_ua->post($uri, Content => $json, @hdr);
    $self->write_cb->($self->_credentials);

    AE::log debug => "Response code is %u, response message is %s",
                     $res->code, $res->message;

    $self->_handle_http_error($res, sub { http_post(@args) })
        unless $res->is_success;

    $self->_unauth_count = 0;

    my $href = $self->_json->decode($res->decoded_content);

    if ($href->{Fault}) {
        my $fault = new QuickBooks::Objects::Fault $href->{Fault};
        AE::log trace => "HTTP response JSON (3): %s", $fault->JSON;
        die $fault;
    }

    AE::log trace => "HTTP response JSON (4): %s",
                     $self->_json->encode($href);

    return $href;
}

sub _handle_http_error {
    my ($self, $res, $repeat_cb) = @_;

    if ($res->code == 401) {
        AE::log error => "Authentication failed with message %s",
                         $res->message;
        AE::log trace => "Authentication failed HTTP response: %s",
                         $res->decoded_content;

        $self->_unauth_count++;

        if ($self->_unauth_count >= 2) {
            die "Failed to get QBO refresh token more than 2 times";
        }

        $self->_refresh_token;

        return $repeat_cb->();
    }
    elsif ($res->code == 400) {
        $self->_unauth_count = 0;

        my $href  = $self->_json->decode($res->decoded_content);
        my $fault = QuickBooks::Objects::Fault->new($href->{Fault});

        AE::log debug => "HTTP response JSON (5): %s", $fault->JSON;

        die $fault;
    }
    else {
        my $fault = QuickBooks::Objects::Fault::HTTP_ERROR
                        $res->code + QB_ERROR_HTTP_GROUP,
                        $res->message,
                        $res->decoded_content;

        AE::log trace => "HTTP response JSON (6): %s",
                         $fault->JSON;

        die $fault;
    }
    ()
}

1;
