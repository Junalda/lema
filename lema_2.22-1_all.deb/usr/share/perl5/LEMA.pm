package LEMA;
use strict;
use warnings;
use Carp;
use Safe::Isa;
use BSON::OID;
use ACME::E
    O_APP_QBO_NO_API_CREDS    => [ 7000, "No QBO API credentials in settings" ],
    SC_SUCCESS => [ 0000, "Success" ],
    SC_ERROR   => [ 1000, "%s" ],
;

our $VERSION = '2.22';
use constant CUSTOM_FIELD_YOUR_REFERENCE => 'Your Reference';

sub hdr($) {
    my $e = shift;
    my %hdr;

    unless (defined $e) {
        $hdr{Success} = 1;
        return \%hdr;
    }

    $hdr{Success} = 0;

    if (is_e $e) {
        $hdr{Code}   = $e->code;
        $hdr{Detail} = $e->detail;
    } elsif (ref $e eq 'HASH' &&
             exists $e->{detail} && exists $e->{type} && exists $e->{code}) {
        $hdr{Code}   = $e->{code};
        $hdr{Detail} = $e->{detail};
    } else {
        $hdr{Code}   = SC_ERROR;
        $hdr{Detail} = $e;
    }

    return \%hdr;
}

sub BSON::OID::create {
    return BSON::OID->new unless defined $_[0];
    return BSON::OID->new(oid => $_[0]->oid) if $_[0]->$_isa('BSON::OID');
    return BSON::OID->new(oid => $_[0]) if length $_[0] == 12;
    return BSON::OID->new(oid => pack( "H*", $_[0]))
      if $_[0] =~ m!^[0-9a-f]{24}$!;

    die "Argument must be 12 packed bytes or 24 bytes of hex to build BSON ID";
}

sub parse_doc_code($) {
    my $doc_code = shift;
    croak "Document code is not set" unless length $doc_code;

    unless ($doc_code =~ /^([^\t]*)\t/) {
        croak "Document code is without delimiter: $doc_code";
    }

    unless ($doc_code =~ /^([^\t]*)\t(\d+)$/) {
        croak "Document code is without ID";
    }

    my ($doc_id, $doc_number) = ($2, $1);
    croak "Document ID is not greater than 0: $doc_code" unless $doc_id > 0;
    croak "Document number in document code is more than 512 characters"
        if length $doc_number > 512;

    return (int($doc_id), $doc_number);
}

sub make_doc_code($$) {
    my ($doc_id, $doc_number) = @_;
    croak "No document ID" unless length $doc_id;
    croak "Document ID not greater than 0" unless $doc_id > 0;
    croak "Document number is more than 512 characters"
        if length $doc_number > 512;

    return $doc_number . "\t" . $doc_id;
}

sub check_id($) {
    my $doc_id = shift;
    croak "No QBO ID for transaction" unless length $doc_id;
    croak "QBO ID for transaction is not greater than 0" unless $doc_id > 0;
    ()
}

1;
