package LEMA::HTTPD::Extended::HTTPConnection::Writer;
use common::sense;
use Scalar::Util;

sub new {
    my ($class, $con) = @_;
    my $self = { con => $con, _first_trace_log => 1 };
    Scalar::Util::weaken($self->{con});

    bless $self, $class;
}

sub clean {
    my ($self) = @_;
    for (keys %$self) {
        delete $self->{$_};
    }
    %$self = ();
    undef $self;
    ()
}

sub con {
    my $con = $_[0]->{con};
    return undef if !defined ($con) ||
                    !defined ($con->{hdl}) ||
                    $con->{disconnected};
    $con
}

sub write {
    my $con = $_[0]->con or return 0;

    if ($con->{trace_log}) {
        my $fmt = "Send response to HTTP client by writer (not first packet):\n%s";

        if ($_[0]{_first_trace_log}) {
            $_[0]{_first_trace_log} = 0;
            $fmt = "Send response to HTTP client by writer (first packet):\n%s";
        }

        AE::log trace => $fmt, $_[1];
    }

    utf8::downgrade $_[1];
    $con->{hdl}->push_write($_[1]);
    1
}

sub print { goto &write; }

sub close {
    my $con = $_[0]->con;

    $_[0]->clean;

    return 0 unless $con;

    $con->response_done;
    1
}

sub DESTROY {
    return unless $_[0];
    $_[0]->close;
}

1;
