package LEMA::HTTPD::Extended;
use common::sense;
use Try::Tiny;
use Carp;
use Safe::Isa;
use CGI::Struct::XS;
use LEMA::HTTPD::Extended::HTTPConnection;
use LEMA::HTTPD::Extended::Response;
use ACME::E;
use parent qw(AnyEvent::HTTPD);
our $VERSION = 0.01;

our $orig_cb;
BEGIN { $orig_cb      = \&AnyEvent::HTTPD::HTTPServer::new }

our $orig_vars_cb;
BEGIN { $orig_vars_cb = \&AnyEvent::HTTPD::Request::vars }

sub AnyEvent::HTTPD::HTTPServer::new {
    my $this = shift;
    return $orig_cb->($this, connection_class =>
            'LEMA::HTTPD::Extended::HTTPConnection', @_);
}

sub AnyEvent::HTTPD::Request::vars {
    my $this = shift;
    my %vars = $orig_vars_cb->($this);
    for my $val (values %vars) {
        if (ref $val eq 'ARRAY') {
            for (@$val) {
                utf8::decode($_) if !ref $_;
            }
        }
        else {
            utf8::decode($val) if !ref $val;
        }
    }
    %vars
}


sub AnyEvent::HTTPD::Request::vars_struct {
    my ($self, $errs) = @_;
    $errs ||= [];
    return build_cgi_struct { $self->vars }, $errs, { dclone => 0 };
}

sub AnyEvent::HTTPD::Request::same_vars_struct {
    my ($self, $errs) = @_;
    $errs ||= [];
    my %vars = $self->vars;
    use Data::Dumper;

    my @keys = sort keys %vars;
    for my $key (@keys) {
        next unless $key =~ /\[x\]/;
        my $val   = delete $vars{$key};
        my $count = 0;
        if (ref $val eq 'ARRAY') {
            for (@$val) {
                my $new_key = $key;
                $new_key =~ s/\[x\]/"[$count]"/ge;
                $vars{$new_key} = $_;
                $count++;
            }
        } else {
            $key =~ s/\[x\]/"[$count]"/ge;
            $vars{$key} = $val;
        }

    }

    return build_cgi_struct \%vars, $errs, { dclone => 0 };
}

sub AnyEvent::HTTPD::Request::respond_403 {
    my ($self) = @_;

    $self->respond([ 403 => 'Forbidden',
                    { 'Content-Type' => 'text/plain' },
                      'Not enough permissions' ]);
    ()
}

sub AnyEvent::HTTPD::Request::respond_403_with_logout {
    my ($self) = @_;

    my $html = q{
    <pre>Not enough permissions. <a href="/lema/v1/logout">Logout</a></pre>
};

    $self->respond([ 403 => 'Forbidden',
                    { 'Content-Type' => 'text/html' },
                      $html ]);
    ()
}

sub AnyEvent::HTTPD::Request::respond_401 {
    my ($self) = @_;
    my $realm = "Authentication Required";
    $self->respond([ 401 => 'Unauthorized',
                    { 'Content-Type' => 'text/plain',
                      'WWW-Authenticate' => 'Basic realm="' . $realm . '", charset="UTF-8"',
                    }, 'Unauthorized' ]);
    ()
}

sub AnyEvent::HTTPD::Request::response {
    my $self = shift;
    if (@_) {
        croak "Response is not valid ISA"
            unless $_[0]->$_isa('LEMA::HTTPD::Extended::Response');

        return $self->{response} = $_[0];
    }

    unless ($self->{response}) {
        $self->{response} = LEMA::HTTPD::Extended::Response->new;
        $self->{response}->username($self->{username});
        $self->{response}->role($self->{role});
    }

    return $self->{response};
}

sub AnyEvent::HTTPD::Request::restricted_area {
    @_ > 1 ? ($_[0]{restricted_area} = !!$_[1]) : !!$_[0]{restricted_area};
}

sub AnyEvent::HTTPD::Request::username {
    @_ > 1 ? ($_[0]{username} = $_[1]) : $_[0]{username};
}

sub AnyEvent::HTTPD::Request::role {
    @_ > 1 ? ($_[0]{role} = $_[1]) : $_[0]{role};
}

sub AnyEvent::HTTPD::Request::finish_response {
    my ($self) = @_;
    my $resp = $self->{response};

    croak "No response created" unless $resp;

    my $err;
    try {
        $self->respond([ $resp->code => $resp->status,
                         $resp->get_headers,
                         $resp->get_output ]);
    } catch {
        warn $_;
        $self->respond_500;
    };

    ()
}

sub ERROR_404() {  \& ERROR_404 }
sub throw_404() { die ERROR_404 }

sub AnyEvent::HTTPD::Request::respond_404 {
    my ($self) = @_;

    $self->respond([ 404 => 'Not Found',
                    { 'Content-Type' => 'text/plain' },
                    'Not Found' ]);
    ()
}

sub AnyEvent::HTTPD::Request::respond_401 {
    my ($self, $realm) = @_;
    if (!length $realm || $realm =~ /\"/) {
        $realm = "Authorization Required";
    }

    $self->respond([ 401 => 'Unauthorized',
                    { 'Content-Type'     => 'text/plain',
                      'WWW-Authenticate' => 'Basic realm="' . $realm . '", charset="UTF-8"',
                    }, 'Unauthorized' ]);
    ()
}

sub AnyEvent::HTTPD::Request::respond_500 {
    my ($self) = @_;

    $self->respond([ 500 => 'Internal Error',
                    { 'Content-Type' => 'text/plain' },
                    'Internal Error' ]);
    ()
}

sub AnyEvent::HTTPD::Request::respond_302 {
    my ($self, $location) = @_;

    Carp::croak "Invalid location for 302 redirect"
        unless !ref $location && length $location;

    $self->respond([ 302 => 'Found',
                    { 'Location' => $location },
                    'Redirect' ]);
    ()
}


sub request_cb {
    my $self = shift;

    for (my $i = 0; $i < @_; $i += 2) {
        my $cb = $_[$i + 1];

        $self->reg_cb($_[$i] => sub {
            my ($httpd, $req) = @_;
            my $debug_on = $httpd->{_DEBUG} ? 1 : 0;

            unless ($debug_on) {
                my %vars = $req->vars;
                if ($vars{debug}) {
                    $debug_on = 1;
                }
            }

            $req->response->debug($debug_on);

            try {
                $cb->($httpd, $req);
            }
            catch {
                $httpd->stop_request;

                if (ref $_ eq 'CODE' && $_ eq ERROR_404) {
                    $req->respond_404($req);
                    return;
                }

                if ($req->responded) {
                    AE::log error => "Request responded, log exception: `%s'",
                                     $_;
                    return;
                }

                my $resp = $req->response->success(0);

                if (ACME::E::is_e) {
                    AE::log debug => "Exception (user error): %s", $_;

                    $resp->error(0+$_);
                    $resp->detail('' . $_);

                    if (!$resp->json && !defined $resp->template) {
                        $resp->template('/50x.tmpl');
                    }
                }
                elsif ($_->$_isa('QuickBooks::Objects::Fault')) {
                    AE::log debug => "Exception (QBO error): %s", $_;

                    $resp->error(1);
                    $resp->detail($_->Error->[0]{Detail});

                    if (!$resp->json && !defined $resp->template) {
                        $resp->template('/50x.tmpl');
                    }
                }
                else {
                    AE::log error => "Exception (app error): %s", $_;

                    $resp->detail('' . $_);
                    $resp->template('/50x.tmpl')
                }

                $resp->reply(version => $LEMA::VERSION);

                try {
                    $req->finish_response;
                } catch {
                    AE::log error => "Couldn't respond: `%s'", $_;
                    $req->respond_500($req);
                };
            };
        });
    }

    ()
}

1;
