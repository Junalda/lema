package LEMA::Web::cache2;
use common::sense;
use Carp;
use Scalar::Util;

sub cache {
    my $self = shift;
    $self->{cache} ||= +{};
}

sub cache_get { $_[0]->cache }

sub cache_get_as_aref {
    my $self = shift;
    my $href = $self->cache_get;
    my @array;
    for (sort { $a->Id <=> $b->Id } values %$href) {
        push @array, $_;
    }
    return \@array;
}

sub cache_available { defined $_[0]{cache} }

sub cache_remove {
    my ($self, $id) = @_;
    die "Invalid object ID" unless $id =~ /^\d+$/;
    delete $self->cache->{$id};
    ()
}

sub cache_set {
    my ($self, $obj) = @_;
    die "Object to store in cache is not blessed"
        unless Scalar::Util::blessed($obj);
    my $id = $obj->Id;
    $self->cache->{$id} = $obj;
    ()
}

sub cache_set_all {
    my ($self, $aref) = @_;
    die "Invalid array ref with object to cache" unless ref $aref eq 'ARRAY';
    for (@$aref) {
        $self->cache_set($_);
    }
    ()
}

sub cache_find_strict {
    my ($self, $id) = @_;
    die "No transaction ID\n" unless length $id;
    my $obj = $self->cache->{$id};
    die "Transaction is not found\n" unless $obj;
    return $obj;
}

sub cache_find {
    my ($self, $id) = @_;
    my $obj = $self->cache->{$id};
    return $obj // undef;
}

sub cache_find_by_doc_number {
    my ($self, $doc_number) = @_;
    die "Invalid document number\n"
        unless !ref $doc_number && length $doc_number;

    my $cache = $self->cache;
    for (values %$cache) {
        if ($_->DocNumber eq $doc_number) {
            return $_;
        }
    }

    return undef;
}

1;

__DATA__


sub CLEAN_ALL() {
    %CACHE = ();
    ()
}

sub cache_clean {
    my $self = shift;
    $CACHE{$self} = [];
    ()
}

sub cache_size {
    my $self = shift;
    my $cache = $CACHE{$self};
    return scalar @$cache;
}

sub cache_set {
    my ($self, $data) = @_;
    $CACHE{$self} = $data;
    ()
}

sub cache_get {
    my ($self) = @_;
    my $ret = $CACHE{$self} //= [];
    $CACHE{$self} = [];
    return $ret;
}

1;
