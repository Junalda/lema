package LEMA::Web::Index;
use common::sense;
use Carp;
use Data::Dumper;

sub new {
    my ($class, %args) = @_;
    bless \%args, $class
}

sub main {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my $resp = $req->response->template('/index/index.tmpl');

    my %uptime = (
    );

    $resp->reply(#logs    => $logs,
                 version => $LEMA::VERSION);

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Index app called (%s %s)", $req->method, $req->url;
        $httpd->stop_request;

        if ($req->url =~ m!/lema/v1/index(\?|$)!) {
            $self->main($httpd, $req);
        }
        else {
            $req->respond_302("/lema/v1/index");
        }

        $httpd->stop_request;
        ()
    }
}

1;
