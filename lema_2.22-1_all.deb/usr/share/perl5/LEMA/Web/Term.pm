package LEMA::Web::Term;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    $self->cache;
    ()
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->term->query;
    } catch {
        die $_;
    };

    $self->cache_set_all(\@items);
    return \@items;
    ()
}

sub existing_terms {
    my $self = shift;
    return $self->cache_get_as_aref;
}

1;
