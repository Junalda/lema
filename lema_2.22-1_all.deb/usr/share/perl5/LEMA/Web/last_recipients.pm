package LEMA::Web::base;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use ACME::Claim;

sub last_recipients {
    my ($self, $httpd, $req, $partner_type, $partner_id, $customer_sub_id, $u_or_e) = @_;
    $partner_id += 0;

    claim { $partner_id >= 0 };
    claim { $partner_type eq 'customer' || $partner_type eq 'supplier' };
    claim { $u_or_e eq 'u' || $u_or_e eq 'e' };

    return 0 if $req->method ne 'GET';

    my $resp = $req->response->json(1);
    die "No partner ID" unless length $partner_id;

    my $recp;
    if ($partner_type eq 'customer') {
        $recp = $self->app->db->properties
                          ->get_last_recipients_for_invoice($partner_id,
                                                            $customer_sub_id);
    } elsif ($partner_type eq 'supplier') {
        $recp = $self->app->db->properties
                          ->get_last_recipients_for_purchase_order($partner_id);
    } else {
        die "Partner ID is not supported";
    }


    if ($u_or_e eq 'u') {
        if (!$recp || !$recp->[1] || !$recp->[1]->count) {
        } else {
            $resp->reply(recipients => $recp->[1]->addresses_line_fmt);
        }
    } else {
        my $ok = 1;
        if (!$recp || !$recp->[0] || !$recp->[0]->count) {

                $ok = 0;
        }

        $resp->reply(recipients => $recp->[0]->addresses_line_fmt)
            if $ok;
    }

    $resp->success(1);
    $req->finish_response;
    1
}

1;
