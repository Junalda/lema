package LEMA::Web::Preferences;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    ()
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->preferences->query;
    } catch {
        die $_;
    };

    die "Couldn't get QBO company preferences\n"
        unless $items[0];

    return $self->{_preferences} = $items[0];
}

sub preferences {
    my $self = shift;
    die "No QBO company preferences\n" unless $self->{_preferences};
    return $self->{_preferences};
}

1;
