package LEMA::Web::Suppliers;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use Digest::CRC qw(crc32);
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

our $SINGLETON;

sub _main_template { '/suppliers/main.tmpl' }
sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    $self->cache;
    ()
}

sub fetch {
    my ($self, $id) = @_;
    my $obj = $self->app->qbo->vendor->query_by_id($id);
    $self->app->db->agents->populate($obj);
    $self->cache_set($obj);
    return $obj;
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->vendor->query;
    } catch {
        die $_;
    };

    for (@items) {
        $self->app->db->agents->populate($_);
    }

    $self->cache_set_all(\@items);
    return \@items;
}

sub show_insert_form {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/suppliers/new.tmpl');
    $resp->success(1);
    $req->finish_response;
    1
}

sub insert {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);

    die "Display Name must be defined\n"
        unless length $vars->{DisplayName};

    my $addresses = delete $vars->{addresses};
    my $bank   = delete $vars->{bank};
    my $vendor = QuickBooks::Objects::Vendor->new_mod($vars);
    my $agent  = $self->app->db->agents->build($addresses, $bank);
    my $vendor = $self->app->qbo->vendor->create($vendor);

    $self->app->db->agents->bind($vendor => $agent);
    $self->cache_set($vendor);

    $resp->reply(supplier => $vendor)->success(1);
    $req->finish_response;
    1
}

sub view {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'GET';

    my %vars   = $req->vars;
    my $resp   = $req->response->template('/suppliers/view.tmpl');
    my $vendor = $self->cache_find_strict($id);

    $resp->reply(supplier => $vendor)->success(1);
    $req->finish_response;
    1
}

sub update {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);

    my $addresses = delete $vars->{addresses};
    my $bank   = delete $vars->{bank};
    my $vendor = QuickBooks::Objects::Vendor->new_mod($vars);
    my $agent  = $self->app->db->agents->build($addresses, $bank);
    my $vendor = $self->app->qbo->vendor->update($vendor);

    $self->app->db->agents->bind($vendor => $agent);
    $self->cache_set($vendor);

    $resp->reply(supplier => $vendor)->success(1);
    $req->finish_response;
    1
}

sub build_array {
    my ($self, $txn) = @_;
    my ($partner_id, $partner_sub);
    if ($txn) {
        die "Invalid transaction object: $txn"
            unless $txn->$_isa('LEMA::Object::Bill');
        $partner_id = $txn->VendorRef->value;
        if ($txn->properties) {
            $partner_sub = $txn->properties->doc_sub // undef;
        }
    }

    my $href = $self->cache;
    my @suppliers;
    for my $h (sort { $a->DisplayName cmp $b->DisplayName } values %$href) {
        my $country = $h->country;
        my $emails  = $h->PrimaryEmailAddr
                    ? $h->PrimaryEmailAddr->Address
                    : undef;

        my $basename = sprintf(length $country ? "%s (%s)" : "%s",
                            $h->DisplayName, $country);
        my %hash = (
            id    => $h->Id,
            label => $basename,
            selected => undef,
            vat_number => $h->TaxIdentifier,
            emails   => $emails,
        );

        if ($ENV{SC_LEVEL}) {
            $hash{destname}    = "Your Company";
            $hash{country}     = "Country";
            $hash{address}     = "Main Road 123";
            $hash{city}        = "Barendrecht";
            $hash{state}       = "QQ";
            $hash{postal_code} = "12345";

        } else {
            $hash{destname}    = "B & L Fruit Logistics BV";
            $hash{country}     = "NL";
            $hash{address}     = "Koopliedenweg 28";
            $hash{city}        = "Barendrecht";
            $hash{state}       = "LN";
            $hash{postal_code} = "2991";
        }


        if ($partner_id && !$partner_sub) {
            $hash{selected} = 1 if $partner_id == $h->Id;
        }

        my $agent;
        if ($h->{reserved} && $h->{reserved}{agent}) {
            $agent = $h->{reserved}{agent};
            if ($agent->bank) {
                if ($h->AcctNum) {
                    $agent->bank->account_iban($h->AcctNum);
                }
                $hash{bank} = $agent->bank->format;
            }
        }
        unless ($hash{bank}) {
            if ($h->AcctNum) {
                $hash{bank} = "IBAN: " . $h->AcctNum;
            }
        }

        push @suppliers, \%hash;

        next unless $h->{reserved} && $h->{reserved}{agent};

        my $agent = $h->{reserved}{agent};
        $hash{eori} = $agent->eori;

        next unless $agent->addresses->count;

        my $selected = $partner_id ? $partner_id == $h->Id : 0;

        my $found_sub_addr = $partner_sub ? 0 : undef;
        $agent->addresses->enum(sub {
            my $addr = shift;
            my %copy = %hash;
            my $idx  = crc32($addr->{reserved}{name});
            $copy{label} = $basename . ': Location: ' . $addr->{reserved}{name};

            $copy{destname}    = $addr->{reserved}{name};
            $copy{address}     = $addr->address_lines_fmt;
            $copy{city}        = $addr->City;
            $copy{state}       = $addr->CountrySubDivisionCode;
            $copy{postal_code} = $addr->PostalCode;
            $copy{country}     = $addr->Country;
            $copy{id}          = $copy{id} . '.' . $idx;

            if ($selected && $partner_sub && $partner_sub == $idx) {
                $copy{selected} = 1;
            } else {
                $copy{selected} = 0;
            }

            push @suppliers, \%copy;
        });

        if (defined $found_sub_addr && $found_sub_addr == 0) {
            $hash{selected} = 1 if $partner_id == $h->Id;
        }

    }
    @suppliers = sort { $a->{label} cmp $b->{label} } @suppliers;
    return \@suppliers;
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;

        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/(\d+)(\?|$)!) {
            $ok = $self->view($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/(\d+)(\?|$)!) {
            $ok = $self->update($httpd, $req, $1);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/new(\?|$)!) {
            $ok = $self->show_insert_form($httpd, $req);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/new(\?|$)!) {
            $ok = $self->insert($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
