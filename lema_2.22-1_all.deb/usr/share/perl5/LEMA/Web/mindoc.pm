package LEMA::Web::mindoc;
use common::sense;

sub _get_next_docnumber {
    my ($self, $txndate) = @_;
    die "Invalid order date\n" unless $txndate =~ /^(\d{4})-\d{2}-\d{2}$/;
    my $year = $1;
    my $href = $self->cache_get;
    my $max  = 0;
    for (values %$href) {
        my $docnum = $_->DocNumber;
        next unless $docnum =~ /^(\d{4})-(\d{4,})$/;
        my ($year_cand, $max_cand) = ($1, $2);
        next unless $year_cand == $year;

        if ($max_cand > $max) {
            $max = $max_cand;
        }
    }

    my $next = sprintf "%04d-%04d", $year, $max + 1;
    return $next;
}

1;
