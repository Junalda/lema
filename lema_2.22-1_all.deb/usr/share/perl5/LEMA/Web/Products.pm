package LEMA::Web::Products;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use LEMA::Object::ExtendedItem;
use LEMA::Web::Accounts;
use ACME::Claim;
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::cache_obj
              LEMA::Web::contragent);
use ACME::E;

sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all_inventory_summary;
    $self->cache_obj;
    $self->fetch_all;
    $self->cache;

    my $self_w = $self;
    Scalar::Util::weaken($self_w);

    unless ($ENV{LEMA_NO_INVENTORY_WATCH}) {
        $self_w->{_w} ||= AE::timer 0, 20, sub {
            return unless $self_w && $self_w->{_w};
            $self_w->fetch_all_inventory_summary;
            ()
        };
    }
    ()
}

sub fetch_all_inventory_summary {
    my $self = shift;
    my @items;

    try {
        @items = $self->app->qbo->inventory->query;
    } catch {
        die $_;
    };

    my $all_products = $self->cache;
    my @new;

    for my $product (sort { $a->Id <=> $b->Id } values %$all_products) {
        claim { $product->$_isa('LEMA::Object::ExtendedItem') };
        my $inventory;


        for (@items) {
            if ($_->ProductsAndService eq $product->FullyQualifiedName) {
                $product->inventory($_);
                last;
            }
        }
    }

    $self->cache_obj_set('inventory', \@items);
    return \@items;
    ()
}

sub fetch {
    my ($self, $id) = @_;
    my $product = $self->app->qbo->item->query_by_id($id);
    my $summary = $self->cache_obj_find('inventory');
    my $inventory;

    for (@$summary) {
        if ($_->ProductsAndService eq $product->FullyQualifiedName) {
            $inventory = $_;
            last;
        }
    }

    LEMA::Object::ExtendedItem->from_qbo($product);
    $product->inventory($inventory) if $inventory;

    $self->cache_set($product);
    return $product;
}

sub fetch_all {
    my $self = shift;
    my @items;

    try {
        @items = $self->app->qbo->item->query;
    } catch {
        die $_;
    };

    for my $product (@items) {
        LEMA::Object::ExtendedItem->from_qbo($product);
    }

    $self->cache_set_all(\@items);

    $self->fetch_all_inventory_summary;
    return \@items;
}





sub main {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;

    $vars{sort} = "FullyQualifiedName";

    local *_main_template = sub { '/products/main.tmpl' };
    local *_allowed_sort = sub {
        return qr{^(FullyQualifiedName)$};
    };

    local *_filter = sub {
        return 1 unless defined $_[2];
        $_[1]->FullyQualifiedName =~ $_[2]
    };

    return $self->SUPER::main($httpd, $req, \%vars);
}

=head1
sub show_insert_form {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/products/new.tmpl');

    my @array;
    my $products = $self->app->db->predefined_products->find_by_type('products');
    $products->populate_to_array(\@array) if $products;

    $resp->reply(products => \@array);
    $resp->success(1);

    $req->finish_response;
    1
}
=cut

sub _row_to_product_description {
    my ($self, $row) = @_;

    for (qw(product variety size origin category state weight)) {
        $row->{$_} =~ s/^\s+//;
        $row->{$_} =~ s/\s+$//;

        if ($row->{$_} =~ m!/!) {
            die "Product properties cannot contain character '/'\n";
        }
    }

    my $is_extra_defined = 0;
    for (qw(variety size origin category state weight origin)) {
        $is_extra_defined = 1 if length $row->{$_};
    }

    die "No product name defined\n"    unless length $row->{name};

    if ($is_extra_defined) {
        die "No variety defined\n"         unless length $row->{variety};
        die "No size defined\n"            unless length $row->{size};
        die "No product country defined\n" unless length $row->{origin};
        die "No category defined\n"        unless length $row->{category};
        die "No organic state defined\n"   unless length $row->{state};
        die "No box weight defined\n"      unless length $row->{weight};
        die "Invalid product origin"       unless length $row->{origin} == 2;


        return sprintf "%s/%s/%s/%s/%s/%s",
                       $row->{variety},  $row->{size},
                       $row->{origin},  $row->{category}, $row->{state},
                       $row->{weight};
    }
    else {
        return undef;
    }
}

=head1
sub insert {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my %vars = $req->vars;
    my $resp = $req->response->json(1);
    $resp->reply(version => $LEMA::VERSION);

    die "Quantity on hands must be defined\n"
        unless $vars{QtyOnHand} =~ /^\d+$/;

    for (qw(product variety size origin category state weight)) {
        my $label = $_;
        $label = "name" if $label eq "product";
        die "Product $label is not specified\n" unless length $vars{$_};
    }

    die "Invalid product origin\n"
        unless length $vars{origin} == 2;

    $vars{Name} = $self->_row_to_product_name(\%vars);

    my $product;
    if (1 || $self->app->db->settings->active_profile->qbo->inventory) {
        $product = QuickBooks::Objects::Item->new(
                   Name               => $vars{Name},
                   ExpenseAccountRef  => { value => 80 },
                   Type               => 'Inventory',
                   IncomeAccountRef   => { value => 79 },
                   TrackQtyOnHand    => 1,
                   QtyOnHand         => $vars{QtyOnHand},
                   InvStartDate      => '2000-01-01',
                   AssetAccountRef   => { value => 81 },
        );
    }
    else {
        die "Non-inventory QBO products are not supported\n";
        $product = QuickBooks::Objects::Item->new(
                   Name               => $vars{Name},
                   ExpenseAccountRef  => { value => 80 },
                   Type               => 'NonInventory',
                   IncomeAccountRef   => { value => 79 },
                   TrackQtyOnHand    => 1,
        );
    }

    my $product_created = $self->app->qbo->item->create($product);

    $resp->reply(product => $product_created)->success(1);
    $req->finish_response;
    1
}
=cut

sub view {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/products/view.tmpl');
    $resp->reply(version => $LEMA::VERSION);
    my $product = $self->cache_find_strict($id);


    my @array;
    my $products = $self->app->db->predefined_products->find_by_type('products');
    $products->populate_to_array(\@array) if $products;

    $resp->reply(products => \@array);
    $resp->reply(product  => $product)->success(1);
    $req->finish_response;
    1
}

=head1
sub update {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my %vars = $req->vars;
    my $resp = $req->response->json(1);
    $resp->reply(version => $LEMA::VERSION);

    die "No ID of product to change\n"
        unless $vars{Id} =~ /^\d+$/;

    die "Quantity on hands must be defined\n"
        unless $vars{QtyOnHand} =~ /^\d+$/;


    $vars{Name} = $self->_row_to_product_name(\%vars);


    my $product = QuickBooks::Objects::Item->new(
               Id                 => $vars{Id},
               Name               => $vars{Name},
               ExpenseAccountRef  => { value => 80 },
               Type               => 'Inventory',
               IncomeAccountRef   => { value => 79 },
               TrackQtyOnHand    => 1,
               QtyOnHand         => $vars{QtyOnHand},
               InvStartDate      => '2000-01-01',
               AssetAccountRef   => { value => 81 },
    );

    my $product = $self->app->qbo->item->update($product);

    $resp->reply(product => $product)->success(1);
    $req->finish_response;
    1
}
=cut

sub existing_products {
    my ($self) = @_;

    my %product;
    my %category;
    my %state;
    my %variety;

    my $all = $self->cache;



    for (values %$all) {
        next unless $_->Type eq 'Service' || $_->Type eq 'Inventory';
        $product{$_->FullyQualifiedName} = 1;
    }

    my $all = LEMA::Web::cache_with_product->products;

    for (values %$all) {
        $product{$_->{item}{name}} = 1;
        $category{$_->{item}{category}} = 1;
        $state{$_->{item}{state}} = 1;
        $variety{$_->{item}{variety}} = 1;
    }

    my $all_predefined = $self->app->db->predefined_products->find_all;

    $all_predefined->{products}->populate_to_hash(\%product)
        if $all_predefined->{products};
    $all_predefined->{categories}->populate_to_hash(\%category)
        if $all_predefined->{categories};
    $all_predefined->{states}->populate_to_hash(\%state)
        if $all_predefined->{states};
    $all_predefined->{varieties}->populate_to_hash(\%variety)
        if $all_predefined->{varieties};

    return {
        product  => [ sort keys %product  ],
        category => [ sort keys %category ],
        state    => [ sort keys %state    ],
        variety  => [ sort keys %variety  ],
    };
}

sub populate_items_value {
    my ($self, $items_aref, %args) = @_;
    die "Invalid items array" unless ref $items_aref eq 'ARRAY';
    die "Items hash is empty" unless @$items_aref;

    my $all = $self->cache;

    my $inventory = $self->app->db->settings->active_profile->inventory;
    unless ($inventory) {
        die "Accounts for inventory products (WD) are not defined. " .
            "Please set them in the Settings.\n";
    }
    my $dd_inventory = $self->app->db->settings->active_profile->dd_inventory;
    unless ($dd_inventory) {
        die "Accounts for inventory products (DD) are not defined. " .
            "Please set them in the Settings.\n";
    }

    for my $item_ref (@$items_aref) {
        my $item_name = $item_ref->{name};
        my $is_dfs   = !!($item_name =~ /\sDFS$/i || $item_name =~ /^DFS\s/i || $item_name =~ /^DD\:/i);
        my $found    = 0;

        for my $product (sort { $a->Id <=> $b->Id } values %$all) {
            if ($product->FullyQualifiedName eq $item_name) {
                $item_ref->value($product->Id);
                $found = $product;
            }
        }

        if ($found) {
            if ($item_ref->{_for_stock}) {
                my $must_income  = $is_dfs ? $dd_inventory->income_account
                                           : $inventory->income_account;
                my $must_expense = $is_dfs ? $dd_inventory->expense_account
                                           : $inventory->expense_account;
                my $must_asset   = $is_dfs ? $dd_inventory->asset_account
                                           : $inventory->asset_account;

                die "Product $item_name has invalid income account for inventory\n"
                    if $found->IncomeAccountRef && $found->IncomeAccountRef->value != $must_income;
                die "Product $item_name has non-inventory expense account for inventory\n"
                    if $found->ExpenseAccountRef && $found->ExpenseAccountRef->value != $must_expense;
                die "Product $item_name has non-inventory asset account for inventory\n"
                    if $found->AssetAccountRef && $found->AssetAccountRef->value != $must_asset;
            }
            next;
        }

        if ($args{-die_if_not_found}) {
            if ($item_ref->{_for_stock}) {
                die sprintf "Inventory product with the name '%s' is not found\n", $item_name;
            }

            die "Non-inventory product with the name '$item_ref->{name}' " .
                "doesn't exist. SMAPP doesn't know anything about " .
                "accounts of for this product. That's why it can't " .
                "create it.\n";
        }

        AE::log info => "Product with name %s is not found; create...",
                        $item_name;

        unless ($item_ref->{_for_stock}) {
            die "Non-inventory product with the name '$item_ref->{name}' " .
                "doesn't exist. SMAPP doesn't know anything about " .
                "accounts for this product. That's why SMAPP can't " .
                "create it.\n";
        }

        my $product;
        if ($is_dfs) {
            $product = QuickBooks::Objects::Item->new(
                   Name              => $item_name,
                   Type              => 'Inventory',
                   TrackQtyOnHand    => 1,
                   QtyOnHand         => 0,
                   InvStartDate      => '2000-01-01',
                   IncomeAccountRef  => { value => $dd_inventory->income_account },
                   ExpenseAccountRef => { value => $dd_inventory->expense_account },
                   AssetAccountRef   => { value => $dd_inventory->asset_account },
            );
        } else {
            $product = QuickBooks::Objects::Item->new(
                   Name              => $item_name,
                   Type              => 'Inventory',
                   TrackQtyOnHand    => 1,
                   QtyOnHand         => 0,
                   InvStartDate      => '2000-01-01',
                   IncomeAccountRef  => { value => $inventory->income_account },
                   ExpenseAccountRef => { value => $inventory->expense_account },
                   AssetAccountRef   => { value => $inventory->asset_account },
            );
        }

        my $product = $self->app->qbo->item->create($product);
        AE::log info => "Product %s got ID %s", $item_name, $product->Id;
        $self->fetch($product->Id);
        $item_ref->value($product->Id);
    }

    ()
}

sub main_properties {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/products/properties.tmpl');

    my $all = $self->app->db->predefined_products->find_all;
    $resp->reply(predefined => $all);

    $resp->success(1);
    $req->finish_response;
    1
}

sub change_properties {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my %vars = $req->vars;
    my $resp = $req->response->json(1);

    for (qw(products varieties categories states)) {
        my $doc = LEMA::DB::PredefinedProducts::Doc->new({
                    type => $_,
                    lines => $vars{$_},
        });
        $self->app->db->predefined_products->upsert($doc);
    }

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;


        my $ok;
        if ($req->url =~ m!/lema/v1/products(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/products/properties(\?|$)!) {
            $ok = $self->main_properties($httpd, $req);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/products/properties(\?|$)!) {
            $ok = $self->change_properties($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/products/(\d+)(\?|$)!) {
            $ok = $self->view($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/products/(\d+)(\?|$)!) {
            $ok = $self->update($httpd, $req, $1);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
