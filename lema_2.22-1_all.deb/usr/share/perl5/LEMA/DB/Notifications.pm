package LEMA::DB::Notifications;
BEGIN { our $VERSION = 0.01; }

package LEMA::DB::Notifications::File;
use common::sense;
use boolean;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use Woof;
use ACME::Data;
use ACME::Claim;
use ACME::E;

PUBLIC (package  => OF 'str_ne')  = __PACKAGE__;
PUBLIC (version  => OF 'float')   = $LEMA::DB::Notifications::VERSION;
PUBLIC (size     => UNDEFOK OF 'int') = undef;
PUBLIC (is_utf8  => OF 'boolean') = sub { boolean::false };
PUBLIC (octets   => UNDEFOK OF 'strnull') = undef;

PUBLIC (type     => UNDEFOK OF 'strnull') = undef;
PUBLIC (name     => UNDEFOK OF 'strnull') = undef;

sub PRUNE();
sub PRUNE() { \&PRUNE; }

sub _octets_ {
    my $self = shift;
    VALIDATE;

    if ($_[0] =~ /[^\x00-\xff]/) {
        my $utf8 = $_[0];
        utf8::encode($utf8);
        $self->is_utf8(1);
        $self->size(length($utf8) || 0) unless defined $self->size;
        return $utf8;
    } else {
        $self->size(length($_[0]) || 0) unless defined $self->size;
        return $_[0];
    }
}

sub extension {
    my $self = shift;
    my $type = $self->type;
    return 'html' if $type =~ m!/html$!i;
    return 'pdf'  if $type =~ m!/pdf$!i;
    die sprintf "Couldn't determine file extension from content type '%s'\n",
                $type;
    ()
}

sub name_with_extension {
    my $self = shift;
    return sprintf "%s.%s", $self->name, $self->extension;
}

package LEMA::DB::Notifications::Files;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;
use ACME::Claim;
our $MAX_FILES_SIZE = 10 * 1024 * 1024;
PUBLIC (package => OF 'str_ne') = __PACKAGE__;
PUBLIC (version => OF 'float')  = $LEMA::DB::Notifications::VERSION;
PUBLIC (count   => OF 'int')    = 0;
PUBLIC (list    => OF 'ARRAY')  = sub { [] };

sub _list_ {
    my ($self, $in) = @_;
    VALIDATE;
    if (ref $in eq 'CODE') { $in = $in->(); }

    my $size = 0;
    my @new;
    for my $el (@$in) {
        my $file = LEMA::DB::Notifications::File->new($el);
        $size += $file->size;
        if ($size > $MAX_FILES_SIZE) {
            die "Total file size in notification is more than 10 MB\n";
        }
        push @new, $file;
    }

    $self->count(scalar @new);
    return \@new;
}

sub enum {
    my ($self, $cb) = @_;
    if ($self->count) {
        for my $el (@{$self->list}) {
            my $copy = $el;
            my $ret  = $cb->($copy);

            if ($copy ne $el && $copy->$_isa('LEMA::DB::Notifications::File')) {
                my $diff = $copy->size - $el->size;
                if ($diff > 0) {
                }
                $el = $copy;
            }

            if ($ret eq $el->PRUNE) {
                last;
            }
        }
    }
    ()
}

sub remove_octets {
    my $self = shift;
    $self->enum(sub {
        my $el = shift;
        delete $el->{octets};
    });
    ()
}

sub attachment {
    my $self = shift;
    my $idx  = 0;
    my @array;
    $self->enum(sub {
        my $el = shift;
        push @array, { name  => $el->name,
                       size  => $el->size,
                       type  => $el->type,
                       extension => $el->extension,
                       index => $idx };
        $idx++;
        ()
    });

    return @array ? \@array : undef;
}

package LEMA::DB::Notifications::Doc;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use AnyEvent;
use Try::Tiny;
use ACME::Object::Users;
use ACME::Object::SMTP;
use LEMA::DB::Properties;
use ACME::Claim;
use Woof;

PUBLIC (_id          => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (doc_number   => OF 'num');
PUBLIC (doc_type     => OF 'num');
PUBLIC (doc_ref      => UNDEFOK OF 'strnull') = undef;
PUBLIC (recipients_e => UNDEFOK OF 'LEMA::DB::Properties::Recipients') = undef;
PUBLIC (recipients_u => UNDEFOK OF 'LEMA::DB::Properties::Recipients') = undef;
PUBLIC (trigger      => OF 'num');
PUBLIC (partner_id   => OF 'num');
PUBLIC (created_on   => OF 'float')   = sub { AE::time };
PUBLIC (revision     => OF 'num');
PUBLIC (files        => OF 'LEMA::DB::Notifications::Files');
PUBLIC (sending_on   => UNDEFOK OF 'float');
PUBLIC (subject      => UNDEFOK OF 'strnull') = undef;
PUBLIC (message      => UNDEFOK OF 'strnull') = undef;
PUBLIC (updated_on   => UNDEFOK OF 'float')   = undef;
PUBLIC (success      => UNDEFOK OF 'boolean') = undef;
PUBLIC (error        => UNDEFOK OF 'strnull') = undef;

sub _doc_number {
    my ($self, $in) = @_;
    VALIDATE;
    LEMA::check_id($in);
    return $in;
}

sub _doc_type {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid document type for properies\n"
        unless $in == LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER ||
               $in == LEMA::DB::Properties::Doc::TYPE_INVOICE ||
               $in == LEMA::DB::Properties::Doc::TYPE_ADJUST;
    return $in;
}

sub _partner_id_ {
    my ($self, $in) = @_;
    VALIDATE;
    die "Partner/contragent ID must be greater than 0\n"
        unless $in > 0;
    return $in;
}

sub _trigger_ {
    my ($self, $in) = @_;
    VALIDATE;
    try {
        LEMA::DB::Properties::Recipient::validate_trigger($in);
    } catch {
        $in = LEMA::DB::Properties::Doc::ORDER_ISSUED;
    };
    $self->_define_triggered_recipients($in);
    return $in;
}

sub _data_ {
    my $self = shift;
    VALIDATE;
    die "Notification data is more than 5MB\n"
        if length $_[0] > 1024 * 1024 * 5;
    return $_[0];
}

sub _revision_ {
    my $self = shift;
    VALIDATE;
    die "Revision number must be greater than 0\n"
        unless $_[0] >= 1;
    return $_[0];
}

sub created_on_fmt {
    return ACME::Data::localtime_tz($_[0]->created_on);
}

sub updated_on_fmt {
    return undef unless $_[0]->updated_on;
    return ACME::Data::localtime_tz($_[0]->updated_on);
}


sub trigger_fmt {
    my $self = shift;
    return LEMA::DB::Properties::Doc::order_status_to_string($self->trigger);
}

sub _define_triggered_recipients {
    my ($self, $trigger) = @_;
    $trigger += 0;
    die "No trigger in arguments\n" unless $trigger =~ /^\d+$/;
    if ($self->recipients_e) {
        $self->recipients_e->enum(sub {
            my $recp = shift;
            $recp->triggered(1) if $recp->is_triggered($trigger);
        });
    }

    if ($self->recipients_u) {
        $self->recipients_u->enum(sub {
            my $recp = shift;
            $recp->triggered(1) if $recp->is_triggered($trigger);
        });
    }
    ()
}

sub has_recipients {
    my $self = shift;
    my $has  = 0;

    if ($self->recipients_e) {
        $self->recipients_e->enum(sub {
            my $recp = shift;
            if ($recp->is_triggered($self->trigger)) {
                $has = 1;
                return $recp->PRUNE;
            }
        });
    }

    return 1 if $has;

    if ($self->recipients_u) {
        $self->recipients_u->enum(sub {
            my $recp = shift;
            if ($recp->is_triggered($self->trigger)) {
                $has = 1;
                return $recp->PRUNE;
            }
        });
    }

    return $has;
}

sub get_usernames_for_emails {
    my $self = shift;
    my %usernames;

    if ($self->recipients_u) {
        $self->recipients_u->enum(sub {
            my $recp = shift;
            claim { $recp->is_username_type };
            if ($recp->is_triggered($self->trigger)) {
                unless (length $recp->email_link) {
                    $usernames{$recp->address}++;
                }
            }
        });
    }
    return %usernames ? [ sort keys %usernames ] : undef;
}

sub link_email_to_username {
    my ($self, $username, $email) = @_;
    die "No username is arguments" unless length $username;
    die "No email address to link with username" unless length $email;

    my $linked = 0;
    $self->recipients_u->enum(sub {
        my $recp = shift;
        claim { $recp->is_username_type };
        if ($recp->address eq $username) {
            $recp->email_link($email);
            $linked = 1;
        }
    });

    die "No username found to link email address\n" unless $linked;
    ()
}

sub link_error_to_username {
    my ($self, $username, $error) = @_;
    die "No username is arguments" unless length $username;

    my $linked = 0;
    $self->recipients_u->enum(sub {
        my $recp = shift;
        claim { $recp->is_username_type };
        if ($recp->address eq $username) {
            $recp->state(LEMA::DB::Properties::Recipient::STATE_ERROR);
            $recp->error($error);
            $linked = 1;
        }
    });

    die "No username found to link error\n" unless $linked;
    ()
}

sub email_to_fmt {
    my $self = shift;

    return undef unless $self->recipients_e || $self->recipients_u;
    return undef unless $self->recipients_e->count ||
                        $self->recipients_u->count;

    my $to;
    $to //= $self->recipients_e->get_email_to($self->trigger);
    $to //= $self->recipients_u->get_email_to($self->trigger);

    unless (defined $to) {
        my $bccs;
        $bccs = $self->recipients_e->get_email_bccs($self->trigger);
        if (defined $bccs) {
            $to = $bccs->[0];
        } else {
            $bccs = $self->recipients_u->get_email_bccs($self->trigger);
            if (defined $bccs) {
                $to = $bccs->[0];
            }
        }
    }

    return $to // undef;
}

sub email_bccs_fmt {
    my $self = shift;
    return undef
        unless $self->recipients_e->count || $self->recipients_u->count;

    my $to = $self->email_to_fmt;
    return undef unless $to;

    my $bccs_1 = $self->recipients_e->get_email_bccs($self->trigger);
    my $bccs_2 = $self->recipients_u->get_email_bccs($self->trigger);
    my %uniq;
    my @bccs;

    for (@$bccs_1) {
        next if exists $uniq{$_} || $_ eq $to;
        $uniq{$_}++;
        push @bccs, $_;
    }
    for (@$bccs_2) {
        next if exists $uniq{$_} || $_ eq $to;
        $uniq{$_}++;
        push @bccs, $_;
    }

    return @bccs ? \@bccs : undef;
}

sub email_ccs_fmt {
    my $self = shift;
    return undef
        unless $self->recipients_e->count || $self->recipients_u->count;

    my $to = $self->email_to_fmt;
    return undef unless $to;

    my $bccs = $self->email_bccs_fmt;

    my %ignore;
    if ($bccs) {
        $ignore{$_}++ for @$bccs;
    }

    my $ccs_1 = $self->recipients_e->get_email_ccs($self->trigger);
    my $ccs_2 = $self->recipients_u->get_email_ccs($self->trigger);
    my %uniq;
    my @ccs;

    for (@$ccs_1) {
        next if exists $uniq{$_} || $_ eq $to || exists $ignore{$_};
        $uniq{$_}++;
        push @ccs, $_;
    }
    for (@$ccs_2) {
        next if exists $uniq{$_} || $_ eq $to || exists $ignore{$_};
        $uniq{$_}++;
        push @ccs, $_;
    }

    return @ccs ? \@ccs : undef;
}

sub email_header_lines_fmt {
    my $self = shift;
    my $to   = $self->email_to_fmt;
    return undef unless $to;

    my $ccs  = $self->email_ccs_fmt;
    my $bccs = $self->email_bccs_fmt;

    my $lines = "TO: $to\n";
    if ($ccs) {
        $lines .= "CC: " . join(", ", @$ccs) . "\n";
    }

    if ($bccs) {
        $lines .= "BCC: " . join(", ", @$bccs) . "\n";
    }

    return $lines;
}

sub email_header_lines_hash {
    my $self = shift;
    my $to   = $self->email_to_fmt;
    return undef unless $to;

    my $ccs  = $self->email_ccs_fmt;
    my $bccs = $self->email_bccs_fmt;

    my %hash;
    $hash{to} = $to;
    if ($ccs) {
        $hash{cc} = join(", ", @$ccs);
    }

    if ($bccs) {
        $hash{bcc} = join(", ", @$bccs);
    }

    return \%hash;
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{created_on_fmt} = $_[0]->created_on_fmt;
    $res->{updated_on_fmt} = $_[0]->updated_on_fmt;
    return $res;
}

sub as_action {
    my $self = shift;
    my %action;
    my $headers = $self->email_header_lines_hash;
    unless ($headers) {

        return undef;
    }

    $action{headers}    = $headers;
    $action{id}         = $self->_id->hex;
    $action{attachment} = $self->files->attachment;
    $action{status_fmt} = $self->trigger_fmt;
    $action{status}     = $self->trigger;
    $action{doc_number} = $self->doc_number;
    $action{doc_type}   = $self->doc_type;
    $action{doc_ref}    = $self->doc_ref;
    return \%action;
}

sub make_key {
    my $self = shift;
    return sprintf "%s.%s", $self->doc_number;
                            $self->doc_type;
}

package LEMA::DB::Notifications;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::E;
use ACME::Claim;
use parent qw(LEMA::DB::base);

our $TABLE = 'notifications' . $LEMA::DB::TABLE_NAME_POSTFIX;

sub initialize {
    my ($self) = @_;

    my $indexes = $self->coll->indexes;
    $indexes->create_one([ doc_type  => 1, doc_number => 1 ]);
    $indexes->create_one([ success   => 1 ]);
    ()
}

sub usernames_to_emails {
    my ($self, $notification, %args) = @_;

    my $profile;
    my $usernames = $notification->get_usernames_for_emails;
    if ($usernames) {
        for my $username (@$usernames) {
            claim { $username =~ /^\@/ };
            $username  = substr $username, 1;
            $profile //= $self->db->settings->active_profile;
            try {
                my $email = $profile->users->get_email_by_username($username);
                unless (defined $email) {
                    die "Email is not defined for user $username\n";
                }
                $notification->link_email_to_username('@' . $username, $email);
            } catch {
                die "Couldn't create notification: $_" if $args{-die};
                $notification->link_error_to_username('@' . $username, $_);
            };
        }
    }
    ()
}

sub create_notification_from_invoice {
    my ($self, $inv, $files, $sending_on, $subject, $message, %args) = @_;
    die "Invalid invoice object"
        unless $inv->$_isa('LEMA::Object::Invoice');
    die "Invoice is not supported by LEMA SMAPP: " . $inv->error
        if defined $inv->error;

    my $notification = LEMA::DB::Notifications::Doc->new({
        doc_type     => LEMA::DB::Properties::Doc::TYPE_INVOICE,
        doc_number   => $inv->Id,
        doc_ref      => $inv->DocNumber,
        partner_id   => $inv->CustomerRef->value,
        recipients_e => $inv->properties->recipients_e,
        recipients_u => $inv->properties->recipients_u,
        trigger      => $inv->properties->status,
        revision     => $inv->properties->revision,
        files        => $files,
        sending_on   => $sending_on,
        subject      => $subject,
        message      => $message,
        created_on   => AE::time,
        updated_on   => undef,
        success      => undef,
        error        => undef,
    });

    $self->usernames_to_emails($notification, -die => 1);
    return $notification;
}

sub create_notification_from_bill {
    my ($self, $bill, $files, $sending_on, $subject, $message) = @_;
    die "Invalid bill object"
        unless $bill->$_isa('LEMA::Object::Bill');
    die "Bill is not supported by LEMA SMAPP: " . $bill->error
        if defined $bill->error;

    my $notification = LEMA::DB::Notifications::Doc->new({
        doc_type     => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
        doc_number   => $bill->Id,#$bill->DocNumber,
        doc_ref      => $bill->DocNumber,
        partner_id   => $bill->VendorRef->value,
        recipients_e => $bill->properties->recipients_e,
        recipients_u => $bill->properties->recipients_u,
        trigger      => $bill->properties->status,
        revision     => $bill->properties->revision,
        files        => $files,
        sending_on   => $sending_on,
        subject      => $subject,
        message      => $message,
        created_on   => AE::time,
        updated_on   => undef,
        success      => undef,
        error        => undef,
    });

    $self->usernames_to_emails($notification, -die => 1);
    return $notification;
}

sub activate {
    my ($self, $notification_id, $subject, $message) = @_;
    die "No subject\n" unless length $subject;
    die "Subject is invalid" unless !ref $subject;
    die "Subject is too long (more than 128 characters)\n"
        if length $subject > 128;
    die "No message\n" unless length $message;
    die "Message is invalid" unless !ref $message;
    die "Message is too long (more than 500,000 characters)\n"
        if length $message > 500_000;

    my $id = BSON::OID::create($notification_id);
    my %hash = (
        subject    => $subject,
        message    => $message,
        sending_on => AE::time,
        updated_on => AE::time,
    );

    my $res = $self->coll->update_one(
        { _id    => $id, },
        { '$set' => \%hash },
    );

    die "Notification is not found by ID $id\n" unless $res->matched_count;
    ()
}

sub insert {
    my ($self, $notification) = @_;
    die "Invalid notification object"
        unless $notification->$_isa('LEMA::DB::Notifications::Doc');

    my $hash = $notification->OUTWOOF;
    $self->coll->insert_one($hash);
    ()
}

sub get_file {
    my ($self, $notification_id, $file_idx) = @_;
    my $id = BSON::OID::create($notification_id);
    $file_idx += 0;
    die "Invalid file index" unless $file_idx >= 0;

    my $doc = $self->coll->find_one({ _id => $id });
    return undef unless $doc;
    my $notification = LEMA::DB::Notifications::Doc->new($doc);

    return undef if $file_idx >= $notification->files->count;

    my $file = $notification->files->list->[$file_idx];
    return ($file->type, $file->octets);
}

sub find_by_invoice {
    my ($self, $invoice, %args) = @_;
    die "Invalid invoice object"
        unless $invoice->$_isa('LEMA::Object::Invoice');
    die "Invoice is not supported by LEMA SMAPP: " . $invoice->error
        if defined $invoice->error;


    my %options;
    if ($args{-without_octets}) {
        $options{projection} = { 'files.list.octets' => 0 };
    }

        my @docs = $self->coll->find({
            doc_type     => LEMA::DB::Properties::Doc::TYPE_INVOICE,
            doc_number   => $invoice->Id,#$invoice->DocNumber,
        }, \%options)->sort({ created_on => -1 })->all;

        for (@docs) {
            my $notification = LEMA::DB::Notifications::Doc->new($_);
            $_ = $notification;
        }


    return @docs ? \@docs : undef;
}

sub find_by_purchase_order {
    my ($self, $invoice, %args) = @_;
    die "Invalid purchase order object: $invoice"
        unless $invoice->$_isa('LEMA::Object::Bill');
    die "Purchase order is not supported by LEMA SMAPP: " . $invoice->error
        if defined $invoice->error;

    my %options;
    if ($args{-without_octets}) {
        $options{projection} = { 'files.list.octets' => 0 };
    }

    my @docs = $self->coll->find({
        doc_type     => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
        doc_number   => $invoice->Id,#$invoice->DocNumber,
    }, \%options)->sort({ created_on => -1 })->all;

    for (@docs) {
        my $notification = LEMA::DB::Notifications::Doc->new($_);
        $_ = $notification;
    }

    return @docs ? \@docs : undef;
}

sub fetch_notifications_to_send {
    my ($self) = @_;

    my @docs = $self->coll->find({ success    => undef,
                                   sending_on => { '$lt' => AE::time } })
                          ->sort({ created_on => 1 })->all;

    for (@docs) {
        my $notification = LEMA::DB::Notifications::Doc->new($_);
        $_ = $notification;
    }

    return @docs ? \@docs : undef;
}

sub update_process {
    my ($self, $notification) = @_;
    die "Invalid notification object"
        unless $notification->$_isa('LEMA::DB::Notifications::Doc');


    my $hash = {
        updated_on   => AE::time,
        success      => $notification->success,
        error        => $notification->error,
        recipients_e => $notification->recipients_e ? $notification->recipients_e->OUTWOOF : undef,
        recipients_u => $notification->recipients_u ? $notification->recipients_u->OUTWOOF : undef,
        files        => $notification->files->OUTWOOF,
    };

    my $res = $self->coll->update_one(
        { _id    => $notification->_id, },
        { '$set' => $hash },
    );


    $notification->updated_on($hash->{updated_on});
    ()
}

sub update_files {
    my ($self, $notification) = @_;
    die "Invalid notification object"
        unless $notification->$_isa('LEMA::DB::Notifications::Doc');

    my $hash = {
        updated_on   => AE::time,
        files        => $notification->files->OUTWOOF,
    };

    my $res = $self->coll->update_one(
        { _id    => $notification->_id, },
        { '$set' => $hash },
    );

    $notification->updated_on($hash->{updated_on});
    ()
}

1;
