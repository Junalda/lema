package LEMA::DB::Agents;
BEGIN { our $VERSION = 0.01; }

package LEMA::DB::Agents::Bank;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Try::Tiny;
use Woof;
use ACME::Data;
use ACME::Claim;
use ACME::E;

PUBLIC (package              => OF 'str_ne') = __PACKAGE__;
PUBLIC (version              => OF 'float')  = $LEMA::DB::Agents::VERSION;
PUBLIC (holder_name          => UNDEFOK OF 'strnull') = undef;
PUBLIC (holder_address       => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (account_no           => UNDEFOK OF 'strnull') = undef;
PUBLIC (account_iban         => UNDEFOK OF 'strnull') = undef;
PUBLIC (account_currency     => UNDEFOK OF 'strnull') = undef;
PUBLIC (bank_name            => UNDEFOK OF 'strnull') = undef;
PUBLIC (bank_address         => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (bank_swift           => UNDEFOK OF 'strnull') = undef;
PUBLIC (bank_routing         => UNDEFOK OF 'strnull') = undef;
PUBLIC (corr_bank_name       => UNDEFOK OF 'strnull') = undef;
PUBLIC (corr_bank_address    => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (corr_bank_account_no => UNDEFOK OF 'strnull') = undef;
PUBLIC (corr_bank_swift      => UNDEFOK OF 'strnull') = undef;
PUBLIC (corr_bank_routing    => UNDEFOK OF 'strnull') = undef;

sub _holder_address_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    return QuickBooks::Objects::Addr->new_mod($in);
}

sub _bank_address_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    return QuickBooks::Objects::Addr->new_mod($in);
}

sub _corr_bank_address_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    return QuickBooks::Objects::Addr->new_mod($in);
}

sub has_corr_bank {
    my $self = shift;
    for (qw(corr_bank_name corr_bank_address corr_bank_account_no
            corr_bank_swift corr_bank_routing)) {
        my $value = $self->$_();
        return 1 if length $value;
    }
    return 0;
}

sub has_custom_account_holder {
    my $self = shift;
    for (qw(holder_name holder_address)) {
        my $value = $self->$_();
        return 1 if length $value;
    }
    return 0;
}

sub format {
    my ($self, $cust_vend) = @_;
    my $str = '';
    my $oks = 0;

    if (length $self->account_iban) {
        $str .= "\n" if length $str;
        if (length $self->account_currency) {
            $str .= "IBAN (" . $self->account_currency . "): ";
        } else {
            $str .= "IBAN: ";
        }

        $str .= $self->account_iban;
        $oks++;
    }

    if (length $self->account_no) {
        $str .= "\n" if length $str;
        if (length $self->account_currency) {
            $str .= "Account Number (" . $self->account_currency . "): ";
        } else {
            $str .= "Account Number: ";
        }
        $str .= $self->account_no;
        $oks++;
    }

    my $account_holder;

    if (length $self->holder_name) {
        $account_holder = $self->holder_name;
    } elsif ($cust_vend) {
        if (length $cust_vend->CompanyName) {
            $account_holder = $cust_vend->CompanyName;
        } elsif (length $cust_vend->DisplayName) {
            $account_holder = $cust_vend->DisplayName;
        }
    }

    if ($self->holder_address->has_any_defined) {
        $account_holder .= ", " if length $account_holder;
        $account_holder .= $self->holder_address->address_comma_fmt;
    } elsif ($cust_vend) {
        if ($cust_vend->BillAddr->has_any_defined) {
            $account_holder = $cust_vend->BillAddr->address_comma_fmt;
        }
    }

    if (length $account_holder) {
        $str .= "\n" if length $str;
        $str .= "Account Holder: " . $account_holder;
        $oks++;
    }

    $str .= "\n" if $oks;
    $oks = 0;

    my $bank_details;
    if (length $self->bank_name) {
        $bank_details .= ", " if length $bank_details;
        $bank_details .= $self->bank_name;
        $oks++;
    }

    if ($self->bank_address->has_any_defined) {
        $bank_details .= ", " if length $bank_details;
        $bank_details .= $self->bank_address->address_comma_fmt;
        $oks++;
    }

    if (length $bank_details) {
        $str .= "\n" if length $str;
        $str .= "Bank: " . $bank_details;
        $oks++;
    }

    if (length $self->bank_swift) {
        $str .= "\n" if length $str;
        $str .= "Bank SWIFT/BIC: " . $self->bank_swift;
        $oks++;
    }

    if (length $self->bank_routing) {
        $str .= "\n" if length $str;
        $str .= "Bank ABA Routing Number: " . $self->bank_routing;
        $oks++;
    }

    $str .= "\n" if $oks;
    $oks = 0;

    if (0) {
    my $bank_details;
    if (length $self->corr_bank_name) {
        $bank_details .= ", " if length $bank_details;
        $bank_details .= $self->corr_bank_name;
        $oks++;
    }

    if ($self->corr_bank_address->has_any_defined) {
        $bank_details .= ", " if length $bank_details;
        $bank_details .= $self->corr_bank_address->address_comma_fmt;
        $oks++;
    }

    if (length $bank_details) {
        $str .= "\n" if length $str;
        $str .= "Correspondent Bank: " . $bank_details;
        $oks++;
    }

    if (length $self->corr_bank_swift) {
        $str .= "\n" if length $str;
        $str .= "Correspondent Bank SWIFT/BIC: " . $self->corr_bank_swift;
        $oks++;
    }

    if (length $self->corr_bank_routing) {
        $str .= "\n" if length $str;
        $str .= "Correspondent Bank ABA Routing Number: " . $self->corr_bank_routing;
        $oks++;
    }
    }

    $str .= "\n" if $oks;
    $oks = 0;

    return $str;
}

package LEMA::DB::Agents::Addresses;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;
use ACME::Claim;
PUBLIC (package => OF 'str_ne') = __PACKAGE__;
PUBLIC (version => OF 'float')  = $LEMA::DB::Agents::VERSION;
PUBLIC (count   => OF 'int')   = 0;
PUBLIC (list    => OF 'ARRAY') = sub { [] };

sub _validate_address_name {
    my ($self, $name) = @_;
    die "No address name\n" unless length $name;
    die "Invalid address name" unless !ref $name;
    die "Address name is too long\n" if length $name > 64;
    ()
}

sub _list_ {
    my $self = shift;
    $_[0] = +[] unless defined $_[0];
    VALIDATE;
    my $in = shift;
    if (ref $in eq 'CODE') { $in = $in->(); }

    my %uniq;
    my @new;

    for (my $i = 0; $i < @$in; $i++) {
        my $el = $in->[$i];

        if ($el->{reserved} && exists $el->{reserved}{name}) {
            my $name = $el->{reserved}{name};
            $self->_validate_address_name($name);
            if (exists $uniq{$name}) {
                die "Address name duplicate detected\n";
            }
            $uniq{$name} = 1;
        } else {
            die "No internal name for address\n";
        }

        my $addr = QuickBooks::Objects::Addr->new_mod($el);
        push @new, $addr;

        $addr->{reserved}{index} = $i;
    }

    $self->count(scalar @new);
    return \@new;
}

sub enum {
    my ($self, $cb) = @_;
    if ($self->count) {
        for my $el (@{$self->list}) {
            $cb->($el);
        }
    }
    ()
}

package LEMA::DB::Agents::Agent;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use ACME::Claim;
use Woof;

PUBLIC (package      => OF 'str_ne')    = __PACKAGE__;
PUBLIC (version      => OF 'float')     = $LEMA::DB::Agents::VERSION;
PUBLIC (_id          => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (qbo_id       => UNDEFOK OF 'num')                         = undef;
PUBLIC (addresses    => UNDEFOK OF 'LEMA::DB::Agents::Addresses') = undef;
PUBLIC (eori         => UNDEFOK OF 'strnull')                     = undef;
PUBLIC (bank         => UNDEFOK OF 'LEMA::DB::Agents::Bank')      = undef;
PUBLIC (updated_on   => OF 'float');

package LEMA::DB::Agents;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::Claim;
use ACME::E;
use parent qw(LEMA::DB::base);

our $TABLE = 'agents' . $LEMA::DB::TABLE_NAME_POSTFIX;

sub initialize {
    my ($self) = @_;
    my $table = $self->table;
    my $coll  = $self->coll;

    my $indexes = $coll->indexes;
    $indexes->create_one([ qbo_id => 1 ], { unique => 1 });
    ()
}

sub build {
    my ($self, $addresses, $bank, $eori) = @_;
    return LEMA::DB::Agents::Agent->new({
        qbo_id     => undef,
        addresses  => { list => $addresses },
        bank       => $bank,
        eori       => $eori,
        updated_on => AE::time,
    });
}

sub bind : method {
    my ($self, $cust_vend, $agent) = @_;
    die "Invalid customer or vendor object"
        unless $cust_vend->$_isa('QuickBooks::Objects::Customer') ||
               $cust_vend->$_isa('QuickBooks::Objects::Vendor');
    die "Invalid agent object"
        unless $agent->$_isa('LEMA::DB::Agents::Agent');
    die "Customer or vendor without ID"
        unless $cust_vend->Id > 0;

    $agent->qbo_id($cust_vend->Id);

    my $hash = $agent->OUTWOOF;
    delete $hash->{_id};
    delete $hash->{qbo_id};

    my $aref = $hash->{addresses}{list};
    my $idx  = 0;
    $agent->addresses->enum(sub {
        my $addr = shift;
        $aref->[$idx]{reserved} = $addr->reserved;
        $idx++;
    });

    $self->coll->update_one(
        { qbo_id => $agent->qbo_id, },
        { '$set' => $hash },
        { upsert => 1 },
    );

    $cust_vend->{reserved} ||= +{};
    $cust_vend->{reserved}{agent} = $agent;
    return $cust_vend;
}

sub populate {
    my ($self, $cust_vend) = @_;
    die "Invalid agent object: $cust_vend"
        unless $cust_vend->$_isa('QuickBooks::Objects::Customer') ||
               $cust_vend->$_isa('QuickBooks::Objects::Vendor');
    die "Customer or vendor without ID"
        unless $cust_vend->Id > 0;

    my $doc = $self->coll->find_one({ qbo_id => $cust_vend->Id });

    if ($doc) {
        my $agent = LEMA::DB::Agents::Agent->new($doc);
        $cust_vend->{reserved}{agent} = $agent;
    } else {
        $cust_vend->{reserved}{agent} = undef;
    }

    return $cust_vend;
}

1;
