package LEMA::DB::PredefinedProducts;

package LEMA::DB::PredefinedProducts::Doc;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;

PUBLIC (_id        => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (type       => OF 'str_ne');
PUBLIC (lines      => OF 'strnull') = undef;
PUBLIC (updated_on => OF 'float')   = sub { AE::time };

sub populate_to_hash {
    my ($self, $href) = @_;
    die "Invalid hashref" unless ref $href eq 'HASH';
    for my $line (split /\r?\n/, $self->lines) {
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        next unless $line =~ /\S/;
        $href->{$line}++;
    }
    ()
}

sub populate_to_array {
    my ($self, $aref) = @_;
    my %hash;
    $self->populate_to_hash(\%hash);
    for (sort keys %hash) {
        push @$aref, $_;
    }
    ()
}

sub lines_fmt {
    my ($self) = @_;
    my $sorted;
    my $href = +{};
    for my $line (split /\r?\n/, $self->lines) {
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        next unless $line =~ /\S/;
        $href->{$line}++;
    }

    for (sort keys %$href) {
        $sorted .= "\n" if length $sorted;
        $sorted .= $_;
    }

    return $sorted;
}

package LEMA::DB::PredefinedProducts;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::Claim;
use ACME::E;
use parent qw(LEMA::DB::base);

our $TABLE = 'predefined_products' . $LEMA::DB::TABLE_NAME_POSTFIX;

sub initialize {
    my ($self) = @_;
    my $table = $self->table;
    my $coll  = $self->coll;

    my $indexes = $coll->indexes;
    $indexes->create_one([ type => 1 ], { unique => 1});
    ()
}

sub upsert {
    my ($self, $doc) = @_;
    die "Invalid predefined products object"
        unless $doc->$_isa('LEMA::DB::PredefinedProducts::Doc');

    my $hash = $doc->OUTWOOF;
    delete $hash->{_id};
    delete $hash->{_type};
    $hash->{updated_on} = AE::time;

    $self->coll->update_one(
        { type   => $doc->type, },
        { '$set' => $hash },
        { upsert => 1 },
    );

    $doc->updated_on($hash->{updated_on});
    ()
}

sub find_all {
    my ($self) = @_;
    my @docs = $self->coll->find->all;

    my %hash;
    for (@docs) {
        my $doc = LEMA::DB::PredefinedProducts::Doc->new($_);
        $hash{$doc->type} = $doc;
    }

    return %hash ? \%hash : undef;
}

sub find_by_type {
    my ($self, $type) = @_;
    die "Invalid type in arguments" unless !ref $type && length $type;
    my @docs = $self->coll->find({ type => $type })->all;
    return undef unless @docs;
    claim { @docs == 1 };
    return LEMA::DB::PredefinedProducts::Doc->new($docs[0]);
}

1;
