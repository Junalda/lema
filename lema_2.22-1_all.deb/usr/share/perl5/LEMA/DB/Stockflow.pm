package LEMA::DB::Stockflow;

package Woof::ISA::BSON::OID;
use common::sense;
use BSON::OID;
use Data::Dumper;
use Scalar::Util;

sub BSON::OID::INWOOF() {
    my @args = @_;

    if (ref $args[0]) {
        if (Scalar::Util::blessed($args[0])) {
            die "Blessed $args[0] is rejected to build BSON::OID";
        }
        $_->referent = BSON::OID->new($args[0]);
    } else {
        my $oid = pack "H*", $args[0];
        $_->referent = BSON::OID->new(oid => $oid);
    }
    ()
}

sub BSON::OID::OUTWOOF {
    return $_[0];
}

package LEMA::DB::Stockflow::Doc;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;
use constant TYPE_NOTHING        => 0;
use constant TYPE_PURCHASE_ORDER => 1;
use constant TYPE_INVOICE        => 2;
use constant TYPE_ADJUST         => 3;

PUBLIC (_id             => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (recv_doc_number => OF 'str_ne');
PUBLIC (recv_doc_type   => OF 'num');
PUBLIC (recv_doc_status => UNDEFOK OF 'num') = undef;
PUBLIC (recv_our_number => OF 'strnull');
PUBLIC (sent_doc_number => UNDEFOK OF 'str_ne') = undef;
PUBLIC (sent_doc_type   => OF 'num');
PUBLIC (sent_doc_status => UNDEFOK OF 'num') = undef;
PUBLIC (sent_our_number => OF 'strnull');
PUBLIC (product_key     => OF 'str_ne');
PUBLIC (product_qty     => OF 'num');
PUBLIC (updated_on      => UNDEFOK OF 'num') = sub { AE::time };
PUBLIC (updated_on_orig => UNDEFOK OF 'strnull') = undef;


PUBLIC (consistency_id => UNDEFOK OF 'BSON::OID') = undef;

sub _recv_doc_number {
    my ($self, $in) = @_;
    croak "PO ID is not defined" unless length $in;
    VALIDATE;
    return $in;
}

sub _sent_doc_number {
    my ($self, $in) = @_;
    return undef unless defined $in;
    VALIDATE;
    return $in;
}

sub _recv_doc_type {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid document type for stock receiving\n"
        unless $in == TYPE_PURCHASE_ORDER || $in == TYPE_ADJUST;
    return $in;
}

sub _sent_doc_type {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid document type for stock sending\n"
        unless $in == TYPE_INVOICE || $in == TYPE_NOTHING;

    if ($self->recv_doc_type == TYPE_ADJUST && $in == TYPE_INVOICE) {
        die "Can't have TYPE_ADJUST for receiver and TYPE_INVOICE for sender";
    }

    if ($in == TYPE_INVOICE) {
        croak "No sent document number\n"
            unless length $self->sent_doc_number;

        die "Invalid sent document number format\n"
            unless $self->sent_doc_number =~ /^\d+(\.\d+)?$/ &&
                   $self->sent_doc_number > 0;
    }
    elsif ($in == TYPE_NOTHING) {
        die "Cannot keep sent document number if TYPE_NOTHING is for sender\n"
            if defined $self->sent_doc_number;
    }
    else {
        die "Invalid sent doc type";
    }
    return $in;
}

sub _product_qty {
    my ($self, $in) = @_;
    VALIDATE;
    if ($self->sent_doc_type == TYPE_INVOICE) {
        die "Quanity must be less than 0 for stock flow by invoice\n"
            unless $in < 0;
    }
    elsif ($self->sent_doc_type == TYPE_NOTHING) {
    }

    if ($self->sent_doc_type != TYPE_INVOICE) {
        if ($self->recv_doc_type == TYPE_PURCHASE_ORDER) {
            die "Quanity must be greater than 0 for stock flow by purchase order\n"
                unless $in > 0;
        }
        elsif ($self->recv_doc_type == TYPE_ADJUST) {
            die "Quanity must be non-zero for stock flow by stock adjustment\n"
                unless $in != 0;
        }
        else {
            die "Unknown document type";
        }
    }

    return $in;
}

sub _recv_doc_status_ {
    my ($self, $in) = @_;
    LEMA::DB::Properties::Doc::validate_order_status($in)
        if defined $in;
    return $in;
}

sub _sent_doc_status_ {
    my ($self, $in) = @_;
    LEMA::DB::Properties::Doc::validate_order_status($in)
        if defined $in;
    return $in;
}

sub product_qty_fmt {
    my $self = shift;
    if ($self->sent_doc_type != TYPE_NOTHING) {
        return $self->product_qty;
    }
    return "+" . $self->product_qty;
}

sub recv_doc_type_fmt {
    my $self = shift;
    my $type = $self->recv_doc_type;
    if ($type == TYPE_INVOICE) {
        return "Order Confirmation";
    } elsif ($type == TYPE_PURCHASE_ORDER) {
        return "Purchase Order";
    } elsif ($type == TYPE_ADJUST) {
        return "Stock Adjust";
    } elsif ($type == TYPE_NOTHING) {
        return undef;
    } else {
        return "Unknown";
    }
}

sub sent_doc_type_fmt {
    my $self = shift;
    my $type = $self->sent_doc_type;
    if ($type == TYPE_INVOICE) {
        return "Order Confirmation";
    } elsif ($type == TYPE_PURCHASE_ORDER) {
        return "Purchase Order";
    } elsif ($type == TYPE_ADJUST) {
        return "Stock Adjust";
    } elsif ($type == TYPE_NOTHING) {
        return undef;
    } else {
        return "Unknown";
    }
}

sub updated_on_fmt {
    my $self = shift;
    return
           ACME::Data::localtime_tz($self->updated_on);
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{product_qty_fmt}    = $_[0]->product_qty_fmt;
    $res->{recv_doc_type_fmt}  = $_[0]->recv_doc_type_fmt;
    $res->{sent_doc_type_fmt}  = $_[0]->sent_doc_type_fmt;
    $res->{updated_on_fmt}     = $_[0]->updated_on_fmt;
    $res->{is_consistent}      = $_[0]->is_consistent;
    $res->{product_name}       = $_[0]->{product_name};
    return $res;
}

sub many_from_purchase_order {
    my ($class, $po) = @_;
    die "Invalid PO object: $po"
        unless $po->$_isa('LEMA::Object::Bill');

    die "PO is not supported by LEMA SMAPP: " . $po->error
        if defined $po->error;

    my @many;
    $po->enum_item_qty(sub {
        my ($detail, $expense, $item_ref) = @_;
        next unless $item_ref->extended;


        my $product_qty = $expense->Qty;


        my $doc = $class->new({
            recv_doc_type   => TYPE_PURCHASE_ORDER,
            recv_doc_number => $po->Id,
            recv_doc_status => $po->properties->status,
            recv_our_number => $po->DocNumber,
            product_key     => $item_ref->product_key,
            product_qty     => $product_qty,
            sent_doc_type   => TYPE_NOTHING,
            sent_doc_number => undef,
            sent_doc_status => undef,
            sent_our_number => undef,
            updated_on      => $po->MetaData->updated_on,
            updated_on_orig => $po->MetaData->LastUpdatedTime,
            consistency_id  => undef,
        });
        push @many, $doc;
    });


    return @many ? \@many : undef;
}

sub many_from_invoice {
    my ($class, $invoice) = @_;
    die "Invalid invoice object"
        unless $invoice->$_isa('LEMA::Object::Invoice');
    die "Invoice is not supported by LEMA SMAPP: " . $invoice->error
        if defined $invoice->error;

    my @many;
    $invoice->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;
        next unless $item_ref->extended;


        next unless defined $item_ref->lot;

        my $product_qty = $sale->Qty;
        my $lot = $item_ref->lot;




            my $doc = $class->new({
                recv_doc_type   => TYPE_PURCHASE_ORDER,
                recv_doc_number => $lot,
                recv_doc_status => undef,
                recv_our_number => undef,
                product_key     => $item_ref->product_key,
                product_qty     => (-1) * $product_qty,
                sent_doc_type   => TYPE_INVOICE,
                sent_doc_number => $invoice->Id,
                sent_doc_status => $invoice->properties ? $invoice->properties->status : undef,
                sent_our_number => $invoice->DocNumber,
                updated_on      => $invoice->MetaData->updated_on,
                updated_on_orig => $invoice->MetaData->LastUpdatedTime,
                consistency_id  => undef,
            });
            push @many, $doc;
    });


    return @many ? \@many : undef;
}

sub is_consistent {
    my $self = shift;
    my $true = undef;
    return boolean(1);
}

sub is_consumer {
    my $self = shift;
    return 1 if $self->sent_doc_type == TYPE_INVOICE;
    return 0;
}

package LEMA::DB::Stockflow;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::E;
use parent qw(LEMA::DB::base);

our $TABLE = 'stockflow' . $LEMA::DB::TABLE_NAME_POSTFIX;

sub initialize {
    my ($self) = @_;
    my $table = $self->table;
    my $coll  = $self->coll;

    my $indexes = $coll->indexes;
    $indexes->create_one([ product_key   => 1 ]);
    $indexes->create_one([ recv_doc_type => 1, recv_doc_number => 1 ]);
    $indexes->create_one([ sent_doc_type => 1, sent_doc_number => 1 ]);
    ()
}

sub check_stock_for_invoice {
    my ($self, $invoice) = @_;

    $invoice->{Id} > 0 or local $invoice->{Id} = AE::time;


    my $docs = LEMA::DB::Stockflow::Doc->many_from_invoice($invoice);
    return unless $docs;

    my %qty_req_by_product_id;
    my %qty_avail_by_product_id;


    my $report;
    for my $doc (@$docs) {
        my $doc_number   = $doc->recv_doc_number;
        my $product_key  = $doc->product_key;
        my $qty_required = (-1) * $doc->product_qty;
        my $qty_avail    = 0;

        my $do_not_count_required = 0;
        if (!$doc_number) {
            $do_not_count_required = 1;
        }

        if (exists $qty_req_by_product_id{$product_key}) {
            goto MAKE_SUM;
        }

        my $all = LEMA::Web::SuppliersOrders->singleton->cache;
        for my $po (values %$all) {
            next if defined $po->error;
            next if $po->Id ne $doc_number;


            my $cand = LEMA::DB::Stockflow::Doc->many_from_purchase_order($po);
            if ($cand) {
                for (@$cand) {
                    if ($_->product_key eq $product_key) {
                        $report .= "increase $product_key from bill $doc_number: qty_avail += " .  $_->product_qty . " = " . ($qty_avail + $_->product_qty) . "<br>";
                        $qty_avail += $_->product_qty;
                    }
                }
            }
            last;
        }

        my $all = LEMA::Web::CustomersOrders->singleton->cache;
        for my $inv (values %$all) {
            next if defined $inv->error;
            next if $inv->Id eq $invoice->Id;


            my $cand = LEMA::DB::Stockflow::Doc->many_from_invoice($inv);
            for (@$cand) {
                next unless $_->product_key     eq $product_key;
                next unless $_->recv_doc_number eq $doc_number;
                $report .= "increase $product_key from invoice docnumber" . $inv->DocNumber . ": qty_avail += " .  $_->product_qty . " = " . ($qty_avail + $_->product_qty) . "<br>";
                $qty_avail += $_->product_qty;
            }

        }

        $qty_avail_by_product_id{$product_key} += $qty_avail;

MAKE_SUM:
        $qty_req_by_product_id{$product_key} += $qty_required
            unless $do_not_count_required;
    }


    for my $product_key (sort { $a <=> $b } keys %qty_req_by_product_id) {
        my $qty_required = $qty_req_by_product_id{$product_key};
        my $qty_avail    = $qty_avail_by_product_id{$product_key};

        if ($qty_required > $qty_avail) {
            die sprintf "No stock for product %s (%s available, %s required)\n",
                        $product_key,
                        $qty_avail, $qty_required;
        }
    }
    ()
}

sub _get_actual_stock {
    my ($self, $invoice) = @_;

    my $all_bills = LEMA::Web::SuppliersOrders->singleton->cache;
    my @stock;
    for my $po (values %$all_bills) {
        next unless $po->$_isa('LEMA::Object::Bill');
        next if defined $po->error;
        my $docs = LEMA::DB::Stockflow::Doc->many_from_purchase_order($po);
        push @stock, @$docs if $docs;

    }

    my $all    = LEMA::Web::CustomersOrders->singleton->cache;
    for my $inv (values %$all) {
        next unless $inv->$_isa('LEMA::Object::Invoice');
        next if defined $inv->error;
        my $docs = LEMA::DB::Stockflow::Doc->many_from_invoice($inv);
        if ($docs && @$docs) {
            for my $doc (@$docs) {
                my $qbo_id = $doc->recv_doc_number;
                if (my $po = $all_bills->{$qbo_id}) {
                    $doc->recv_our_number($po->DocNumber);
                }
            }
            push @stock, @$docs;
        };

    }

    return (undef, \@stock);
}


sub _validate_query {
    my ($self, $query) = @_;

    my %supported;
    @supported{qw(limit page sort order search Id)} = undef;

    for (keys %$query) {
        delete $query->{$_} unless exists $supported{$_};
    }

    $query->{limit}   = int $query->{limit};
    $query->{limit}   = 100 if $query->{limit} <= 0 || $query->{limit} > 500;
    $query->{page}    = int $query->{page};
    $query->{page}    = 1 if $query->{page} <= 0;
    $query->{sort}    = 'updated_on'
        unless $query->{sort} =~ /^(updated_on|product_id|recv_doc_number|recv_our_number|sent_doc_number|sent_our_number)$/;
    $query->{order}   = 'asc'
        unless $query->{order} =~ /^(desc|asc)$/;

    $query->{search} =~ s/^\s+//;
    $query->{search} =~ s/\s+$//;
    $query->{search} = undef unless length $query->{search};
    ()
}

sub query {
    my ($self, $query, $ptotal) = @_;
    my $coll = $self->coll;
    $self->_validate_query($query);

    my $total = 0;
    my $limit = $query->{limit};
    my $skip  = ($query->{page} - 1) * $query->{limit};
    my $qr    = undef;
    my $product_key = undef;


    if ($query->{search} =~ /^product_key\:(.+)$/) {
        $product_key = $1;
    }

    my $limit  = $query->{limit};
    my $skip   = ($query->{page} - 1) * $query->{limit};

    my $stock = $self->_get_actual_stock;


    my $cb;
    my $sort = $query->{sort};
    my $cmp_num = 0;
    if ($sort =~ /(^product_id|product_key|updated_on)$/) {
        $cmp_num = 1;
    }
    my $is_desc = $query->{order} eq 'desc';

    if (length $sort) {
        $cb = sub {
            my $r = $cmp_num ? ($a->{$sort} <=> $b->{$sort})
                             : ($a->{$sort} cmp $b->{$sort});
            $r
              or
            $is_desc ? ($b->{sent_doc_number} cmp $a->{sent_doc_number})
                     : ($a->{sent_doc_number} cmp $b->{sent_doc_number})
        };
    }
    else {
        $cb = sub { };
    }

    my $fn = $is_desc
           ? sub { $cb->() * (-1) }
           : $cb;

    my @sorted;
    for (sort $fn grep {
            my $ret = 1;
            if ($product_key) {
                $ret = 0 unless $_->product_key eq $product_key;
            }
            $ret
        } @$stock) {

        $skip--;
        if ($skip < 0 && @sorted < $limit) {
            push @sorted, $_;
        }

        $total++;
    }


    $total = @$stock;

    $$ptotal = $total if ref $ptotal eq 'SCALAR';
    return \@sorted;
}

sub get_stock {
    my ($self, $invoice) = @_;
    die "Invalid invoice object"
        if defined $invoice && !$invoice->$_isa('LEMA::Object::Invoice');

    my $stock  = $self->_get_actual_stock;



    my %prod_ids;
    for (@$stock) {
        my $product_qty = $_->product_qty;
        my $product_key = $_->product_key;

        my $detail = $prod_ids{$product_key} //= +{};
        $detail->{qty} += $product_qty;
        $detail->{name} = $product_key;


            $detail->{lots} ||= [];
            push @{$detail->{lots}}, [ $product_qty,
                                       $_->recv_doc_number,
                                       $_->recv_doc_status,
            ];
    }


    my @extra;
    my %do_not_remove_names;
    if (defined $invoice) {
        my $list = $invoice->prepare_product_list(+{}, -revert => 1, -lots => 1);

        for (@$list) {
            $_->{name} = $_->{item}{product_key};

            $do_not_remove_names{$_->{name}} = 1;
        }

        push @extra, @$list;
    }

    return (\%do_not_remove_names, [ values %prod_ids, @extra ]);
}

sub build_qty_hash {
    my ($self, $invoice) = @_;
    my ($do_not_remove_names, $stock) = $self->get_stock($invoice);

    my $all_bills = LEMA::Web::SuppliersOrders->singleton->cache;

    tie my %hash, 'Tie::IxHash';
    my @parts;

    for (sort { $a->{name} cmp $b->{name} } @$stock) {
        my $name = $_->{name};
        my $qty  = $_->{qty};
        my $lots = $_->{lots};

        @parts = split m!/!, $name;
        unless (@parts == 7) {
            next;
        }


        my $first_created;
        my $first_level;

        my $ptr = \%hash;
        for (my $i = 0; $i < @parts; $i++) {
            my $el = $parts[$i];
            unless ($ptr->{$el}) {
                tie my %inner, 'Tie::IxHash';
                $ptr->{$el} = \%inner;

                $first_created ||= [ $ptr, $el ];
                $first_level   //= $i;
            }
            $ptr->{$el}{''} += $qty;

            if ($i + 1 == @parts) {
                my $add_zero_qty = exists $do_not_remove_names->{$name};

                my $aref = ACME::Data::merge_2d_matrix_N_S(
                                $ptr->{$el}{'/'} // [], $lots, $add_zero_qty);

                $ptr->{$el}{'/'} = $aref;

                my $has_undefined_lot = 0;
                unless (@$aref) {
                    if ($first_created && $first_level > 0) {
                    }
                }
                else {
                    for my $lot (@$aref) {
                        if ($lot->[1] == 0) {
                            $has_undefined_lot = 1;
                        }
                        else {
                            my $po = $all_bills->{$lot->[1]};
                            $lot->[3] = $po->DocNumber if $po;
                        }
                    }
                }

                unless ($has_undefined_lot) {
                    push @$aref, [ 0, "0", undef, undef ];
                }

                last;
            }

            $ptr = $ptr->{$el};
        }
    }

    return \%hash;
}

1;
