package LEMA::DB::base;
use Carp;
use AnyEvent::Log;
use Safe::Isa;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use Scalar::Util;

sub new {
    my ($class, $parent, %args) = @_;

    die "Invalid parent class: $parent"
        unless $parent->$_isa('LEMA::DB');

    my $self = {
        __parent => $parent,
        __table  => undef,
        __prefix => undef,
    };

    Scalar::Util::weaken($self->{__parent});

    if (exists $args{-prefix}) {
        die "Invalid prefix"            unless length $args{-prefix};
        die "Invalid prefix characters" unless $args{-prefix} =~ /^\w+$/;
        $self->{__prefix} = $args{-prefix};
    }

    bless $self, $class;

    my $k     = ref $self;
    my $table = ${$k . '::TABLE'};

    die "No table name"                 unless !ref $table && length $table;
    die "Invalid table name characters" unless $table =~ /^\w+$/;

    $self->{__table} = defined $self->{__prefix}
                     ? $self->{__prefix} . '__' . $table
                     : $table;

    if ($args{-drop}) {
        die "No prefix is specified: argument `-drop` can be used to drop " .
            "tables which names are prefixed"
            unless defined $self->{__prefix};

        $self->drop('I know what I do');
    }

    $self->initialize;

    return $self;
}

sub db    { $_[0]{__parent} }

sub table {
    my $self = shift;
    if ($self->$_isa('LEMA::DB::Settings')) {
        return $self->{__table};
    }



    my $index = $self->db->settings->active_profile->index;

    return $self->{__table} . "." . $index;
}

sub coll {
    my ($self) = @_;
    return $self->db->handle->get_collection($self->table);
}

sub initialize {
    die "Define your own initialize() method in user class";
}

sub drop {
    my ($self, $i_know_what_i_do) = @_;
    return 0 unless $i_know_what_i_do eq 'I know what I do';

    return 1;
}

1;
