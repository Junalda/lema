package LEMA::DB::Export;

package LEMA::DB::Properties::Export::Line;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Try::Tiny;
use Woof;
use ACME::Data;
use ACME::Claim;
use ACME::E;
PUBLIC (package  => OF 'str_ne') = __PACKAGE__;
PUBLIC (version  => OF 'float')  = $LEMA::DB::Properties::VERSION;
PUBLIC (id       => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (item_ref => OF 'LEMA::Object::ItemRef');
PUBLIC (item_idx => OF 'int');
PUBLIC (active   => UNDEFOK OF 'boolean') = undef;
PUBLIC (commodity_code     => UNDEFOK OF 'strnull') = undef;
PUBLIC (nett_weight_box    => UNDEFOK OF 'float')   = undef;
PUBLIC (gross_weight_box   => UNDEFOK OF 'float')   = undef;


PUBLIC (item_qty           => OF 'float');
PUBLIC (item_price           => UNDEFOK OF 'float') = undef;

sub _item_idx_ {
    my ($self, $in) = @_;
    die "Invalid export line index" unless $in =~ /^\d+$/ && $in >= 0;
    $in += 0;
    return $in;
}



sub nett_weight_box_fmt {
    my $self = shift;
    return undef unless defined $self->nett_weight_box;
    return ACME::Data::print_amount($self->nett_weight_box);
}

sub gross_weight_box_fmt {
    my $self = shift;
    return undef unless defined $self->gross_weight_box;
    return ACME::Data::print_amount($self->gross_weight_box);
}


sub calc_nett_weight_total {
    my $self = shift;
    return undef unless $self->nett_weight_box;
    return ACME::Data::print_amount($self->nett_weight_box * $self->item_qty);
}

sub calc_gross_weight_total {
    my $self = shift;
    return undef unless $self->gross_weight_box;
    return ACME::Data::print_amount($self->gross_weight_box * $self->item_qty);
}

sub item_price_fmt {
    my $self = shift;
    return ACME::Data::print_amount($self->item_price);
}

sub item_total_fmt {
    my $self = shift;
    return ACME::Data::print_amount($self->item_price * $self->item_qty);
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{item_total_fmt}       = $_[0]->item_total_fmt;
    $res->{item_price_fmt}     = $_[0]->item_price_fmt;
    $res->{calc_gross_weight_total} = $_[0]->calc_gross_weight_total;
    $res->{calc_nett_weight_total}   = $_[0]->calc_nett_weight_total;
    return $res;
}

package LEMA::DB::Properties::Export;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;
use ACME::Claim;
PUBLIC (package => OF 'str_ne') = __PACKAGE__;
PUBLIC (version => OF 'float')  = $LEMA::DB::Properties::VERSION;
PUBLIC (export_num => UNDEFOK OF 'strnull') = undef;
PUBLIC (count   => OF 'int')   = 0;
PUBLIC (lines   => OF 'ARRAY') = sub { [] };
PUBLIC (total_nett_weight => UNDEFOK OF 'float') = undef;
PUBLIC (total_gross_weight => UNDEFOK OF 'float') = undef;

sub PRUNE();
sub PRUNE() { \&PRUNE }

sub total_nett_weight_fmt {
    my $self = shift;
    return ACME::Data::print_amount($self->total_nett_weight);
}

sub total_gross_weight_fmt {
    my $self = shift;
    return ACME::Data::print_amount($self->total_gross_weight);
}

sub _lines_ {
    my ($self, $in) = @_;
    VALIDATE;
    if (ref $in eq 'CODE') { $in = $in->(); }

    my %uniq;
    my @new;
    for my $el (@$in) {
        my $line = LEMA::DB::Properties::Export::Line->new($el);
        push @new, $line;
    }

    $self->count(scalar @new);
    return \@new;
}

sub push_line {
    my ($self, $line) = @_;
    die "Invalid line object to push"
        unless $line->$_isa('LEMA::DB::Properties::Export::Line');

    push @{$self->lines}, $line;
    $self->count($self->count + 1);
    ()
}

sub get_lines_by_product_key {
    my ($self, $product_key) = @_;
    die "Invalid product key" unless !ref $product_key && length $product_key;

    my @lines;
    $self->enum(sub {
        my $line = shift;
        if ($line->item_ref->product_key eq $product_key) {
            push @lines, $line;
        }
        ()
    });
    return @lines ? \@lines : undef;
}

sub get_line_by_id {
    my ($self, $id) = @_;
    die "No ID" unless length $id;
    my $found;

    $self->enum(sub {
        my $line = shift;
        if ($line->id eq $id) {
            $found = $line;
            return PRUNE;
        }
        ()
    });
    die "Line is not found. Please try to reload page.\n" unless $found;
    return $found;
}

sub new_from_invoice {
    my ($class, $invoice) = @_;
    die "Invalid invoice object"
        unless $invoice->$_isa('LEMA::Object::Invoice');

    my @lines;
    $invoice->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;
        return unless $item_ref->extended;

        my $line = {
            item_ref => $item_ref->clone,
            item_idx => scalar @lines,
            item_qty => $sale->Qty,
            item_price => $sale->UnitPrice,
            active   => 1,
        };

        $line->{nett_weight_box} = $item_ref->weight
            if $item_ref->weight =~ /^\d+$/;

        push @lines, $line;
        ()
    });

    return $class->new(lines => \@lines);
}

sub merge {
    my ($self, $export) = @_;
    die "Invalid export object"
        unless $export->$_isa('LEMA::DB::Properties::Export');

    my %seq;
    my @add_later;
    $export->enum(sub {
        my $new_line  = shift;
        my $old_lines = $self->get_lines_by_product_key(
                            $new_line->item_ref->product_key);

        unless ($old_lines) {
            push @add_later, $new_line;
            return;
        }

        my $cmp_lines = $seq{$new_line->item_ref->product_key} ||= $old_lines;
        my $removed   = undef;
        for (@$cmp_lines) {
            next unless defined $_;
            $removed = $_;
            $_ = undef;
        }

        unless ($removed) {
            push @add_later, $new_line;
            return;
        }
        else {

        }

    });

    for (@add_later) {
        $self->push_line($_);
        $self->deactivate_all_lines;
    }
    ()
}

sub update {
    my ($self, $href) = @_;
    die "Not hashref" unless ref $href eq 'HASH';
    my $list = $href->{list};

    for (@$list) {
        my $id = $_->{id};
        my $line = $self->get_line_by_id($id);
        $line->commodity_code($_->{commodity_code});
        my $fl = ACME::Data::adjust_amount($_->{nett_weight_box});
        $line->nett_weight_box(length $fl ? $fl : undef);
        my $fl = ACME::Data::adjust_amount($_->{gross_weight_box});
        $line->gross_weight_box(length $fl ? $fl : undef);
    }

    $href->{total_nett_weight} = undef unless length $href->{total_nett_weight};
    $href->{total_gross_weight} = undef unless length $href->{total_gross_weight};
    $self->total_nett_weight($href->{total_nett_weight});
    $self->total_gross_weight($href->{total_gross_weight});
    ()
}

sub deactivate_all_lines {
    my $self = shift;
    $self->enum(sub {
        my $line = shift;
        $line->active(0);
    });
    ()
}

sub activate_lines {
    my ($self, $invoice) = @_;
    die "Invalid invoice object"
        unless $invoice->$_isa('LEMA::Object::Invoice');

    $self->deactivate_all_lines;


    $invoice->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;
        return unless $item_ref->extended;

        my $activated = 0;
        $self->enum(sub {
            my $line = shift;
            return if $line->item_ref->product_key ne $item_ref->product_key;
            return if $line->active;

            my $qty = $sale->Qty;
            my $has_new_qty = "$qty" != "" . $line->item_qty;
            $line->item_qty($qty);
            $line->item_price($sale->UnitPrice);
            $line->active(1);
            $activated = 1;


                unless (defined $line->nett_weight_box) {
                    $line->nett_weight_box($item_ref->weight)
                        if $item_ref->weight =~ /^\d+$/;
                }



            return PRUNE;
        });

        unless ($activated) {
            die "Export items don't have all items from " .
                "the order confirmation\n";
        }
        ()
    });

    ()
}

sub enum {
    my ($self, $cb) = @_;
    if ($self->count) {
        for my $el (@{$self->lines}) {
            my $ret = $cb->($el);

            if ($ret eq LEMA::DB::Properties::Export::PRUNE) {
                last;
            }
        }
    }
    ()
}

1;
