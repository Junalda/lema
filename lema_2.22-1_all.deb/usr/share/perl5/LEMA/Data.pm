package LEMA::Data;
use common::sense;
use Carp;
use Safe::Isa;

sub number_from_doc_number($) {
    my $doc_number = shift;
    die "Invalid documnet number in arguments"
        unless $doc_number =~ /^(\d{4})\-(\d+)$/;
    my $number = sprintf "%04d", $2;
    return $number;
}

1;
