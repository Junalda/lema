package LEMA::DB;
use common::sense;
use Carp;
use MongoDB;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use LEMA;
use LEMA::Logging;
use LEMA::Object::ConfigData;
use ACME::E
    SC_DUP_INSERT => [ 5000, "Duplicate record inserting detected" ],
;
BEGIN { our $TABLE_NAME_POSTFIX = "_v1" }
our $TABLE_NAME_POSTFIX;
use LEMA::DB::Settings;
use LEMA::DB::Properties;
use LEMA::DB::Stockflow;
use LEMA::DB::PredefinedProducts;
use LEMA::DB::Notifications;
use LEMA::DB::Agents;

our $SINGLETON;

sub new {
    my ($class, $config) = @_;

    die "Invalid config data object"
        unless $config->$_isa('LEMA::Object::ConfigData');

    my $self = { config => $config, conn => undef, handle => undef };
    $SINGLETON = bless $self, $class;


    return $self;
}

sub initialize {
    my ($self, $profile_index) = @_;
    my $config = $self->config;

    my $uri = $config->mongodb_get_uri;
    unless (length $uri) {
        die "No MongoDB connection string in settings\n";
    }

    my $uri_redacted = $config->mongodb_get_uri_redacted;
    AE::log info => "Connect to MongoDB using URI: %s...", $uri_redacted;

    my $conn   = MongoDB->connect($uri);
    my $handle = $conn->get_database($conn->db_name);
    AE::log info => "Connected to MongoDB";

    die "Couldn't initialize database handle\n"
        unless $handle;

    $self->{conn}   = $conn;
    $self->{handle} = $handle;

    my $settings = LEMA::DB::Settings->new($self);
    $self->{_db_settings} = $settings;

    AE::log info => "Initialize all MongoDB collections...";
    $self->{_db_properties}          = LEMA::DB::Properties->new($self);
    $self->{_db_stockflow}           = LEMA::DB::Stockflow->new($self);
    $self->{_db_predefined_products} = LEMA::DB::PredefinedProducts->new($self);
    $self->{_db_notifications}       = LEMA::DB::Notifications->new($self);
    $self->{_db_agents}              = LEMA::DB::Agents->new($self);

    AE::log info => "All MongoDB collections are initialized";

    ()
}


sub inited { $_[0]{conn} ? 1 : 0 }

sub _inited_db {
    my ($self, $key) = @_;
    die "MongoDB is not initialized\n"
        unless $self->{conn};
    return $self->{$key};
}

sub settings   { $_[0]->_inited_db('_db_settings')   }
sub properties { $_[0]->_inited_db('_db_properties') }
sub stockflow  { $_[0]->_inited_db('_db_stockflow')  }
sub predefined_products { $_[0]->_inited_db('_db_predefined_products') }
sub notifications       { $_[0]->_inited_db('_db_notifications') }
sub agents     { $_[0]->_inited_db('_db_agents') }

sub singleton {
    my ($class) = @_;
    die "No DB singleton" unless $SINGLETON;
    return $SINGLETON;
}

sub has_singleton { defined $SINGLETON }
sub handle        { $_[0]{handle} }
sub config        { $_[0]{config} }
sub table_postfix { $TABLE_NAME_POSTFIX }

1;
