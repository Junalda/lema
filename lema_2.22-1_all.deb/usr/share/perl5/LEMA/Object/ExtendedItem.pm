package LEMA::Object::ExtendedItem;
use common::sense;
use Safe::Isa;
use Data::Dumper;
use parent qw(QuickBooks::Objects::Item);
use Woof;
use ACME::E
;


PUBLIC (Id => UNDEFOK OF 'num') = undef;

PUBLIC (extended => OF 'boolean') = sub { boolean::false };


PUBLIC (inventory => UNDEFOK OF 'QuickBooks::Objects::InventoryItem') = undef;

sub from_qbo {
    my ($class, $item) = @_;
    die "Invalid QBO Item object"
        unless $item->$_isa('QuickBooks::Objects::Item');

    return $item if $item->$_isa('LEMA::Object::ExtendedItem');


    bless $item, $class;
        $item->extended(0);

    $item->inventory(undef);

    return $item;
}



sub _inventory_ {
    my ($self, $inventory_item) = @_;
    return undef unless defined $inventory_item;

    die "Invalid QBO Inventory Item object"
        unless $inventory_item->$_isa('QuickBooks::Objects::InventoryItem');

    if ($inventory_item->ProductsAndService ne $self->FullyQualifiedName) {
        die sprintf "Inventory item is not linked with product item: %s vs %s\n",
                    $inventory_item->ProductsAndService,
                    $self->FullyQualifiedName;
    }

    if ($self->Type ne 'Inventory') {
        die "Inventory is being attach to non-inventory item";
    }

    return $inventory_item;
}

sub income_account {
    my $self = shift;
    return undef unless $self->IncomeAccountRef;
    return $self->IncomeAccountRef->name;
}

sub expense_account {
    my $self = shift;
    return undef unless $self->ExpenseAccountRef;
    return $self->ExpenseAccountRef->name;
}

sub asset_account {
    my $self = shift;
    return undef unless $self->AssetAccountRef;
    return $self->AssetAccountRef->name;
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{income_account}    = $_[0]->income_account;
    $res->{expense_account}   = $_[0]->expense_account;
    $res->{asset_account}     = $_[0]->asset_account;
    return $res;
}

1;
