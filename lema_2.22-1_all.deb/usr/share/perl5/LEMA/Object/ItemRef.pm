package LEMA::Object::ItemRef;

package LEMA::Object::ItemRef::Tax;
use common::sense;
use Safe::Isa;
use Data::Dumper;
use Woof;
PUBLIC (selected => UNDEFOK OF 'boolean') = undef;

PUBLIC (tax_code_id => OF 'int');
PUBLIC (net_amount  => OF 'float');

PUBLIC (name => UNDEFOK OF 'strnull') = undef;
PUBLIC (rate_value => UNDEFOK OF 'float') = undef;
PUBLIC (active => UNDEFOK OF 'boolean') = undef;
PUBLIC (id => UNDEFOK OF 'int') = undef;
PUBLIC (tax_amount => UNDEFOK OF 'float') = undef;
PUBLIC (candidates  => OF 'ARRAY') = sub { [] };

sub tripple {
    my $self = shift;
    return sprintf "%s.%s.%s", $self->id, $self->tax_code_id, $self->rate_value;
}

sub _tax_code_id_ {
    my ($self, $in) = @_;
    $in += 0;
    die "Bad tax code ID" unless $in > 0;
    return $in;
}

sub _candidates_ {
    my ($self, $in) = @_;
    die "Invalid VAT struct candidates" unless ref $in eq 'ARRAY';
    my @populate = qw(name rate_value active id tax_amount);
    for (@populate) {
        $self->$_(undef);
    }

    for my $vat_el (@$in) {
        next unless ref $vat_el eq 'HASH';
        if ($vat_el->{tax_code_id} == $self->tax_code_id) {
            for (@populate) {
                next if $_ eq 'tax_amount';
                $self->$_($vat_el->{$_});
            }

            $self->tax_amount(sprintf("%.2f", ($self->net_amount * $self->rate_value) / 100));
            last;
        }
    }

    return $in;
}

package LEMA::Object::ItemRef;
use common::sense;
use Safe::Isa;
use Data::Dumper;
use parent qw(QuickBooks::Objects::ItemRef);
use Woof;
use ACME::E;



PUBLIC (variety => OF 'str_ne') = undef;
PUBLIC (size => OF 'str_ne') = undef;
PUBLIC (origin => OF 'str_ne') = undef;
PUBLIC (category => OF 'str_ne') = undef;
PUBLIC (state => OF 'str_ne') = undef;
PUBLIC (weight => OF 'str_ne') = undef;
PUBLIC (product_id => OF 'str_ne') = undef;
PUBLIC (product_key => OF 'str_ne') = undef;
PUBLIC (lot => UNDEFOK OF 'strnull') = undef;


PUBLIC (extended => OF 'boolean') = sub { boolean::false };


PUBLIC (tax => UNDEFOK OF 'LEMA::Object::ItemRef::Tax') = undef;

sub extend {
    my ($class, $item, $description) = @_;
    die "Invalid QBO Item object"
        unless $item->$_isa('QuickBooks::Objects::ItemRef');

    return $item if $item->$_isa('LEMA::Object::ItemRef');

    my $pas   = $item->name . '/' . $description;
    my @parts = split m!/!, $description;

    bless $item, $class;

    if (@parts >= 6) {


        $pas =~ s/\W/_/g;
        $item->product_id('PID_' . $pas);
        $item->variety($parts[0]);
        $item->size($parts[1]);
        $item->origin($parts[2]);
        $item->category($parts[3]);
        $item->state($parts[4]);
        $item->weight($parts[5]);

        my $product_key = sprintf "%s/%s/%s/%s/%s/%s/%s",
                   $item->name,
                   $item->variety,  $item->size,
                   $item->origin,  $item->category, $item->state,
                   $item->weight;
        $item->product_key($product_key);


        if (@parts > 6 && $parts[6] =~ /^\d+$/) {
            $item->lot($parts[6]);
        }
        else {
            $item->lot(0);
        }

        $item->extended(1);
    } else {
        $item->extended(0);
    }

    $item->tax(undef);
    return $item;
}








sub product_key_with_lot {
    my $self = shift;
    return undef unless $self->extended;
    my $ret  = $self->product_key;
    $ret .= "/" . $self->lot if $self->lot > 0;
    return $ret;
}

sub unique_id {
    my $self = shift;
    my $id = "$self";
    $id =~ s/\W//g;
    $id =~ s/HASH//;
    $id =~ s/0x//;
    return $id;
}

sub clone {
    my $self = shift;
    return LEMA::Object::ItemRef->new($self->OUTWOOF);
}

sub fmt {
    my $self = shift;
    my $buf  = "";

    $buf .= $self->variety;

    if (length $self->size) {
        $buf .= ", " if length $buf;
        $buf .= "Size ";
        $buf .= $self->size;
    }

    if (length $self->origin) {
        $buf .= ", " if length $buf;
        $buf .= $self->origin;
    }

    if (length $self->weight) {
        $buf .= ", " if length $buf;
        $buf .= $self->weight;
    }

    if (length $self->state) {
        $buf .= ", " if length $buf;
        $buf .= $self->state;
    }

    return $buf;
}

sub lot_fmt {
    my $self = shift;
    my $lot  = $self->lot;
    unless ($lot =~ /^\d{4}-\d{4}$/) {
        $lot = LEMA::Web::SuppliersOrders->singleton->get_lot_by_txn_id($lot);
        return defined $lot ? $lot : '—';
    }
    return $lot;
}

1;
