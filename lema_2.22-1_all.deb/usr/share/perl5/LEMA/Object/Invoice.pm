package LEMA::Object::Invoice;
use common::sense;
use boolean;
use Safe::Isa;
use BSON::OID;
use Try::Tiny;
use Data::Dumper;
use QuickBooks::Objects::VendorRef;
use LEMA::Object::ItemRef;
use parent qw(QuickBooks::Objects::Invoice);
use Woof;
use ACME::Data;
use ACME::E;

PUBLIC (error         => UNDEFOK OF 'strnull')   = undef;
PUBLIC (PrivateNote   => UNDEFOK OF 'strnull')   = undef;
PUBLIC (DocNumber     => UNDEFOK OF 'strnull')   = undef;

PUBLIC (properties    => UNDEFOK OF 'LEMA::DB::Properties::Doc') = undef;


sub extend {
    my ($class, $item) = @_;
    die "Invalid QBO invoice object: $item"
        unless $item->$_isa('QuickBooks::Objects::Invoice');

    return $item if $item->$_isa('LEMA::Object::Invoice');

    bless $item, $class;

    my $error;
    unless (length $item->DocNumber =~ /^\d{4}-\d{4}$/) {
        $error //= "Invoice without LEMA SMAPP document number";
    }

    unless (defined $error) {
        my $line = $item->Line;
        if (ref $line eq 'ARRAY' && @$line) {
            for my $detail (@$line) {
                next unless $detail->DetailType eq 'SalesItemLineDetail';

                my $item_detail = $detail->SalesItemLineDetail;
                unless ($item_detail) {
                    $error //= "Order confirmation doesn't contain items";
                    last;
                }

                my $item_ref = $item_detail->ItemRef;
                unless ($item_ref) {
                    $error //= "Order confirmation with invalid item references";
                    last;
                }


                LEMA::Object::ItemRef->extend($item_ref, $detail->Description);

                if ($item_ref->extended && !$item_ref->lot) {
                    $item_ref->lot(0);
                }

            }
        } else {
            $error //= "Invoice without items";
        }
    }

    unless (defined $error) {
        $item->error(undef);
        $item->properties(undef);
    } else {
        $item->error($error);
    }

    return $item;
}

sub root {
    my ($self) = @_;
    return QuickBooks::Objects::Invoice->new($self->OUTWOOF);
}

sub _properties {
    my ($self, $in) = @_;
    die "Properties are supported by extended invoice object only"
            if defined $self->error;
    VALIDATE;
    return $in;
}



sub _DocNumber {
    my ($self, $in) = @_;
    return $self->SUPER::_DocNumber($in) if defined $self->error;
    die "Document number must be in format YYYY-NNNN\n"
        unless $in =~ /^\d{4}-\d+$/;
    return $in;
}

sub txndate_fmt {
    my $tmp = $_[0]->TxnDate;
    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub duedate_fmt {
    my $tmp = $_[0]->DueDate;
    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub creation_date_fmt {
    my $self = shift;
    return undef unless $self->properties;
    return undef unless $self->properties->creation_date;
    my $tmp = $self->properties->creation_date;

    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub totalamt_fmt {
    my $tmp = $_[0]->TotalAmt;
    return ACME::Data::print_amount($tmp);
}

sub balance_fmt {
    my $tmp = $_[0]->Balance;
    return ACME::Data::print_amount($tmp);
}

sub subtotal_amount_fmt {
    my $self = shift;
    my $lines = $self->Line;
    for (@$lines) {
        if ($_->DetailType eq 'SubTotalLineDetail') {
            return ACME::Data::print_amount($_->Amount);
        }
    }
    return undef;
}

sub vat_amount_fmt {
    my $self = shift;
    if ($self->TxnTaxDetail && $self->TxnTaxDetail->TaxLine) {
        my $vat_amount_total = 0;
        for (@{$self->TxnTaxDetail->TaxLine}) {
            $vat_amount_total += $_->Amount;
        }
        return ACME::Data::print_amount($vat_amount_total);
    }

    return undef;
}


sub delivered {
    my ($self) = @_;
    return undef if defined $self->error;
    return boolean::false unless $self->properties;
    return boolean($self->properties->is_delivered);
}


sub prepare_product_list {
    my ($self, $hashout, %args) = @_;
    die "Hashout is not defined in arguments" unless ref $hashout eq 'HASH';
    return undef if $self->error;

    my %used;
    my $line = $self->Line;
    for my $detail (@$line) {
        next unless $detail->DetailType eq 'SalesItemLineDetail';
        my $extended_item_ref = $detail->SalesItemLineDetail->ItemRef;
        next unless $extended_item_ref->extended;

        my $qty = $detail->SalesItemLineDetail->Qty;
        my $lot = $extended_item_ref->lot;

        my $href = $hashout->{$extended_item_ref->product_key} ||= {
            qty   => 0,
            name  => $extended_item_ref->name,
            value => $extended_item_ref->value,
            item  => $extended_item_ref->clone,
            txn_count => 0,
            $args{-lots} ? (lots => []) : (),
        };

        unless ($args{-revert}) {
            $href->{qty} -= $qty;
        } else {
            $href->{qty} += $qty;
        }

        push @{$href->{lots}}, [ $qty, $lot ] if $args{-lots};
        $used{$href} = $href;
    }

    return %used ? [ values %used ] : undef;
}

sub existing_properies_hash {
    my $self = shift;
    return () if defined $self->error;
    return () unless $self->properties;
    return $self->properties->as_hash;
}

sub populate_vat_on_lines {
    my ($self, $vat_struct) = @_;
    die "No VAT structure used on QBO\n" unless ref $vat_struct eq 'ARRAY';

    my $detail = $self->TxnTaxDetail;

    return undef unless $detail;

    my $aref = $detail->TaxLine;
    return unless $aref && @$aref;

    my @candidates;
    for my $el (@$aref) {
        my $line = $el->TaxLineDetail;
        next unless $line;

        for (@$vat_struct) {
            if ($_->{id} == $line->TaxRateRef->value) {
                if ("$_->{rate_value}" == "" . $line->TaxPercent) {
                    push @candidates, { %$_ };
                }
            }
        }
    }

    return unless @candidates;

    $self->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;

        return unless $sale->TaxCodeRef;
        my $tax_code_id = $sale->TaxCodeRef->value;

        my $attached;
        for my $struct (@$vat_struct) {
            next unless $struct->{tax_code_id} eq $tax_code_id;


            my $tax = LEMA::Object::ItemRef::Tax->new(
                    tax_code_id => $tax_code_id,
                    net_amount  => $detail->Amount,
                    candidates  => \@candidates,
            );

            $item_ref->tax($tax);
        }

        ()
    });

    ()
}

sub set_your_ref {
    my ($self, $definition_id, $your_ref) = @_;

    die "Invalid definition ID for custom field\n"
        unless $definition_id =~ /^\d+$/;


    my %your_ref = (
        Type         => 'StringType',
        DefinitionId => $definition_id,
        StringValue  => $your_ref,
        Name         => LEMA::CUSTOM_FIELD_YOUR_REFERENCE(),
    );

    my $field = QuickBooks::Objects::CustomFieldElement->new(\%your_ref);
    $self->merge_custom_fields([ $field ]);
    return $field->StringValue;
}

sub your_ref {
    my $self = shift;
    use LEMA::Web::Preferences;
    my $res = undef;

    try {
        my $prefs         = LEMA::Web::Preferences->singleton->preferences;
        my $definition_id = $prefs->invoice_custom_field_id(LEMA::CUSTOM_FIELD_YOUR_REFERENCE());

        return undef unless $self->CustomField && @{$self->CustomField};

        for (@{$self->CustomField}) {
            if ($_->DefinitionId == $definition_id) {
                $res = $_->StringValue;
                last;
            }
        }
    }
    catch {
        AE::log error => "%s", $_;
    };

    return $res // undef;
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{txndate_fmt}        = $_[0]->txndate_fmt;
    $res->{totalamt_fmt}       = $_[0]->totalamt_fmt;
    $res->{delivered}          = $_[0]->delivered;
    $res->{duedate_fmt}        = $_[0]->duedate_fmt;
    $res->{creation_date_fmt}        = $_[0]->creation_date_fmt;
    return $res;
}

1;
