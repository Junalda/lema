package LEMA::Object::ID;
use common::sense;
use Carp;
use overload (
    "cmp"    => \&_compare,
    "<=>"    => \&_compare,
    '""'     => \&hex,
    fallback => 1,
);

our $MAX_INC_VAL     = 0xFFFFFF;
our $MAX_INC_VAL_INC = 0x01000000;

sub __rand_bytes_5() {
    my @set = ('0' ..'9', 'a' .. 'z');
    my $str = join '' => map pack("C", int rand 256), 1 .. 5;
    return $str;
}

{
    my $_inc : shared;
    {
        lock($_inc);
        $_inc = int rand($MAX_INC_VAL);
    }

    sub __reset {
        lock($_inc);
        $_inc = $MAX_INC_VAL - 1;
    }

    my $_pid = $$;
    my $_rnd;

    sub CLONE {
        $_rnd = __rand_bytes_5;
    }

    CLONE();

    sub _create_id {
        unless ($$ == $_pid) {
            CLONE();
            $_pid = $$;
        }

        pack('Na5a3',
             $_[0] // time,
             $_rnd,
             substr(
                 pack('N', do { lock($_inc);
                                $_inc++;
                                $_inc %= $MAX_INC_VAL_INC }),
                 1, 3
             )
        );
    }
}

sub new {
    my ($class, %args) = @_;

    my $self = bless { id => $args{id} }, $class;

    $self->{id} //= _create_id();

    croak "ID must be 12 octets"
        unless length $self->id == 12;

    $self
}

sub id { $_[0]{id} }

sub hex {
    my ($self) = @_;
    $self->{_hex} // ($self->{_hex} = unpack("H*", $self->{id}))
}

sub get_time {
    unpack("N", substr($_[0]->{id}, 0, 4))
}

sub _compare {
    $_[2] ? "$_[1]" cmp "$_[0]"
          : "$_[0]" cmp "$_[1]"
}

sub create {
    return LEMA::Object::ID->new unless defined $_[0];
    return LEMA::Object::ID->new(id => $_[0]) if length $_[0] == 12;
    return LEMA::Object::ID->new(id => pack( "H*", $_[0]))
      if $_[0] =~ m{\A[0-9a-f]{24}\z}i;
    croak "Arguments must be 12 packed bytes or 24 bytes of hex";
}

sub TO_JSON { $_[0]->hex }

1;
