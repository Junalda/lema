package LEMA::Config;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ConfigData;
use ACME::E;

our $VERSION = $LEMA::VERSION;
our $JSON    = JSON::XS->new->utf8->convert_blessed->pretty;
our $SINGLETON;

sub new {
    my ($class, $app, $datadir) = @_;

    if (defined $app) {
        die "Invalid LEMA::App object"
            unless $app->$_isa('LEMA::App');
    }

    die "No config data directory"
        unless length $datadir;

    die "Config data directory must end with /"
        unless $datadir =~ m!/$!;

    my $self = { app => $app, datadir => $datadir, _cached_data => undef };

    return $SINGLETON = bless $self, $class;
}

sub singleton {
    my ($class) = @_;
    die "No config singleton" unless $SINGLETON;
    return $SINGLETON;
}

sub has_singleton { !!defined $SINGLETON }

sub app     { $_[0]{app}     }
sub datadir { $_[0]{datadir} }

sub _get_data {
    my $self = shift;
    my $fn   = $self->datadir . 'lema.json';
    my $fh;

    unless (open $fh, '<', $fn) {
        if ($!{ENOENT}) {
        }

        AE::log fatal => "Couldn't open config file %s: %s", $fn, $!;
        my $data = LEMA::Object::ConfigData->new;
        $self->{_cached_data} = $data;
        return $data;
    }

    my $buf = do { local $/ = undef; <$fh> };
    close $fh;

    unless (length $buf) {
        return LEMA::Object::ConfigData->new;
    }

    my $hash = try {
        $JSON->decode($buf);
    } catch {
        AE::log crit => "Couldn't decode JSON of config file %s: %s", $fn, $_;
    };

    my $data = LEMA::Object::ConfigData->new($hash);
    return $self->{_cached_data} = $data;
}

sub _set_data {
    my ($self, $data) = @_;
    die "Invalid config data object"
        unless $data->$_isa('LEMA::Object::ConfigData');

    my $fn  = $self->datadir . 'lema.json';
    my $fnt = sprintf "%s.%s.tmp", $fn, AE::time;
    my $buf = $JSON->encode($data->as_hashref);

    open my $fh, '>', $fnt or die $!;
    print $fh $buf;
    close $fh;

    rename $fnt, $fn or die $!;

    $self->{_cached_data} = $data;
    ()
}

sub data {
    my $self = shift;
    unless ($self->{_cached_data}) {
        return $self->_get_data;
    }
    return $self->{_cached_data};
}

sub save_data {
    my $self = shift;
    $self->_set_data($self->data);
    ()
}

1;
