package LEMA::App;
use common::sense;
use Carp ();
use Getopt::Long ();
use File::Path ();
use Try::Tiny;
use Data::Dumper;
use LEMA;
use LEMA::DB;
use LEMA::Web;
use QuickBooks;
use constant APP_STATE_EMPTY         => 0;
use constant APP_STATE_DB_PROVIDED  => 0b01;
use constant APP_STATE_QBO_PROVIDED => 0b10;
use ACME::E;

$|++;

our $VERSION = $LEMA::VERSION;
our $SINGLETON;

sub new {
    my $class = shift;
    my %class = (
        @_,
        _state => APP_STATE_EMPTY,
        _qbo   => undef,
    );
    return $SINGLETON = bless \%class, $class;
}

sub singleton {
    my ($class) = @_;
    die "No config singleton" unless $SINGLETON;
    return $SINGLETON;
}

sub host         {   $_[0]{host}         }
sub port         {   $_[0]{port}         }
sub datadir      {   $_[0]{datadir}      }
sub config       {   $_[0]{config}       }
sub test         { !!$_[0]{test}         }
sub is_debug     { LEMA::Logging::is_debug }

sub has_state_db_provided  { $_[0]{_state} & APP_STATE_DB_PROVIDED  }
sub has_state_qbo_provided { $_[0]{_state} & APP_STATE_QBO_PROVIDED }

sub db {
    my $self = shift;
    die "Not setter" if @_;
    if (!$self->has_state_db_provided || !LEMA::DB::has_singleton) {
        LEMA::DB->new($self->config->data);
        $self->{_state} |=  APP_STATE_DB_PROVIDED;
        $self->{_state} &= ~APP_STATE_QBO_PROVIDED;
    }

    return LEMA::DB->singleton;
}

sub qbo {
    my $self = shift;
    die "Not setter" if @_;
    die "No active database to get QBO credentials\n"
        unless $self->has_state_db_provided;

    if (!$self->has_state_qbo_provided || !$self->{qbo}) {
        delete $self->{qbo};
        unless ($self->db->inited) {
            die e40 O_APP_QBO_NO_API_CREDS;
        }

        my $profile = $self->db->settings->active_profile;
        if ($profile->qbo) {
            my $qbo = QuickBooks->new(
                -credentials => $profile->qbo,
                -write_cb    => sub {
                    my ($credentials) = @_;
                    $self->db->settings->update_qbo_by_index($profile->index,
                                                             $credentials);
                    ()
                },
            );

            $self->{qbo} = $qbo;


            $self->{_state} |= APP_STATE_QBO_PROVIDED;
        }
        else {
            die e40 O_APP_QBO_NO_API_CREDS;
        }
    }
    return $self->{qbo};
}

sub change_db_and_profile {
    my ($self, $profile_index) = @_;
    die "Invalid profile index" if defined $profile_index &&
                                   $profile_index !~ /^\d+$/;
    $self->{_state} = 0;

    $self->db;
    $self->db->initialize;

    if (defined $profile_index) {
        $self->db->settings->activate_profile_by_index($profile_index);
    }

    $self->qbo;
    ()
}

sub parse_options {
    my $self = shift;

    my $parser = Getopt::Long::Parser->new(
        config => [ "no_auto_abbrev", "no_ignore_case", "pass_through" ],
    );

    AE::log info => "Program arguments in use:\n%s",
                    join("\n", @ARGV);

    $parser->getoptions(
        'host=s'       => \$self->{host},
        'port=i'       => \$self->{port},

        'd|data-dir=s' => \$self->{datadir},

        'h|help'       => \$self->{help},
        'v|version'    => \$self->{version},
        't|test'       => \$self->{test},
    );

    if ($self->{help}) {
        require Pod::Usage;
        Pod::Usage::pod2usage(0);
    }

    my $version_line = "LEMA $LEMA::VERSION";
    if (length $LEMA::GITTAG) {
        $version_line .= " (git tag $LEMA::GITTAG)";
    }

    $version_line .= " Perl/$]";

    if ($self->{version}) {
        print "$version_line\n";
        exit 0;
    }

    AE::log info => "%s started", $version_line;

    unless (length $self->datadir) {
        unless ($LEMA::DIST) {
            use FindBin;
            $self->{datadir} = "$FindBin::Bin/../var/lib/lema";
        }
        else {
            $self->{datadir} = "/var/lib/lema";
        }
    }

    unless ($self->datadir =~ m!/$!) {
        $self->{datadir} .= "/";
    }

    if (length $self->{port}) {
        if ($self->{port} <= 0 || $self->{port} > 0xFFFF) {
            AE::log fatal => "Invalid LEMA web port: %s", $self->{port};
        }
    }
    else {
        $self->{port} = 8080;
    }

    AE::log info => "LEMA IP: %s",   $self->host // '[all interfaces]';
    AE::log info => "LEMA port: %d", $self->port;
    AE::log info => "LEMA path to data directory: %s", $self->datadir;

    ()
}

sub run {
    my $self = shift;

    my $is_debug = !!($ENV{SC_DEBUG} || $ENV{SC_TRACE});
    LEMA::Logging::setup($is_debug, sub {
        $_[0] =~ s/perl/App/gi;
        LEMA::Web::Logs::log_collect($_[0]);
        ()
    });

    unless (ref $self) {
        $self = $self->new;
        $self->parse_options(@_);
        return $self->run;
    }

    LEMA::Static::init;
    LEMA::Static::html5_prefix("html5");

    AE::log info => "Share directory: %s",
                    LEMA::Static::share_dir;
    AE::log info => "Web files directory: %s",
                    LEMA::Static::html5_fs_full_path;

    unless ($] >= 5.022) {
        AE::log fatal => "Perl: Minimum version required 5.022 (yours is %s)",
                         $];
    }

    unless (-d $self->datadir) {
        AE::log warn => "Directory for data files %s doesn't exist",
                        $self->datadir;

        File::Path::mkpath($self->datadir, { error => \my $err });
        for (@$err) {
            my ($key) = keys %$_;
            AE::log fatal => "mkdir %s: %s", $key, $_->{$key};
        }
    }

    {
        AE::log debug => "Test directory for data files...";
        my $file = $self->datadir . ".temp";
        my $fh;
        unless (open $fh, '>', $file) {
            unless ($!{EEXIST}) {
                AE::log fatal => "Couldn't write files to data " .
                                 "directory %s: %s", $self->datadir, $!;
            }
        }
        unlink $file;
        close $fh;
    }

    unless ($self->test) {
        $LEMA::Logging::LOG_FILE = sprintf "%s/%s", $self->datadir,
                                                    $LEMA::Logging::LOG_FILE;
        LEMA::Logging::enable_log_to_file();
    }

    $self->{config} = LEMA::Config->new($self, $self->datadir);

    try { $self->change_db_and_profile } catch { AE::log error => "%s", $_ };

    if ($self->test) {
        AE::log info => "Test for program dependencies and assets is passed";
        exit 0;
    }

    LEMA::Web::init $self;
    LEMA::Web::run  $self;
    ()
}

1;
