package LEMA::Static;
use common::sense;
use Cwd ();
use Data::Dumper;
use File::Spec;
use File::Temp;
use File::Path;
use AnyEvent::Log;
use LEMA;

our $VERSION         = $LEMA::VERSION;
our $STATIC_FALLBACK = 0;

{
    package static;
    use common::sense;

    unless (exists &{static::find}) {
        *{static::find} = sub { };
        $LEMA::Static::STATIC_FALLBACK = 1;
    }

    unless (exists &{static::list}) {
        *{static::list} = sub { };
        $LEMA::Static::STATIC_FALLBACK = 1;
    };
}

my $APP_SHARE_DIR       = "share";
my $HTML5_PREFIX        = "/html5";
my $HTML5_FS_FULL_PATH  = undef;
my $TEMP_DIR            = undef;

sub _update();
sub acme_dir();

sub init() {
    if ($STATIC_FALLBACK) {
        if ($LEMA::DIST) {
            require File::ShareDir;
            $APP_SHARE_DIR = File::ShareDir::dist_dir('LEMA');
        }
        else {
            use FindBin;
            $APP_SHARE_DIR = "$FindBin::Bin/../share";
        }
    }
    else {
    }

    _update;

    unless (defined find_html5("/50x.tmpl")) {
        die "No html5 directory with all files\n";
    }

    ()
}

sub share_dir() { $APP_SHARE_DIR }

sub temp_dir() {
    return $TEMP_DIR if defined $TEMP_DIR;

    return $TEMP_DIR = File::Temp->newdir(
        'lema-XXXXXXXX',
        DIR => "/var/tmp",
        CLEANUP => 1
    );
}

sub html5_prefix(;$) {
    return $HTML5_PREFIX unless @_;
    $HTML5_PREFIX = $_[0];
    _update;
    ()
}

sub _update() {
    $HTML5_FS_FULL_PATH = File::Spec->canonpath(
        $APP_SHARE_DIR . "/" . $HTML5_PREFIX);
    ()
}

sub html5_fs_full_path() {
    return $HTML5_FS_FULL_PATH;
}

sub find_html5 {
    my $uri_path = shift;
    my $name     = $HTML5_FS_FULL_PATH . $uri_path;

    AE::log trace => "Open file '%s'...", $name;

    unless ($STATIC_FALLBACK) {
        return static::find($name);
    }

    open my $fh, '<', $name or return undef;
    binmode $fh;
    my $buf = do { local $/ = undef; <$fh> };
    close $fh;
    return $buf;
}

1;
