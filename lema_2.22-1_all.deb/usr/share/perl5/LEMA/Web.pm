package LEMA::Web;
use common::sense;
use Data::Dumper;
use Try::Tiny;
use Safe::Isa;
use MIME::Base64;
use AnyEvent::Log;
use ACME::Object::Users;
use LEMA;
use LEMA::Object::ID;
use LEMA::Logging;
use LEMA::Static;
use LEMA::Config;
use LEMA::HTTPD::Extended;
use LEMA::Web::File;
use LEMA::Web::Index;
use LEMA::Web::Logs;
use LEMA::Web::CustomersOrders;
use LEMA::Web::SuppliersOrders;
use LEMA::Web::Customers;
use LEMA::Web::Suppliers;
use LEMA::Web::Products;
use LEMA::Web::Stock;
use LEMA::Web::Accounts;
use LEMA::Web::Tax;
use LEMA::Web::Term;
use LEMA::Web::Preferences;
use LEMA::Web::Notifications;
use LEMA::Web::Settings;
use LEMA::Web::Webhook;

our $VERSION = $LEMA::VERSION;

our $httpd;
our %apps;
our %requests;

our @userlist = (
    { username => "lema", password => "password" },
);

sub init_httpd($) {
    my ($app) = @_;

    AE::log fatal => "Invalid LEMA::App object"
        unless $app->$_isa('LEMA::App');

    $httpd = try {
        LEMA::HTTPD::Extended->new(host => $app->host,
                                            port => $app->port);
    } catch {
        warn $_;
        undef
    };

    AE::log fatal => "Couldn't start LEMA webserver"
        unless $httpd;

    $httpd->{_DEBUG} = LEMA::Logging::is_debug;

    $httpd->reg_cb(request => sub {
        my ($httpd, $req) = @_;
        my $url      = $req->url;
        my @segments = $url->path_segments;
        my $headers  = $req->headers;
        my $auth_val = $headers->{authorization};
        my $ask_cred = 1;
        my $users;

        $req->restricted_area(1);
        $app->db->initialize unless $app->db->inited;

        if ($app->db->inited) {
            my $profile = $app->db->settings->active_profile;
            $users = $profile->users;
        }

        if (length $auth_val && $auth_val =~ /^Basic\s+(\S+)/i) {
            $auth_val = MIME::Base64::decode_base64 $1;
            if ($auth_val =~ /^([^\:]+):(.+)$/) {
                my ($username, $password) = ($1, $2);
                AE::log debug => "Check if user '%s' can be authorized...",
                                 $username;

                if ($users) {
                    my $auth_user = $users->get_authorized_user($username,
                                                                $password);
                    if ($auth_user) {
                        if ($auth_user->role > 0) {
                            AE::log debug => "User %s is authorized with role %u",
                                             $username, $auth_user->role;

                            $req->role($auth_user->role);
                            $req->username($auth_user->username);
                        } else {
                            AE::log debug => "User %s is authenticated, but not authorized (no role)",
                                             $username;

                            if ($req->url !~ m!^/lema/v1/logout($|/)!) {
                                $req->respond_403_with_logout;
                                $httpd->stop_request;
                                return;
                            }
                        }
                        $ask_cred = 0;
                    }
                } else {
                    if ($username eq $LEMA::DB::Settings::DEFAULT_USERNAME ||
                        $password eq $LEMA::DB::Settings::DEFAULT_PASSWORD) {
                        $req->role(ACME::Object::User::ROLE_ADMINISTRATOR());
                        $req->username($username);
                        $ask_cred = 0;
                    }
                }
            }
        }

        if ($ask_cred) {
            if ($req->url =~ m!/lema/v1/qbo-webhook(\?|$)!) {
                AE::log debug => "Password is not required for QBO webhook";
                $ask_cred = 0;
            }
        }

        if ($ask_cred) {
            $req->respond_401;
            $httpd->stop_request;
            return;
        }

        if (@segments >= 2 && $segments[0] == '') {
            unless ($app->db->inited) {
                unless ($req->url =~ m!^/lema/v1/settings(/database)?($|\?)?! ||
                        $req->url =~ m!^/lema/v1/assets/!) {
                    $req->respond_302("/lema/v1/settings");
                    $httpd->stop_request;
                    return;
                }
            }
            return;
        }

        $req->respond_404($req);
        $httpd->stop_request;
        ()
    });
    ()
}

sub init_httpd_routing($) {
    my ($app) = @_;

    AE::log fatal => "Invalid LEMA::App object"
        unless $app->$_isa('LEMA::App');

    try {
    $apps{index}     = new LEMA::Web::Index;
    $apps{file}      = new LEMA::Web::File;

    $apps{notifications} = new LEMA::Web::Notifications
                                -app => $app, -config => $app->config;

    $apps{settings}  = new LEMA::Web::Settings
                                -app => $app, -config => $app->config;


    $apps{products}  = new LEMA::Web::Products
                                -app => $app, -config => $app->config;

    $apps{stock}  = new LEMA::Web::Stock
                                -app => $app, -config => $app->config;

    $apps{accounts}  = new LEMA::Web::Accounts
                                -app => $app, -config => $app->config;
    $apps{tax}       = new LEMA::Web::Tax
                                -app => $app, -config => $app->config;
    $apps{term}      = new LEMA::Web::Term
                                -app => $app, -config => $app->config;
    $apps{preferences}      = new LEMA::Web::Preferences
                                -app => $app, -config => $app->config;



    $apps{customers}  = new LEMA::Web::Customers
                                -app => $app, -config => $app->config;
    $apps{suppliers}    = new LEMA::Web::Suppliers
                                -app => $app, -config => $app->config;
    $apps{corders}    = new LEMA::Web::CustomersOrders
                                -app => $app, -config => $app->config;
    $apps{sorders}    = new LEMA::Web::SuppliersOrders
                                -app => $app, -config => $app->config;

    $apps{logs}       = new LEMA::Web::Logs;

    $apps{webhook}   = new LEMA::Web::Webhook
                                -app => $app, -config => $app->config;

    };

    my %logout_sessions;

    %requests = (
        ''                   => $apps{index}->app_cb,
        '/'                  => $apps{index}->app_cb,
        '/lema'              => $apps{index}->app_cb,
        '/lema/v1'           => $apps{index}->app_cb,
        '/lema/v1/assets'    => $apps{file}->app_cb,

        '/lema/v1/assets'    => $apps{file}->app_cb,
        '/lema/v1/notifications' => $apps{notifications}->app_cb,
        '/lema/v1/qbo-webhook'   => $apps{webhook}->app_cb,
        '/lema/v1/settings' => $apps{settings}->app_cb,
        '/lema/v1/products'    => $apps{products}->app_cb,
        '/lema/v1/stock'    => $apps{stock}->app_cb,
        '/lema/v1/accounts'    => $apps{accounts}->app_cb,
        '/lema/v1/accounts/tax' => $apps{tax}->app_cb,
        '/lema/v1/suppliers'      => $apps{suppliers}->app_cb,
        '/lema/v1/customers'      => $apps{customers}->app_cb,
        '/lema/v1/customers/orders' => $apps{corders}->app_cb,
        '/lema/v1/suppliers/orders' => $apps{sorders}->app_cb,
        '/lema/v1/logs'      => $apps{logs}->app_cb,

        '/lema/v1/logout'       => sub {
            my ($httpd, $req) = @_;
            $httpd->stop_request;
            my $uniq_id = LEMA::Object::ID->new;
            $logout_sessions{$uniq_id} = 1;
            $req->respond_302("/lema/v1/logout/request/$uniq_id");
            ()
        },

        '/lema/v1/logout/request' => sub {
            my ($httpd, $req) = @_;
            $httpd->stop_request;
            my $url = $req->url;


            if ($url =~ m!/lema/v1/logout/request/(\w+)$!) {
                my $uniq_id = $1;
                if (exists $logout_sessions{$uniq_id}) {
                    if ($logout_sessions{$uniq_id} == 1) {
                        $logout_sessions{$uniq_id} = 0;
                        $req->respond_401;#(TL::App::base::realm());
                    } else {
                        $req->respond_302('/');
                    }
                }
                else {
                    $req->respond_302('/lema/v1/logout');
                }
            } else {
                $req->respond_404($req);
            }
            ()
        },

    );

    $httpd->request_cb(%requests);
    ()
}

sub init($) {
    my ($app) = @_;

    init_httpd         $app;
    init_httpd_routing $app;

    AE::log info => "Listening on %s:%d.", $httpd->host, $httpd->port;
    ()
}

sub run($) {
    my ($app) = @_;
    my $health = 0;

    my $w = AE::timer 5, 5, sub {
        $health++;
        $health = 0 if $health == 0xFFFFFFFF;
    };

    my ($w2, $ib);

    AE::log fatal => "Service is not initialized" unless $httpd;
    AE::cv->recv;
    AE::log info => "App quits...";
    ()
}

1;
