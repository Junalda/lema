package QuickBooks;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use AnyEvent::Log;
use QuickBooks::Utils::Date;
use QuickBooks::Globals;
use QuickBooks::Objects;
use QuickBooks::useragent;
use QuickBooks::CompanyInfo;
use QuickBooks::Customer;
use QuickBooks::InventoryValuationSummary;
use QuickBooks::Invoice;
use QuickBooks::Account;
use QuickBooks::Item;
use QuickBooks::Purchase;
use QuickBooks::PurchaseOrder;
use QuickBooks::Bill;
use QuickBooks::TaxRate;
use QuickBooks::TaxCode;
use QuickBooks::TaxAgency;
use QuickBooks::Term;
use QuickBooks::Preferences;
use QuickBooks::Vendor;

sub new {
    my ($class, %args) = @_;

    if (QuickBooks::Utils::Date::str_to_gmt_date('2021-05-09') ne '2021-05-09') { die 'Bad date' }
    if (QuickBooks::Utils::Date::str_to_gmt_date('25/03/2021') ne '2021-03-25') { die 'Bad date' }
    if (QuickBooks::Utils::Date::str_to_gmt_date('01/02/2021') ne '2021-02-01') { die 'Bad date' }

    $args{_ua} = QuickBooks::useragent->new(%args);
    $args{_ch} = +{};

    bless \%args, $class;
}

sub ua { $_[0]{_ua} }

sub company_info {
    $_[0]->{_ch}{company_info} ||= new QuickBooks::CompanyInfo $_[0];
}

sub customer {
    $_[0]->{_ch}{customer} ||= new QuickBooks::Customer $_[0];
}

sub vendor {
    $_[0]->{_ch}{vendor} ||= new QuickBooks::Vendor $_[0];
}

sub invoice {
    $_[0]->{_ch}{invoice} ||= new QuickBooks::Invoice $_[0];
}

sub account {
    $_[0]->{_ch}{account} ||= new QuickBooks::Account $_[0];
}

sub payment {
    $_[0]->{_ch}{payment} ||= new QuickBooks::Payment $_[0];
}

sub deposit {
    $_[0]->{_ch}{deposit} ||= new QuickBooks::Deposit $_[0];
}

sub item {
    $_[0]->{_ch}{item} ||= new QuickBooks::Item $_[0];
}

sub purchase {
    $_[0]->{_ch}{purchase} ||= new QuickBooks::Purchase $_[0];
}

sub purchase_order {
    $_[0]->{_ch}{purchase} ||= new QuickBooks::PurchaseOrder $_[0];
}

sub bill {
    $_[0]->{_ch}{bill} ||= new QuickBooks::Bill $_[0];
}

sub tax_rate {
    $_[0]->{_ch}{tax_rate} ||= new QuickBooks::TaxRate $_[0];
}

sub tax_code {
    $_[0]->{_ch}{tax_code} ||= new QuickBooks::TaxCode $_[0];
}

sub tax_agency {
    $_[0]->{_ch}{tax_agency} ||= new QuickBooks::TaxAgency $_[0];
}

sub term {
    $_[0]->{_ch}{term} ||= new QuickBooks::Term $_[0];
}

sub bill_payment {
    $_[0]->{_ch}{bill_payment} ||= new QuickBooks::BillPayment $_[0];
}

sub journalentry {
    $_[0]->{_ch}{journalentry} ||= new QuickBooks::JournalEntry $_[0];
}

sub transaction_list {
    $_[0]->{_ch}{transaction_list} ||= new QuickBooks::TransactionList $_[0];
}

sub inventory {
    $_[0]->{_ch}{inventory} ||= new QuickBooks::InventoryValuationSummary $_[0];
}

sub preferences {
    $_[0]->{_ch}{preferences} ||= new QuickBooks::Preferences $_[0];
}

sub sugar {
    $_[0]->{_ch}{sugar} ||= new QuickBooks::Sugar $_[0];
}

1;
