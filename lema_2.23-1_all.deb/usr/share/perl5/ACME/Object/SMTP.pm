package ACME::Object::SMTP;
use common::sense;
use boolean;
use Data::Dumper;
use Digest::SHA;
use Try::Tiny;
use Safe::Isa;
use ACME::Data;
use Woof;
use ACME::Claim;
use ACME::E;

our $VERSION = 0.01;

PUBLIC (package    => OF 'str_ne') = __PACKAGE__;
PUBLIC (version    => OF 'float')  = $VERSION;
PUBLIC (host       => OF 'str_ne');
PUBLIC (port       => OF 'int')    = 465;
PUBLIC (username   => OF 'str_ne');
PUBLIC (password   => OF 'str_ne');
PUBLIC (from_email => OF 'str_ne');

sub _package_ {
    VALIDATE;
    die "Package is not handled: $_[1]" unless $_[0]->$_isa($_[1]);
    return $_[1];
}

sub _version_ {
    VALIDATE;
    die "Package is handled for versions not greater than $VERSION"
        unless $_[1] <= $VERSION;
    return $_[1];
}

sub _host_ {
    my $self = shift;
    die "No SMTP host or IP\n" unless length $_[0];
    VALIDATE;
    unless ($_[0] =~ /^[A-Za-z0-9\.\-]+$/) {
        die "Invalid SMTP host or IP\n";
    }

    return $_[0];
}

sub _port_ {
    my ($self, $in) = @_;
    $in = 465 unless length $in;
    die "Port must be in range of 1 to 65535\n"
        unless $in >= 1 && $in <= 65535;
    return $in;
}

sub _username_ {
    my $self = shift;
    die "No username\n" unless length $_[0];
    VALIDATE;
    die "Username is too long (more than 128 characters)\n"
        unless length $_[0] <= 128;
    return $_[0];
}

sub _password_ {
    my $self = shift;
    die "No password\n" unless length $_[0];
    VALIDATE;
    die "Password is too long (more than 128 characters)\n"
        unless length $_[0] <= 128;
    return $_[0];
}

sub _from_email_ {
    my ($self, $in) = @_;
    die "No email address to send emails from\n" unless length $in;
    VALIDATE;

    die "Invalid email address to send emails from\n"
        unless ACME::Data::is_valid_email $in;
    return $in;
}

sub from_email_address {
    my $self = shift;
    my $full = $self->from_email;
    if ($full =~ /\<([^\<\>]+)\>/) {
        my $addr = $1;
        if ($addr =~ /\@/) {
            return $addr;
        }
    }

    return $full;
}

sub from_email_company {
    my $self = shift;
    my $full = $self->from_email;
    if ($full =~ /\(([^\(\)]+)\)/) {
        my $company = $1;
        return $company;
    }

    return undef;
}

sub from_email_fullname {
    my $self = shift;
    my $full = $self->from_email;
    if ($full =~ /\"([^\"]+)\"/) {
        return $1;
    }
    return undef;
}

sub from_email_with_fullname {
    my $self = shift;
    my $fullname = $self->from_email_fullname;
    my $email    = $self->from_email_address;
    return '"' . $fullname . '" ' . '<' . $email . '>';
}

1;
