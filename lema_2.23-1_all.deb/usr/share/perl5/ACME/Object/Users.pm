package ACME::Object::Users;
use common::sense;
use ACME::E
    O_USERS_INVALID_USERNAME    => [ 3603, "Username may contain lower-case latin characters, _, -, . and be less than 32 characters" ],
    O_USERS_NO_USERNAME         => [ 3605, "Username required" ],
    O_USERS_INVALID_EMAIL       => [ 3606, "Invalid email" ],
    O_USERS_INVALID_PASSWORD    => [ 3607, "Invalid password" ],
    O_USERS_NO_PASSWORD         => [ 3610, "No password" ],
    O_USERS_USER_DUP            => [ 3611, "Username duplicate detected" ],
;
our $VERSION = 0.01;

package ACME::Object::User;
use common::sense;
use boolean;
use Data::Dumper;
use Digest::SHA;
use Try::Tiny;
use Safe::Isa;
use ACME::Data;
use Woof;
use ACME::Claim;
use ACME::E;
use constant ROLE_DISABLED      => 0b000;
use constant ROLE_ADMINISTRATOR => 0b001;
use constant ROLE_WAREHOUSE     => 0b010;

use constant PASSTYPE_SHA512    => 0b001;

our $VERSION = $ACME::Object::Users::VERSION;

my %PASSHASH_FUNCS = (
    PASSTYPE_SHA512() => sub ($$) {
        my $pwd = shift;
        utf8::encode $pwd;
        return Digest::SHA::sha512_hex($pwd . "\x00" . $_[0]);
    },
);

sub __get_passhash_func($) {
    my $passhash_func = $PASSHASH_FUNCS{$_[0]};
    claim { ref $passhash_func eq 'CODE' };
    return $passhash_func;
}

PUBLIC (package  => OF 'str_ne') = __PACKAGE__;
PUBLIC (version  => OF 'float')  = $VERSION;
PUBLIC (username => OF 'str_ne');
PUBLIC (passsalt => OF 'str_ne') = sub { ACME::Data::randstr24 };
PUBLIC (passtype => OF 'int') = PASSTYPE_SHA512;
PUBLIC (passhash => UNDEFOK OF 'strnull') = undef;
PUBLIC (password => UNDEFOK OF 'strnull') = undef;
PUBLIC (role     => OF 'int')             = ROLE_DISABLED;
PUBLIC (fullname => UNDEFOK OF 'strnull') = undef;
PUBLIC (email    => UNDEFOK OF 'strnull') = undef;

sub _package_ {
    VALIDATE;
    die "Package is not handled: $_[1]" unless $_[0]->$_isa($_[1]);
    return $_[1];
}

sub _version_ {
    VALIDATE;
    die "Package is handled for versions not greater than $VERSION"
        unless $_[1] <= $VERSION;
    return $_[1];
}

sub _role_ {
    my $self = shift;
    die "Invalid user role\n"
        unless $_[0] == ROLE_DISABLED ||
               $_[0] == ROLE_ADMINISTRATOR  ||
               $_[0] == ROLE_WAREHOUSE;
    return $_[0];
}

sub _email_ {
    my $self = shift;
    VALIDATE;
    if (defined $_[0]) {
        die e40 O_USERS_INVALID_EMAIL
            unless ACME::Data::is_valid_email $_[0];
    }
    return $_[0];
}

sub _passtype_ {
    my $self = shift;
    VALIDATE;
    die "Unknown password hash type"
        unless $_[0] == PASSTYPE_SHA512;
    return $_[0];
}

sub _passsalt_ {
    my $self = shift;
    VALIDATE;
    die "Salt length cannot be greater than 24 characters"
        if length $_[0] > 24;
    return $_[0];
}

sub _password_ {
    my $self = shift;
    VALIDATE;
    if (defined $_[0]) {
        die e40 O_USERS_INVALID_PASSWORD
            unless ACME::Data::is_valid_password $_[0];

        $self->passhash(__get_passhash_func($self->passtype)->
                                           ($_[0], $self->passsalt));
    } else {
        unless (defined $self->passhash) {
            die e40 O_USERS_NO_PASSWORD
                unless length $_[0];
        }
        else {
        }
    }

    return undef;
}

sub _username_ {
    my $self = shift;
    die e40 O_USERS_NO_USERNAME
        unless length $_[0];
    die e40 O_USERS_INVALID_USERNAME
        unless ACME::Data::is_valid_username $_[0];
    return $_[0];
}

sub check_auth {
    my $self = shift;

    return 0 unless $self->username eq $_[0];

    my $passhash = __get_passhash_func($self->passtype)->
                                      ($_[1], $self->passsalt);

    return $passhash eq $self->passhash ? 1 : 0;
}

package ACME::Object::Users;
use common::sense;
use boolean;
use Data::Dumper;
use Safe::Isa;
use Woof;
use ACME::Claim;
use ACME::E;

PUBLIC (package => OF 'str_ne') = __PACKAGE__;
PUBLIC (version => OF 'float')  = $VERSION;
PUBLIC (count   => OF 'int')   = 0;
PUBLIC (list    => OF 'ARRAY') = sub { [] };

sub _list_ {
    my ($self, $in) = @_;
    VALIDATE;
    if (ref $in eq 'CODE') { $in = $in->(); }

    my %uniq;
    for my $el (@$in) {
        my $user     = ACME::Object::User->new($el);
        my $username = $user->username;
        if (exists $uniq{$username}) {
            die "Username duplicate detected\n";
        } else {
            $uniq{$username} = 1;
        }

        $el = $user;
    }

    $self->count(scalar keys %uniq);

    return $in;
}

sub add {
    my ($self, $user) = @_;
    claim { $user->$_isa('ACME::Object::User') };
    if ($self->count) {
        my $username = $user->username;
        for (@{$self->list}) {
            if ($_->username eq $username) {
                die e40 O_USERS_USER_DUP;
            }
        }
    }

    push @{$self->list}, $user;
    $self->count($self->count + 1);
    ()
}

sub get_authorized_user {
    my $self = shift;
    return undef unless $self->count;
    for (@{$self->list}) {
        $_->check_auth($_[0], $_[1]) and return $_;
    }
    return undef;
}

sub amend_pass {
    my ($self, $aref) = @_;
    claim { ref $aref eq 'ARRAY' };
    for my $href (@$aref) {
        next unless length $href->{username};
        next if length $href->{password};
        for (@{$self->list}) {
            if ($_->username eq $href->{username}) {
                $href->{passsalt} = $_->passsalt;
                $href->{passtype} = $_->passtype;
                $href->{passhash} = $_->passhash;
            }
        }
    }
    ()
}

sub get_user_by_username {
    my ($self, $username) = @_;

    die O_USERS_INVALID_USERNAME
        unless ACME::Data::is_valid_username $username;

    for (@{$self->list}) {
        if ($_->username eq $username) {
            return $_;
        }
    }
    return undef;
}

sub get_email_by_username {
    my ($self, $username) = @_;
    my $user = $self->get_user_by_username($username);
    die "Username $username is not found\n" unless $user;
    return $user->email;
}

1;
