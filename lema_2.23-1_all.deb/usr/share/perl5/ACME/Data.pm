package ACME::Data;
use common::sense;
use Carp;
use POSIX;
use DateTime;
use Safe::Isa;


sub yyyymmdd(;$) {
    my ($epoch) = @_;
    $epoch = time unless length $epoch;
    my($y, $m, $d) = (gmtime($epoch))[5,4,3];
    $y += 1900;
    $m += 1;
    return sprintf "%04d-%02d-%02d", $y, $m, $d;
}

sub local_yyyymmdd(;$) {
    my ($epoch) = @_;
    $epoch = time unless length $epoch;
    my ($y, $m, $d) = (localtime($epoch))[5,4,3];
    $y += 1900;
    $m += 1;
    return sprintf "%04d-%02d-%02d", $y, $m, $d;
}

sub local_yyyy(;$) {
    my ($epoch) = @_;
    $epoch = time unless length $epoch;
    my ($y) = (localtime($epoch))[5,4,3];
    $y += 1900;
    return sprintf "%04d", $y;
}

sub local_tz(;$) {
    my $epoch = shift;
    return strftime("%Z", localtime($epoch));
}

sub localtime_tz(;$) {
    my $epoch = shift;
    return localtime($epoch) . ' ' . strftime("%Z", localtime($epoch));
}

sub epoch_from_yyyymmdd($) {
    die "Invalid date YYYY-mm-dd"
        unless $_[0] =~ /^(\d{4}).(\d{2}).(\d{2})$/;

    my $dt = DateTime->new(
        year   => $1,
        month  => $2,
        day    => $3,
        hour   => 0,
        minute => 0,
        second => 0,
        nanosecond => 0,
        time_zone  => 'UTC'
    );

    return $dt->epoch;
}

sub epoch_from_yyyymmdd_rand_time($) {
    die "Invalid date YYYY-mm-dd"
        unless $_[0] =~ /^(\d{4}).(\d{2}).(\d{2})$/;

    my $dt = DateTime->new(
        year   => $1,
        month  => $2,
        day    => $3,
        hour   => int(rand 24),
        minute => int(rand 60),
        second => int(rand 60),
        nanosecond => 0,
        time_zone  => 'UTC'
    );

    return $dt->epoch;
}

sub yyyy_mm_dd_hh_mm_ss_tz($) {
    die "Invalid datetime YYYY-mm-dd HH:MM:SS TZ"
        unless $_[0] =~ /^(\d{4}).(\d{2}).(\d{2})
                          .
                          (\d{2}).(\d{2}).(\d{2})
                          .(\S+)$/x;

    my $tz = $7;
    if ($tz eq '000Z') {
        $tz = 'GMT';
    }

    return DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => $7,
    );
}

sub epoch_from_yyyy_mm_dd_hh_mm_ss_ms($) {
    die "Invalid datetime YYYY-mm-ddTHH:MM:SS.msZ"
        unless $_[0] =~ /^(\d{4}).(\d{2}).(\d{2})
                          .
                          (\d{2}).(\d{2}).(\d{2})
                          .(\S+)Z$/x;

    my $ms = $7;
    my $dt = DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => 'GMT',
    );

    my $epoch = $dt->epoch;
    $epoch .= '.' . $ms;
    return $epoch + 0;
}

sub timenum_fmt($) {
    my ($timenum) = @_;
    die "Invalid timenum" unless $timenum =~ /^\d+$/;
    $timenum = int $timenum;
    die "Invalid timenum range" unless $timenum >= 0 && $timenum <= 235959;
    my $fill = 6 - length $timenum;
    for (my $i = 0; $i < $fill; $i++) {
        $timenum = '0' . $timenum;
    }
    $timenum =~ m!^(\d{2})(\d{2})(\d{2})$!;
    return "$1:$2:$3";
}

sub datenum($) {
    my $date = shift;
    $date =~ s!\D!!g;
    die "Invalid date for YYYYMMDD format" unless length $date == 8;
    return $date;
}

sub dbl_cast($) {
    return unpack('d', pack('d', sprintf "%.3f", $_[0]));
}

sub DateTime::datetime_psql {
    return $_[0]->strftime("%Y-%m-%d %H:%M:%S %Z");
}

sub print_amount($) {
    my ($amount) = @_;
    $amount = sprintf "%.2f", $amount;
    my @parts = split /\./, $amount;
    my @rev = reverse split //, $parts[0];
    my $i = 0;
    my $buf = '';
    for (@rev) {
        if ($i == 3) {
            $i = 0;
        }
        $buf .= $_;
        $i++;
    }
    $buf = reverse $buf;
    $parts[1] = ",00" unless length $parts[1];

    return "$buf,$parts[1]";
}

sub adjust_amount($) {
    my ($amount) = @_;
    return "" unless length $amount;

    $amount =~ s/,/./g;
    $amount = '0' . $amount if $amount =~ /^[\.,]/;
    $amount =~ s/\.+$//g;
    my @arr = split /\./, $amount;
    if (@arr >= 2) {
        $arr[1] = '.' . $arr[1];
    }
    $amount = join '', @arr;
    return sprintf "%.2f", $amount;
}

sub adjust_int($) {
    my ($amount) = @_;
    return "" unless length $amount;
    $amount =~ s![,\.]!!g;
    $amount += 0;
    return $amount;
}

sub is_valid_ipv4($) {
    my $ip  = shift;
    my $ipn = AnyEvent::Socket::parse_ipv4($ip);

    if (defined $ipn && $ip =~ /^\d+\.\d+\.\d+\.\d+$/) {
        return 1;
    }

    return 0;
}

sub is_valid_host($) {
    my $host = shift;
    return 0 unless length $host;
    return 1 if is_valid_ipv4($host);
    return 0 unless length $host < 256;
    return 0 unless $host =~ /^[a-zA-Z0-9\.\-]+$/;
    return 0 unless $host =~ /\./;
    return 0 if $host =~ /^\./ || $host =~ /\.$/;
    return 1;
}

sub is_valid_port($) {
    my $port = shift;
    return 0 unless length $port;
    return 0 unless $port =~ /^\d{1,5}$/;
    return 0 if $port <= 0 || $port > 65535;
    return 0 if $port >= 25000 && $port <= 25032;
    return 1;
}

sub is_valid_username($) {
    return 0 if $_[0] =~ /\:/;
    return 0 unless $_[0] =~ /^[a-z0-9_\-\.]+$/;
    return 0 if length $_[0] > 32;
    return 1;
}

sub is_valid_password($) {
    return !!($_[0] =~ /^[\w\-\.]{1,32}$/)
}

sub is_valid_email($) {
    return 0 unless $_[0] =~ /\@/;
    return 0 if $_[0] =~ /\:/;
    return 1;
}

sub randstr24() {
    my @set = ('0' ..'9', 'a' .. 'z');
    my $str = join '' => map $set[int(rand scalar @set)], 1 .. 24;
    return $str;
}

sub merge_2d_matrix_N_S($$$) {
    my ($a1, $a2, $add_zero_qty) = @_;

    my @merge;
    for my $el2 ((@$a1, @$a2)) {
        my ($N_cand, $S_cand, $status_cand) = @$el2;
        my $found = 0;

        for my $el1 (@merge) {
            my ($N, $S, $status) = @$el1;
            if ($S eq $S_cand) {
                $el1->[0] += $N_cand;

                if (defined $el1->[2]) {
                } else {
                    if (defined $status_cand) {
                        $el1->[2] = $status_cand;
                    }
                }

                $found = 1;
                last;
            }
        }

        unless ($found) {
            push @merge, [ $N_cand, $S_cand, $status_cand ];
        }
    }

    if (@merge) {
        @merge = sort { $b->[0] <=> $a->[0]
                            or
                        $a->[1] cmp $b->[1] } @merge;

        my @new;
        for (@merge) {
            push @new, $_ if $add_zero_qty || $_->[0] != 0;
        }
        return \@new;
    }

    return \@merge;
}

1;
