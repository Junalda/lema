package ACME::Claim;
use strict;
use warnings;
use Carp ();
use base 'Exporter';
use overload (
    '""'     => \&longmess,
    fallback => 1,
);

$Carp::CarpInternal{(__PACKAGE__)} = 1;

our @EXPORT  = qw(claim);
our $VERSION = 0.01;

sub claim(&;$) {
    local $@;
    my $retval = eval { !!$_[0]->() };
    return 1 if !length $@ && $retval;

    my $e    = $@;
    my $msg  = "Claim failed" . (@_ >= 2 && length $_[1] ? ": $_[1]" : "");
    my $excp = bless {
        longmess  => Carp::longmess($msg) .
                    (length $e ? "Claim validator failed: $e" : ""),

        shortmess => $msg . (length $e ? ": $e" : ""),

        caller => [ caller(0) ],
    };

    die $excp;
    ()
}

sub TO_JSON {
    my $self = shift;
    return $self->{shortmess};
}

sub longmess   : method { $_[0]{longmess}  }
sub caller     : method { $_[0]{caller}    }
sub package    : method { $_[0]{caller}[0] }
sub filename   : method { $_[0]{caller}[1] }
sub line       : method { $_[0]{caller}[2] }
sub subroutine : method { $_[0]{caller}[3] }

1;
