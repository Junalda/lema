package Woof::_Blesser;
use strict;
use warnings;
use Carp;
use Data::Dumper;
use Scalar::Util;
use Safe::Isa;
$Carp::Internal{'Woof::_Blesser'} = 1;

sub OUTWOOF_non_recursive {
    return _outwoof($_[0], 0);
}

sub OUTWOOF {
    return _outwoof($_[0], 1);
}

sub _outwoof {
    my ($self, $recursive_enabled) = @_;

    Carp::confess("Blessed object is required: ", $self // '<undef>')
        unless Scalar::Util::blessed($self);

    my $class = ref $self;

    my $members = do {
        no strict 'refs';
        &{$class . '::MEMBERS'}
    };

    my %keys;
    @keys{keys %$self} = undef;

    my %hash;

    for (@$members) {
        my $name = $_->{name};
        my $type = $_->{type};

        if ($recursive_enabled ||
            !exists &{$type . '::MEMBERS'}
        ) {
            if ($_->{outwoof_cb}) {
                $hash{$name} = defined $self->{$name}
                             ? $_->{outwoof_cb}->($self->{$name})
                             : undef;
            } else {
                if (defined $type && length $type) {
                    no strict 'refs';
                    $hash{$name} = defined $self->{$name}
                                 ? &{$type . '::OUTWOOF'}($self->{$name})
                                 : undef;
                }
                else {
                    $hash{$name} = $self->{$name};
                }
            }
        }
        else {
            $hash{$name} = $self->{$name};
        }

        delete $keys{$name};
    }

    return \%hash;
}

sub WOOF {
    my ($class, $hashref) = @_;

    if (Scalar::Util::blessed($class)) {
        croak "Must be a class name, not object: `$class'";
    }

    my $members = do {
        no strict 'refs';
        &{$class . '::MEMBERS'}
    };

    my %keys;
    @keys{keys %$hashref} = undef;

    my $ret_ok = 1;

    my $self = bless +{}, $class;

    for (@$members) {
        my $name = $_->{name};

        local $_->{flags} = Woof::FLAG_INWOOF();

        my $count = () = $self->$name($hashref->{$name});

        if ($count == 0) {
            $ret_ok = 0;
        }

        delete $keys{$name};
    }

    return $ret_ok ? $self : ();
}

sub FREEZE {
    my ($self, $serialiser) = @_;
    return $self->OUTWOOF_non_recursive;
}

sub TO_JSON {
    my $self = shift;
    return $self->OUTWOOF_non_recursive;
}

sub JSON {
    my $self = shift;
    my $json = Woof::json_coder();
    return $json->encode($self);
}

sub FROM_JSON {
    my ($class, $json_str) = @_;

    my $pp = Woof::json_coder()->decode($json_str);

    return $class->WOOF($pp);
}

1;
