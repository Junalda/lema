package Woof::_Members;
use strict;
use warnings;
use Carp;

$Carp::Internal{'Woof::_Members'} = 1;

sub insert {
    my $class   = shift;
    my $name    = shift;

    Carp::croak("Invalid variable name")
        unless defined $name && !ref $name && $name =~ /^[a-z_]\w*$/i;

    my $member = $_[0] || Woof::_Member->new;

    $member->{name}  = $name;
    $member->{class} = $class;

    my $members = do {
        no strict 'refs';
        &{$class . '::MEMBERS'}
    };

    for (0 .. $#$members) {
        if ($members->[$_]{name} eq $name) {
            no strict 'refs';
            if ($_->{orig_cb}) {
                *{$class . '::' . $name} = $_->{orig_cb};
            }
            else {
                undef &{$class . '::' . $name};
            }

            splice @$members, $_, 1;
            last;
        }
    }

    if (1) {
        no strict 'refs';

        if (exists &{$class . '::_' . $name}) {
            $member->{orig_cb} = \&{$class . '::_' . $name};
        }
        elsif (exists &{$class . '::_' . $name . '_'}) {
            $member->{orig_cb} = \&{$class . '::_' . $name . '_'};
        }
        else {
        }

        if ($member->{type}) {

            if (exists &{$member->{type} . '::WOOF'}) {
                $member->{woof_cb}    = \&{$member->{type} . '::WOOF'};
            }
            if (exists &{$member->{type} . '::OUTWOOF'}) {
                $member->{outwoof_cb} = \&{$member->{type} . '::OUTWOOF'};
            }
            if (exists &{$member->{type} . '::INWOOF'}) {
                $member->{inwoof_cb} = \&{$member->{type} . '::INWOOF'};
            }
        }

        *{$class . '::' . $name} = sub {
            use Data::Dumper;
            my $local_member;
            my $local_members = $_[0]->MEMBERS;
            for (0 .. $#$local_members) {
                if ($local_members->[$_]{name} eq $name) {
                    $local_member = $local_members->[$_];
                    last;
                }
            }

            unless ($local_member) {
                Carp::croak("No member hashref");
            }

            Woof::_Wrapper::wrapper($local_member, @_);
        };
    }

    push @$members, $member;

    return $member;
}

1;
