package Woof::ISA::boolean;
use strict;
use warnings;
use Scalar::Util;
use boolean ();

sub boolean::INWOOF() {
    my @args = @_;
    my $bad  = !!(@args > 1);

    unless ($bad) {
        if (ref $args[0]) {
            unless (Scalar::Util::blessed($args[0])) {
                $bad = 1;
            }
            else {
                if (Scalar::Util::reftype($args[0]) eq 'SCALAR') {
                    $args[0] = !!${$args[0]};
                }
                else {
                    $bad = 1;
                }
            }
        }
    }

    Carp::croak("Invalid boolean value: ",
            join(',', map { $_ // '<undef>' } @args))
        if $bad;

    $_->referent = boolean::boolean($args[0]);

    ()
}

sub boolean::OUTWOOF() {
    boolean::boolean($_[0])
}

1;
