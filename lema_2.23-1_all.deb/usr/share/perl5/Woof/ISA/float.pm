package Woof::ISA::float;
use strict;
use warnings;
use Carp;

sub float::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid float number for `$_->{name}': ",
            join(', ', map { $_ // '<undef>' } @args))
        unless @args == 1 && defined $args[0] && $args[0] =~ /^-?\d+(\.\d+)?$/;

    $_->referent = unpack("d", pack("d", $args[0]));

    ()
}

sub float::OUTWOOF { $_[0] }

1;
