package Woof::ISA::str_ne;
use strict;
use warnings;
use Carp;

sub str_ne::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid non-empty string for `$_->{name}': ",
            join(',', map { !length ? '<empty>' : (!defined ? '<undef>' : $_) } @args))
        unless @args == 1 && defined $args[0] && length $args[0] &&
               !ref $args[0];

    $_->referent = '' . $args[0];

    ()
}

sub str_ne::OUTWOOF { $_[0] }

1;
