package Woof::ISA::str;
use strict;
use warnings;
use Carp;

sub str::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid string for `$_->{name}': ",
            join(',', map { $_ // '<undef>' } @args))
        unless @args == 1 && defined $args[0] && !ref $args[0];

    $_->referent = '' . $args[0];

    ()
}

sub str::OUTWOOF { $_[0] }

1;
