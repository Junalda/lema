package Woof::ISA::strnull;
use strict;
use warnings;
use Carp;

sub strnull::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid string for `$_->{name}': ",
            join(',', @args))
        unless @args == 1 && !ref $args[0];

    if (!length $args[0]) {
        $_->referent = undef;
    } else {
        $_->referent = '' . $args[0];
    }

    ()
}

sub strnull::OUTWOOF { $_[0] }

1;
