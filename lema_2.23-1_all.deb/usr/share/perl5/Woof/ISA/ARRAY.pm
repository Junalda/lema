package Woof::ISA::ARRAY;
use strict;
use warnings;
use Carp;
use Data::Dumper;
use Scalar::Util;

sub ARRAY::INWOOF() {
    my @args = @_;

    Carp::croak("Invalid arrayref for `$_->{name}': ",
            join(',', map { $_ // '<undef>' } @args))
        unless @args == 1 && ref $args[0] eq 'ARRAY';

    $_->referent = $args[0];

    ()
}

sub ARRAY::OUTWOOF {

    my @copy;

    for my $el (@{$_[0]}) {
        if (Scalar::Util::blessed($el) &&
            exists &{ref($el) . '::MEMBERS'}) {
            push @copy, $el->OUTWOOF;
        }
        else {
            push @copy, $el;
        }
    }

    \@copy
}

1;
