package Woof::_Wrapper;
use strict;
use warnings;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;

$Carp::Internal{'Woof::_Wrapper'} = 1;

sub errors($) {
    no strict 'refs';
    my $class  = shift;
    my $errors = ${$class . '::ERRORS'};
    return unless $errors;

    if (ref $errors eq 'HASH') {
        return ${$class . '::ERRORS'} = new Woof::_Errors $errors;
    }

    if ($errors->$_isa('Woof::_Errors')) {
        return $errors;
    }

    Carp::croak("ERRORS is not supported type");
}

sub wrapper {
    my $spec   = shift;
    my $class  = ref $_[0];
    my $orig   = $spec->{orig_cb};
    my $name   = $spec->{name};
    my $errors = errors($class);

    $errors->levelup($name) if $errors;

    if ($spec->{private}) {
        my ($self) = @_;
        my ($accessor_caller) = caller(1);

        unless ($accessor_caller eq 'Woof' ||
                $self->$_isa($accessor_caller) ||
                $spec->is_building || $spec->is_inwoof
        ) {
            Carp::croak("Private variable for `$spec->{name}': $self vs $accessor_caller");
        }
    }

    unless (@_ >= 2) {
        unless (exists $_[0]->{$name}) {
            Carp::croak("Not initialized `$name'");
        }

        $errors->leveldown if $errors;
        return $_[0]->{$name};
    }

    unless ($orig) {
        no strict 'refs';
        if (exists &{$class . '::_' . $name}) {
            Carp::croak("Setter `$name' is ignored: it must be seen during runtime");
        }
    }
    Carp::croak("Constant member `$spec->{name}' cannot be changed: ", $spec->flags)
        if $spec->const && !($spec->is_building || $spec->is_inwoof);

    {
        my ($ok, $value);
        my $set  = 0;
        local $_ = $spec;

        my $orig_value = $_[1];

        local $_->{reference} = \ $orig_value;

        goto validation unless $orig;

setter:
        $ok = 0;
        eval {
            $value = $orig->($_[0], $orig_value);
            $ok    = 1;
        };

        goto error unless $ok;

        $_->{reference} = \ $value;
        $set = 1;

validation:
        $ok = 0;
        eval {
            Woof::_Validator::validate();
            $ok = 1;
        };

        goto error unless $ok;

        $errors->leveldown if $errors;

        return $_[0]->{$name} = ${$_->{reference}};

error:
        $ok = !!$_->{reference};

        $_->{reference} = undef;

        if ($errors) {
            $errors->add($@) if $ok;
            $errors->leveldown;
            return ();
        }

        die $@;
    }
}

1;
