package Woof::_Errors;
use strict;
use warnings;
use Data::Dumper;
use Carp;

sub new {
    my ($class, $hashref) = @_;

    Carp::croak("No hashref to store errors")
        unless ref $hashref eq 'HASH';

    bless [ $hashref, [] ], $class
}

sub hashref { $_[0][0] }
sub names   { $_[0][1] }

sub add {
    my ($self, $error) = @_;

    my $last = scalar @{$self->names} - 1;

    Carp::croak("No name for level")
        if $last < 0;

    my $index = 0;
    my $ptr   = $self->hashref;

    for (@{$self->names}) {
        if ($index == $last) {
            $ptr->{$_} = $error;
            last;
        }

        $ptr->{$_} //= +{};
        $ptr = $ptr->{$_};

        $index++;
    }

    ()
}

sub levelup {
    my ($self, $name) = @_;
    push @{$self->names}, $name;
    ()
}

sub leveldown {
    my ($self) = @_;
    pop @{$self->names};
}

1;
