package QuickBooks::Objects::MetaData;
use common::sense;
use Woof;
use DateTime;

=head1 EXAMPLE
2021-12-19 17:34:50 +0400 +                  'MetaData' => {
2021-12-19 17:34:50 +0400 +                                  'LastUpdatedTime' => '2021-12-19T03:51:38-08:00',
2021-12-19 17:34:50 +0400 +                                  'CreateTime' => '2021-12-19T03:38:09-08:00'
2021-12-19 17:34:50 +0400 +                                },
=cut

PUBLIC (LastUpdatedTime => UNDEFOK OF 'strnull') = undef;
PUBLIC (CreateTime      => UNDEFOK OF 'strnull') = undef;

sub updated_on_dt {
    my $self = shift;
    my $time = $self->LastUpdatedTime;
    return undef unless length $time;

    return undef unless $time =~ /^(\d{4}).(\d{2}).(\d{2})
                                   .
                                   (\d{2}).(\d{2}).(\d{2})
                                   \s*
                                   (\S+)$/x;


    return DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => $7,
    );
}

sub updated_on {
    my $self = shift;
    my $dt   = $self->updated_on_dt;
    return undef unless $dt;
    return int $dt->epoch;
}

sub created_on_dt {
    my $self = shift;
    my $time = $self->CreateTime;
    return undef unless length $time;

    return undef unless $time =~ /^(\d{4}).(\d{2}).(\d{2})
                                   .
                                   (\d{2}).(\d{2}).(\d{2})
                                   \s*
                                   (\S+)$/x;

    return DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => $7,
    );
}

sub created_on {
    my $self = shift;
    my $dt   = $self->created_on_dt;
    return undef unless $dt;
    return int $dt->epoch;
}

1;
