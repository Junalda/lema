package QuickBooks::Objects::SalesTaxRateList;
use common::sense;
use QuickBooks::Objects::TaxRateRef;
use Woof;

=head1
+                    'SalesTaxRateList' => {
+                                            'TaxRateDetail' => [
+                                                                 {
+                                                                   'TaxTypeApplicable' => 'TaxOnAmount',
+                                                                   'TaxOrder' => 0,
+                                                                   'TaxRateRef' => {
+                                                                                     'value' => '6',
+                                                                                     'name' => 'VAT 0% (Sales)'
+                                                                                   }
+                                                                 }
+                                                               ]
+                                          },
=cut

PUBLIC (TaxRateDetail => UNDEFOK OF 'ARRAY') = undef;

sub _TaxRateDetail_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    die "Invalid TaxRateDetail" unless ref $in eq 'ARRAY';
    for (@$in) {
        die "Invalid element of TaxRateDetail" unless ref $_ eq 'HASH';
        if ($_->{TaxRateRef}) {
            $_->{TaxRateRef} = QuickBooks::Objects::TaxRateRef->new($_->{TaxRateRef});
        }
    }

    return $in;
}

sub enum_tax_rate_ref {
    my ($self, $cb) = @_;
    my $aref = $self->TaxRateDetail;

    if ($aref) {
        for my $hash (@$aref) {
            next unless $hash->{TaxRateRef};
            $cb->($hash->{TaxRateRef});
        }
    }
    ()
}

1;
