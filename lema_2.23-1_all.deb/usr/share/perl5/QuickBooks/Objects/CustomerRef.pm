package QuickBooks::Objects::CustomerRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"CustomerRef"=> {
    "value"=> "1"
}
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => UNDEFOK OF 'str_ne') = undef;

1;
