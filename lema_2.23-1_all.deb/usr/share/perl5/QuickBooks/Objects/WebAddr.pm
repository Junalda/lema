package QuickBooks::Objects::WebAddr;
use common::sense;
use Woof;

=head1 EXAMPLE
  {
    "URI": "http://www.google.com"
  }, 
=cut

PUBLIC (URI => UNDEFOK OF 'str_ne');

1;
