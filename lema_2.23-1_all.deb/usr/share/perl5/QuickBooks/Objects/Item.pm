package QuickBooks::Objects::Item;
use common::sense;
use QuickBooks::Objects::ItemRef;
use QuickBooks::Objects::AccountRef;
use Woof;

PUBLIC (Name               => OF 'str_ne');
PUBLIC (Type               => OF 'str_ne');
PUBLIC (FullyQualifiedName => UNDEFOK OF 'str_ne')  = undef;
PUBLIC (Id                 => UNDEFOK OF 'num')     = undef;
PUBLIC (Active             => UNDEFOK OF 'boolean') = undef;
PUBLIC (TrackQtyOnHand     => UNDEFOK OF 'boolean') = undef;
PUBLIC (QtyOnHand          => UNDEFOK OF 'float')   = undef;
PUBLIC (InvStartDate       => UNDEFOK OF 'strnull') = undef;
PUBLIC (IncomeAccountRef   => OF 'QuickBooks::Objects::AccountRef') = undef;
PUBLIC (ExpenseAccountRef  => OF 'QuickBooks::Objects::AccountRef') = undef;
PUBLIC (AssetAccountRef    => OF 'QuickBooks::Objects::AccountRef') = undef;

PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;

sub make_ref {
    my $self = shift;
    return new QuickBooks::Objects::ItemRef name  => $self->FullyQualifiedName,
                                            value => $self->Id;
}

sub is_inventory {
    my $self = shift;
    return $self->Type eq 'Inventory' ? 1 : 0;
}

sub income_account {
    my $self = shift;
    if ($self->IncomeAccountRef) {
        return $self->IncomeAccountRef->name;
    }
    return undef;
}

sub expense_account {
    my $self = shift;
    if ($self->ExpenseAccountRef) {
        return $self->ExpenseAccountRef->name;
    }
    return undef;
}

1;
