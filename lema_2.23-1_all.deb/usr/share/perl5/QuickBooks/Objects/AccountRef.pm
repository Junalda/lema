package QuickBooks::Objects::AccountRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"AccountRef" : {
    "name" : "A/C Payables",
    "value" : "333"
}
=cut

PUBLIC (value => UNDEFOK OF 'num') = undef;
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

1;
