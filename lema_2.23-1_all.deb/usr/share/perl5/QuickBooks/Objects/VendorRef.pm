package QuickBooks::Objects::VendorRef;
use common::sense;
use Woof;

=head1 EXAMPLE
                                              'VendorRef' => {
                                                               'name' => 'Organic Delivery',
                                                               'value' => '10'
                                                             },
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

1;
