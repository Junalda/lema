package QuickBooks::Objects::Phone;
use common::sense;
use Woof;

=head1 EXAMPLE
"PrimaryPhone": {
    "FreeFormNumber": "(555) 555-5555"
  }, 
=cut

PUBLIC (FreeFormNumber  => UNDEFOK OF 'strnull') = undef;

1;
