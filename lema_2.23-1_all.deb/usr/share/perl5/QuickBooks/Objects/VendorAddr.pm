package QuickBooks::Objects::VendorAddr;
use common::sense;
use Woof;

=head1 EXAMPLE
                    'VendorAddr' => {
                                    'Country' => 'US',
                                    'Id' => '110'
                    },

=cut

PUBLIC (Id => OF 'num');
PUBLIC (Country => UNDEFOK OF 'strnull') = undef;

1;
