package QuickBooks::Objects::CustomFieldElement;
use common::sense;
use Woof;

=head1 EXAMPLE
2022-01-08 15:37:32 +0400 +                                     {
2022-01-08 15:37:32 +0400 +                                       'Type' => 'StringType',
2022-01-08 15:37:32 +0400 +                                       'DefinitionId' => '2',
2022-01-08 15:37:32 +0400 +                                       'StringValue' => 'YOURREF',
2022-01-08 15:37:32 +0400 +                                       'Name' => 'Your Reference'
2022-01-08 15:37:32 +0400 +                                     }
=cut

PUBLIC (Type         => UNDEFOK OF 'strnull') = undef;
PUBLIC (DefinitionId => UNDEFOK OF 'int')     = undef;
PUBLIC (StringValue  => UNDEFOK OF 'strnull') = undef;
PUBLIC (Name         => UNDEFOK OF 'strnull') = undef;

1;
