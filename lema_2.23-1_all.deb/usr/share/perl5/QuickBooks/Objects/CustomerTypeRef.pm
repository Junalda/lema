package QuickBooks::Objects::CustomerTypeRef;
use common::sense;
use Woof;

=head1 EXAMPLE
'ParentRef' => {
                      'value' => '177'
                    },
=cut

PUBLIC (value => OF 'int');

1;
