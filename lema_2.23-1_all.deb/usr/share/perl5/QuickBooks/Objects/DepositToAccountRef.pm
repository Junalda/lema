package QuickBooks::Objects::DepositToAccountRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"DepositToAccountRef"=> {
    "value"=> "1"
}
=cut

PUBLIC (value => OF 'int');
PUBLIC (name  => UNDEFOK OF 'str_ne') = undef;

1;
