package QuickBooks::Objects::TaxCode;
use common::sense;
use QuickBooks::Objects::SalesTaxRateList;
use QuickBooks::Objects::PurchaseTaxRateList;
use Woof;

=head1
{
        "TaxGroup": false,
        "Name": "TAX",
        "Taxable": true,
        "Description": "TAX",
        "Id": "TAX",
        "MetaData": {
          "CreateTime": "2014-10-15T11:28:33-07:00",
          "LastUpdatedTime": "2014-10-15T11:28:33-07:00"
}

=cut

PUBLIC (Id                 => OF 'num');
PUBLIC (Name               => UNDEFOK OF 'strnull') = undef;
PUBLIC (Description        => UNDEFOK OF 'strnull') = undef;
PUBLIC (Taxable            => OF 'boolean');
PUBLIC (SalesTaxRateList    => UNDEFOK OF 'QuickBooks::Objects::SalesTaxRateList') = undef;
PUBLIC (PurchaseTaxRateList => UNDEFOK OF 'QuickBooks::Objects::PurchaseTaxRateList') = undef;
PUBLIC (Active              => OF 'boolean');

sub sales_tax_rate_ids {
    my $self = shift;
    return undef unless $self->SalesTaxRateList;

    my @ids;
    $self->SalesTaxRateList->enum_tax_rate_ref(sub {
        my $tax_ref = shift;
        push @ids, $tax_ref->{value};
        ()
    });

    return @ids ? \@ids : undef;
}

sub purchase_tax_rate_ids {
    my $self = shift;
    return undef unless $self->PurchaseTaxRateList;

    my @ids;
    $self->PurchaseTaxRateList->enum_tax_rate_ref(sub {
        my $tax_ref = shift;
        push @ids, $tax_ref->{value};
        ()
    });

    return @ids ? \@ids : undef;
}

sub sales_tax_rate_ids_fmt {
    my $self = shift;
    my $aref = $self->sales_tax_rate_ids;
    return "" unless $aref;
    return join ', ', @$aref;
}

sub purchase_tax_rate_ids_fmt {
    my $self = shift;
    my $aref = $self->purchase_tax_rate_ids;
    return "" unless $aref;
    return join ', ', @$aref;
}

sub TO_JSON {
    my ($self) = @_;
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{sales_tax_rate_ids}     = $self->sales_tax_rate_ids;
    $res->{sales_tax_rate_ids_fmt} = $self->sales_tax_rate_ids_fmt;
    $res->{purchase_tax_rate_ids}  = $self->purchase_tax_rate_ids;
    $res->{purchase_tax_rate_ids_fmt}  = $self->purchase_tax_rate_ids_fmt;


    return $res;
}

1;
