package QuickBooks::Objects::CurrencyPrefs;
use common::sense;
use QuickBooks::Objects::HomeCurrency;
use Woof;

=head1
    "CurrencyPrefs": {
      "HomeCurrency": {
        "value": "USD"
      }, 
      "MultiCurrencyEnabled": false
    }, 
}
=cut

PUBLIC (MultiCurrencyEnabled => OF 'boolean');
PUBLIC (HomeCurrency         => OF 'QuickBooks::Objects::HomeCurrency');

1;
