{
    package QuickBooks::Objects::SalesItemLineDetail;
    use common::sense;
    use QuickBooks::Objects::TaxCodeRef;
    use QuickBooks::Objects::ItemRef;
    use Woof;

    PUBLIC (ItemRef        => OF 'QuickBooks::Objects::ItemRef');
    PUBLIC (ItemAccountRef => UNDEFOK OF 'QuickBooks::Objects::ItemAccountRef')
                = undef;

    PUBLIC (Qty        => UNDEFOK OF 'float') = undef;
    PUBLIC (UnitPrice  => UNDEFOK OF 'float') = undef;
    PUBLIC (TaxCodeRef => UNDEFOK OF 'QuickBooks::Objects::TaxCodeRef') = undef;
    PUBLIC (ServiceDate => UNDEFOK OF 'dateYYYYMMDD') = undef;

    sub unit_price_fmt {
        return ACME::Data::print_amount($_[0]->UnitPrice);
    }

    sub qty_fmt {
        my $ret = ACME::Data::print_amount($_[0]->Qty);
        if ($ret =~ /\.(\d+)/) {
            unless ($1 > 0) {
                return int $ret;
            }
        }
        return $ret;
    }
}

{
    package QuickBooks::Objects::DepositLineDetail;
    use common::sense;
    use QuickBooks::Objects::AccountRef;
    use QuickBooks::Objects::PaymentMethodRef;
    use Woof;

=head1 EXAMPLE
    "DepositLineDetail" : {
       "AccountRef" : {
          "name" : "Opening Balance Equity",
          "value" : "123"
       }
    }
=cut

    PUBLIC (AccountRef =>
            UNDEFOK OF 'QuickBooks::Objects::AccountRef') = undef;
    PUBLIC (PaymentMethodRef =>
            UNDEFOK OF 'QuickBooks::Objects::PaymentMethodRef') = undef;
    PUBLIC (CheckNum =>
            UNDEFOK OF 'str_ne') = undef;
}

{
    package QuickBooks::Objects::ItemBasedExpenseLineDetail;
    use common::sense;
    use QuickBooks::Objects::ItemRef;
    use Woof;

=head1 EXAMPLE
2021-10-08 18:24:10 +0400 +                                         'ItemBasedExpenseLineDetail' => {
2021-10-08 18:24:10 +0400 +                                                                           'ItemRef' => {
2021-10-08 18:24:10 +0400 +                                                                                          'value' => '19',
2021-10-08 18:24:10 +0400 +                                                                                          'name' => 'Oranges/Valencia/4/GR/I/BIO/15'
2021-10-08 18:24:10 +0400 +                                                                                        },
2021-10-08 18:24:10 +0400 +                                                                           'Qty' => 22,
2021-10-08 18:24:10 +0400 +                                                                           'BillableStatus' => 'NotBillable',
2021-10-08 18:24:10 +0400 +                                                                           'UnitPrice' => 123,
2021-10-08 18:24:10 +0400 +                                                                           'TaxCodeRef' => {
2021-10-08 18:24:10 +0400 +                                                                                             'value' => 'NON'
2021-10-08 18:24:10 +0400 +                                                                                           }
2021-10-08 18:24:10 +0400 +                                                                         },
=cut

    PUBLIC (ItemRef => OF 'QuickBooks::Objects::ItemRef');
    PUBLIC (Qty       => UNDEFOK OF 'float') = undef;
    PUBLIC (UnitPrice => UNDEFOK OF 'float') = undef;
    PUBLIC (BillableStatus => UNDEFOK OF 'str_ne') = undef;
    PUBLIC (TaxCodeRef => UNDEFOK OF 'QuickBooks::Objects::TaxCodeRef') = undef;


    sub unit_price_fmt {
        return ACME::Data::print_amount($_[0]->UnitPrice);
    }

    sub qty_fmt {
        my $ret = ACME::Data::print_amount($_[0]->Qty);
        if ($ret =~ /[\,\.](\d+)$/) {
            unless ($1 > 0) {
                $ret =~ s/[\,\.](\d+)$//;
            }
        }
        return $ret;
    }
}

{
    package QuickBooks::Objects::AccountBasedExpenseLineDetail;
    use common::sense;
    use QuickBooks::Objects::ItemRef;
    use Woof;

=head1 EXAMPLE
2020-09-20 19:22:19 +0400 +  'AccountBasedExpenseLineDetail' => {
2020-09-20 19:22:19 +0400 +                                       'BillableStatus' => 'NotBillable',
2020-09-20 19:22:19 +0400 +                                       'AccountRef' => {
2020-09-20 19:22:19 +0400 +                                                         'name' => 'Apples',
2020-09-20 19:22:19 +0400 +                                                         'value' => '122'
2020-09-20 19:22:19 +0400 +                                                       },
2020-09-20 19:22:19 +0400 +                                       'TaxCodeRef' => {
2020-09-20 19:22:19 +0400 +                                                         'value' => 'NON'
2020-09-20 19:22:19 +0400 +                                                       }
2020-09-20 19:22:19 +0400 +                                     },

=cut
    PUBLIC (AccountRef => OF 'QuickBooks::Objects::AccountRef');
    PUBLIC (TaxCodeRef => UNDEFOK OF 'HASH') = undef;

    PUBLIC (BillableStatus => UNDEFOK OF 'str_ne') = undef;
}

{
    package QuickBooks::Objects::TaxLineDetail;
    use common::sense;
    use QuickBooks::Objects::ItemRef;
    use Woof;

    PUBLIC (TaxRateRef => UNDEFOK OF 'QuickBooks::Objects::TaxRateRef') = undef;
    PUBLIC (TaxPercent => UNDEFOK OF 'float') = undef;
    PUBLIC (PercentBased => UNDEFOK OF 'boolean') = undef;
    PUBLIC (NetAmountTaxable => UNDEFOK OF 'float') = undef;

    sub tax_rate_ref_decreased {
        my ($self) = @_;
        if ($self->TaxRateRef && $self->TaxRateRef->value > 0) {
            return $self->TaxRateRef->value - 1;
        }
        return undef;
    }
}


package QuickBooks::Objects::Detail;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Woof;

=head1 EXAMPLE
{
    "DetailType"=> "SalesItemLineDetail",
    "Amount"=> 123.0,
    "SalesItemLineDetail"=> {
        "ItemRef"=> {
            "name"=> "Services",
            "value"=> "12",
            }
    }
}
=cut

PUBLIC (DetailType => UNDEFOK OF 'str_ne') = undef;
PUBLIC (Amount     => UNDEFOK OF 'float') = sub { 0 };
PUBLIC (Description => UNDEFOK OF 'str_ne') = undef;
PUBLIC (SalesItemLineDetail => UNDEFOK OF 'QuickBooks::Objects::SalesItemLineDetail')
        = undef;
PUBLIC (DepositLineDetail => UNDEFOK OF 'QuickBooks::Objects::DepositLineDetail')
        = undef;
PUBLIC (AccountBasedExpenseLineDetail => UNDEFOK OF 'QuickBooks::Objects::AccountBasedExpenseLineDetail')
        = undef;
PUBLIC (ItemBasedExpenseLineDetail => UNDEFOK OF 'QuickBooks::Objects::ItemBasedExpenseLineDetail')
        = undef;
PUBLIC (TaxLineDetail => UNDEFOK OF 'QuickBooks::Objects::TaxLineDetail')
        = undef;


PUBLIC (SubTotalLineDetail => UNDEFOK OF 'HASH') = undef;
PUBLIC (LinkedTxn          => OF 'ARRAY') = sub { [] };


sub _SalesItemLineDetail {
    my ($self, $href) = @_;
    return %$href ? $href : undef;
}

sub _DepositLineDetail {
    my ($self, $href) = @_;
    return %$href ? $href : undef;
}

sub _SubTotalLineDetail {
    my ($self, $href) = @_;
    if (%$href) {
        croak "Empty HASH is only supported in SubTotalLineDetail";
    }
    return undef;
}

sub _AccountBasedExpenseLineDetail {
    my ($self, $href) = @_;
    return %$href ? $href : undef;
}

sub _LinkedTxn {
    my $self = shift;

    VALIDATE;

    my @copy;

    for my $el (@{$_[0]}) {
        unless ($el->$_isa('QuickBooks::Objects::Txn')) {
            unless (BUILDING) {
                croak "Element of array `LinkedTxn` is not " .
                      "QuickBooks::Objects::Txn";
            }
            else {
                push @copy, QuickBooks::Objects::Txn->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}

sub line {
    my $self = shift;

    my $line = sprintf "%s,%s,%s",
                       $self->DetailType  // '<undef>',
                       $self->Description // '<undef>',
                       $self->Amount;

    if ($self->DetailType eq 'SalesItemLineDetail') {
        $line .= sprintf "\n\t%s,%s,%s",
                         $self->SalesItemLineDetail->Qty       // '<undef>',
                         $self->SalesItemLineDetail->UnitPrice // '<undef>',
                         $self->SalesItemLineDetail->ItemRef->line;
    }
    elsif ($self->DetailType eq 'SubTotalLineDetail') {
        croak 'No line preparation for SubTotalLineDetail: ',
              Dumper+$self->SubTotalLineDetail;
    }
    elsif ($self->DetailType eq 'DepositLineDetail') {
        my $ref;
        if (length $self->DepositLineDetail->CheckNum) {
            $ref = $self->DepositLineDetail->CheckNum;
        }
        else {
            $ref = "For account '" .
                   $self->DepositLineDetail->AccountRef->name . "'";
        }

        $line .= "\n\t". $ref;
    }
    elsif ($self->DetailType eq 'AccountBasedExpenseLineDetail') {
        croak 'No line preparation for AccountBasedExpenseLineDetail: ',
              Dumper+$self->AccountBasedExpenseLineDetail;
    }

    return $line;
}

sub line_ident {
    my ($self, $ident) = @_;

    my $line  = $self->line;
    my @lines = split /\n/, $self->line;

    my $buf = '';
    for (@lines) {
        $buf .= $ident . $_ . "\n";
    }

    return $buf;
}

sub amount_comma {
    return ACME::Data::print_amount($_[0]->Amount);
}

1;
