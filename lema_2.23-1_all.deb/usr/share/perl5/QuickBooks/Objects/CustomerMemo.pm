package QuickBooks::Objects::CustomerMemo;
use common::sense;
use Woof;

PUBLIC (value => OF 'strnull') = undef;

1;
