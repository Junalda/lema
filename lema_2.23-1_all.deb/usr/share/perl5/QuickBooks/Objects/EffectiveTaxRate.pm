package QuickBooks::Objects::EffectiveTaxRate;
use common::sense;
use Woof;

=head1
                               {
                                 'EndDate' => '2022-01-25T00:00:00-08:00',
                                 'RateValue' => 9,
                                 'EffectiveDate' => '1970-01-01T00:00:00-08:00'
                               },
OR
                               {
                                 'EffectiveDate' => '2022-01-26T00:00:00-08:00',
                                 'RateValue' => 8
                               }


=cut

PUBLIC (EndDate            => UNDEFOK OF 'strnull') = undef;
PUBLIC (RateValue          => UNDEFOK OF 'num') = undef;
PUBLIC (EffectiveDate      => OF 'strnull');

sub end_date_dt {
    my $self = shift;
    my $time = $self->EndDate;
    return undef unless length $time;

    return undef unless $time =~ /^(\d{4}).(\d{2}).(\d{2})
                                   .
                                   (\d{2}).(\d{2}).(\d{2})
                                   \s*
                                   (\S+)$/x;


    return DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => $7,
    );
}

sub end_date_epoch {
    my $self = shift;
    my $dt   = $self->end_date_dt;
    return undef unless $dt;
    return int $dt->epoch;
}

sub effective_date_dt {
    my $self = shift;
    my $time = $self->EffectiveDate;
    return undef unless length $time;

    return undef unless $time =~ /^(\d{4}).(\d{2}).(\d{2})
                                   .
                                   (\d{2}).(\d{2}).(\d{2})
                                   \s*
                                   (\S+)$/x;


    return DateTime->new(
        year       => $1,
        month      => $2,
        day        => $3,
        hour       => $4,
        minute     => $5,
        second     => $6,
        time_zone  => $7,
    );
}

sub effective_date_epoch {
    my $self = shift;
    my $dt   = $self->effective_date_dt;
    return undef unless $dt;
    return int $dt->epoch;
}

1;
