package QuickBooks::Objects::TaxRateRef;
use common::sense;
use Woof;

PUBLIC (value => OF 'num');
PUBLIC (name  => UNDEFOK OF 'strnull') = undef;

1;
