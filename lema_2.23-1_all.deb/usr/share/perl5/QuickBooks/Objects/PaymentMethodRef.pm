package QuickBooks::Objects::PaymentMethodRef;
use common::sense;
use Woof;

=head1 EXAMPLE
"PaymentMethodRef"=> {
    "value"=> "123"
}
=cut

PUBLIC (value => OF 'int');

1;
