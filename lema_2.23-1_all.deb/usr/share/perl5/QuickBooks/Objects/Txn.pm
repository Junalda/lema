package QuickBooks::Objects::Txn;
use common::sense;
use Woof;

=head1 EXAMPLE
{
  'TxnId' => '40',
  'TxnType' => 'Payment'
}
=cut

PUBLIC (TxnId => OF 'num');
PUBLIC (TxnType => OF 'str_ne');
PUBLIC (TxnLineId => UNDEFOK OF 'num') = undef;

sub is_payment {
    my $self = shift;
    return $self->TxnType eq 'Payment';
}

sub is_invoice {
    my $self = shift;
    return $self->TxnType eq 'Invoice';
}

1;
