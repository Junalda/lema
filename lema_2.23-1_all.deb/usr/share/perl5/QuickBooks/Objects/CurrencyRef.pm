package QuickBooks::Objects::CurrencyRef;
use common::sense;
use Woof;

=head1 EXAMPLE
'CurrencyRef' => {
                   'value' => 'USD',
                   'name' => 'US Dollars'
                 }
=cut

PUBLIC (value => OF 'str_ne');
PUBLIC (name  => UNDEFOK OF 'str_ne') = undef;

1;
