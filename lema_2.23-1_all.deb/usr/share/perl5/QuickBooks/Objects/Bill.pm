package QuickBooks::Objects::Bill;
use common::sense;
use Carp;
use Safe::Isa;
use Data::Dumper;
use QuickBooks::Objects::MetaData;
use QuickBooks::Objects::Detail;
use QuickBooks::Objects::VendorRef;
use QuickBooks::Objects::APAccountRef;
use QuickBooks::Objects::VendorAddr;
use QuickBooks::Objects::SalesTermRef;
use QuickBooks::Objects::Txn;
use QuickBooks::Objects::TxnTaxDetail;
use QuickBooks::Globals;
use parent qw(QuickBooks::Objects::_TxnDateMethods);
use Woof;

PUBLIC (Id   => UNDEFOK OF 'num') = undef;
PUBLIC (Line => OF 'ARRAY') = sub { [] };
PUBLIC (TxnTaxDetail => UNDEFOK OF 'QuickBooks::Objects::TxnTaxDetail') = undef;
PUBLIC (TxnDate => UNDEFOK OF 'dateYYYYMMDD') = undef;

PUBLIC (DueDate => UNDEFOK OF 'dateYYYYMMDD') = undef;

PUBLIC (SalesTermRef => UNDEFOK OF 'QuickBooks::Objects::SalesTermRef') = undef;

PUBLIC (APAccountRef => UNDEFOK OF 'QuickBooks::Objects::APAccountRef') = undef;

PUBLIC (VendorRef   => OF 'QuickBooks::Objects::VendorRef');
PUBLIC (VendorAddr  => UNDEFOK OF 'QuickBooks::Objects::VendorAddr') = undef;
PUBLIC (CurrencyRef => UNDEFOK OF 'QuickBooks::Objects::CurrencyRef') = undef;
PUBLIC (Balance     => UNDEFOK OF 'float') = undef;
PUBLIC (TotalAmt    => UNDEFOK OF 'float') = undef;
PUBLIC (DocNumber   => UNDEFOK OF 'strnull') = undef;
PUBLIC (LinkedTxn   => OF 'ARRAY') = sub { [] };
PUBLIC (SyncToken => UNDEFOK OF 'int') = undef;

PUBLIC (PrivateNote => UNDEFOK OF 'strnull') = undef;
PUBLIC (domain => UNDEFOK OF 'strnull') = undef;

PUBLIC (MetaData => UNDEFOK OF 'QuickBooks::Objects::MetaData') = undef;

PUBLIC (GlobalTaxCalculation => UNDEFOK OF 'strnull') = undef;


sub doc_code {
    my $self = shift;
    croak "QBO ID is not known"
        unless length $self->Id;
    die "Document code is not greater than 0\n"
        unless $self->Id > 0;

    return LEMA::make_doc_code($self->Id, $self->DocNumber);
}

sub _MetaData_ {
    my $self = shift;
    return $_[0] if defined $_[0];
    return QuickBooks::Objects::MetaData->new(+{});
}

sub _DocNumber {
    my $self = shift;

    VALIDATE;
    my $len = length $_[0];

    return undef unless $len;

    croak "Document number length must be not greater 21 chars"
       unless $len <= 21;

    $_[0]
}

sub _Line {
    my $self = shift;

    VALIDATE;

    my @copy;

    for my $el (@{$_[0]}) {
        unless ($el->$_isa('QuickBooks::Objects::Detail')) {
            unless (BUILDING) {
                croak "Element of array `Line` is not " .
                      "QuickBooks::Objects::Detail";
            }
            else {
                push @copy, QuickBooks::Objects::Detail->new($el);
                next;
            }
        }

        push @copy, $el;
    }

    return \@copy;
}


sub make_txn {
    my $self = shift;

    croak "Couldn't make invoice Txn as invoice ID is not defined"
        unless defined $self->Id;

    return new QuickBooks::Objects::Txn TxnId   => $self->Id,
                                        TxnType => 'Invoice';
}


sub is_paid {
    my $self = shift;
    croak "Invoice total amount is not greater 0"
        unless $self->TotalAmt > 0;

    return $self->Balance == 0 ? 1 : 0
}

sub is_partial_paid {
    my $self = shift;

    croak "Invoice total amount is not greater 0"
        unless $self->TotalAmt > 0;

    return 0 if $self->Balance == 0;

    return ($self->Balance < $self->TotalAmt) ? 1 : 0;
}

sub doc_num_autogen {
    my $self = shift;

    return $self->DocNumber if $self->DocNumber =~ /^BL\d+/;

    my $extra_num = QuickBooks::Globals::seq_extra_on ? '0' : '';
    my $seq       = QuickBooks::Globals::seq_inc;

    croak "Invalid seq number in arguments"
        unless !ref $seq && $seq =~ /^\d+$/ && $seq >= 1;

    croak "DocNumber is already generated: ", $self->DocNumber
        if defined $self->DocNumber;

    my $chksum_char = QuickBooks::Globals::doc_chksum(
                            $self->VendorRef->value,
                            $seq,
                            $self->get_txndate_lyr,
                            $self->get_txndate_doy);

    my $docnum = sprintf "%s%02d%03d-%03d-%03d%s%s",
                "BL",
                $self->get_txndate_lyr,
                $self->get_txndate_doy,
                $self->VendorRef->value,
                $seq,
                $chksum_char,
                $extra_num;

    $self->DocNumber($docnum);

    ()
}

sub get_bill_payment_doc_num_autogen {
    my $self    = shift;
    my $doc_num = $self->DocNumber;

    croak "Invalid Doc Number of Bill to generate Doc Number of Bill Payment"
        unless length $doc_num && $doc_num =~ /^ZBL\d+/;

    $doc_num =~ s/^BL/BP/;
    return $doc_num;
}

sub enum_details {
    my ($self, $cb) = @_;
    for (@{$self->Line}) {
        $cb->($_);
    }

    ()
}

sub line_details {
    my $self = shift;

    my @lines;
    $self->enum_details(sub {
        my $detail = shift;
        push @lines, $detail->line;
    });

    @lines
}

sub line {
    my $self = shift;

    return sprintf "%s,%s,%s,%s,%s",#Net 30,,My Memo,%s,%s,%s,%s,%s\r\n",
            $self->DocNumber,
            $self->Id,
            $self->VendorRef->value,
            $self->TxnDate,
            $self->TotalAmt,
    ;
}


sub get_linked_purchase_order_ids {
    my $self = shift;
    my $link = $self->LinkedTxn;
    return undef unless ref $link eq 'ARRAY';

    my @po_ids;
    for (@$link) {
        if ($_->{TxnType} eq 'PurchaseOrder' && defined $_->{TxnId}) {
            push @po_ids, $_->{TxnId};
        }
    }
    return @po_ids ? \@po_ids : undef;
}

sub link_purchase_order_id {
    my ($self, $po_id) = @_;
    $po_id += 0;
    die "Invalid purchase order ID to link\n" unless $po_id > 0;

    my $ids = $self->get_linked_purchase_order_ids;
    if ($ids) {
        for my $id (@$ids) {
            if ($id == $po_id) {
                return;
            }
        }
    }

    push @{$self->LinkedTxn}, { TxnType => 'PurchaseOrder', TxnId => $po_id };

    my $line    = $self->Line;
    my $line_id = 1;

    for my $detail (@$line) {
        my $aref = $detail->LinkedTxn;
        die "Couldn't link Purchase Order to Bill items exclusively"
            if @$aref;
        push @$aref, {
            'TxnType'   => 'PurchaseOrder',
            'TxnId'     => $po_id,
            'TxnLineId' => $line_id,
        };
        $line_id++;
    }

    ()
}

sub has_linked_purchase_order_id {
    my ($self) = @_;
    return defined $self->get_linked_purchase_order_ids;
}

sub enum_item_qty {
    my ($self, $cb) = @_;
    die "No callback" unless ref $cb eq 'CODE';

    my $line = $self->Line;
    return unless @$line;

    for my $detail (@$line) {
        next unless $detail->DetailType eq 'ItemBasedExpenseLineDetail';
        my $expense = $detail->ItemBasedExpenseLineDetail;
        next unless $expense;
        my $item_ref = $expense->ItemRef;
        next unless $item_ref;

        $cb->($detail, $expense, $item_ref);
    }
}

sub item_id_qty_href {
    my $self = shift;
    my %hash;
    $self->enum_item_qty(sub {
        my ($detail, $expense, $item_ref) = @_;
        $hash{$item_ref->value} += $expense->Qty;
        ()
    });

    return \%hash;
}

sub docnumber_no_dash_fmt {
    my $self = shift;
    my $docnum = $self->DocNumber;
    return $docnum;
}

1;
