package QuickBooks::Objects::CompanyInfo;
use common::sense;
use Data::Dumper;
use QuickBooks::Objects::CustomerRef;
use QuickBooks::Objects::CustomerTypeRef;
use QuickBooks::Objects::Addr;
use QuickBooks::Objects::ParentRef;
use QuickBooks::Objects::Phone;
use QuickBooks::Objects::Email;
use QuickBooks::Objects::WebAddr;
use QuickBooks::Objects::SalesTermRef;
use Woof;

=head
'CompanyInfo' => {
                              'CompanyStartDate' => '2021-03-20',
                              'LegalName' => 'Sandbox Company_FR_3',
                              'PrimaryPhone' => {
                                                  'FreeFormNumber' => '01 42 84 20 09'
                                                },
                              'SupportedLanguages' => 'fr',
                              'WebAddr' => {},
                              'CompanyName' => 'Sandbox Company_FR_3',
                              'LegalAddr' => {
                                               'Country' => 'FR',
                                               'Line1' => "58 Rue de l'Abb\x{e9} Gr\x{e9}goire",
                                               'Id' => '1',
                                               'City' => 'Paris',
                                               'PostalCode' => '75006'
                                             },
                              'Email' => {
                                           'Address' => 'fr_sample_company@mailinator.com'
                                         },
                              'domain' => 'QBO',
                              'FiscalYearStartMonth' => 'January',
                              'MetaData' => {
                                              'CreateTime' => '2021-03-19T19:07:43-07:00',
                                              'LastUpdatedTime' => '2021-10-21T14:27:34-07:00'
                                            },
                              'Id' => '1',
                              'EmployerId' => 'RCS PARIS 123123456',
                              'CompanyAddr' => {
                                                 'Line1' => "58 Rue de l'Abb\x{e9} Gr\x{e9}goire",
                                                 'Id' => '1',
                                                 'PostalCode' => '75006',
                                                 'City' => 'Paris',
                                                 'Country' => 'FR'
                                               },
                              'Country' => 'FR',
                              'SyncToken' => '13',
                              'NameValue' => [
                                               {
                                                 'Value' => 'true',
                                                 'Name' => 'NeoEnabled'
                                               },
                                               {
                                                 'Name' => 'NonTracking',
                                                 'Value' => 'false'
                                               },
                                               {
                                                 'Name' => 'IsQbdtMigrated',
                                                 'Value' => 'false'
                                               },
                                               {
                                                 'Name' => 'IndustryType',
                                                 'Value' => 'Boulangeries commerciales'
                                               },
                                               {
                                                 'Value' => 'Company single member limited',
                                                 'Name' => 'CompanyType'
                                               },
                                               {
                                                 'Value' => '311812',
                                                 'Name' => 'IndustryCode'
                                               },
                                               {
                                                 'Name' => 'SubscriptionStatus',
                                                 'Value' => 'SUBSCRIBED'
                                               },
                                               {
                                                 'Name' => 'OfferingSku',
                                                 'Value' => "QuickBooks\x{a0}Plus"
                                               },
                                               {
                                                 'Value' => 'false',
                                                 'Name' => 'PayrollFeature'
                                               },
                                               {
                                                 'Value' => 'false',
                                                 'Name' => 'AccountantFeature'
                                               },
                                               {
                                                 'Name' => 'QBOIndustryType',
                                                 'Value' => 'Entreprises de fabrication'
                                               },
                                               {
                                                 'Name' => 'ItemCategoriesFeature',
                                                 'Value' => 'true'
                                               },
                                               {
                                                 'Value' => '2021-10-21T06:27:33-07:00',
                                                 'Name' => 'AssignedTime'
                                               }
                                             ],
                              'CustomerCommunicationAddr' => {
                                                               'Country' => 'FR',
                                                               'PostalCode' => '75006',
                                                               'City' => 'Paris',
                                                               'Line1' => "58 Rue de l'Abb\x{e9} Gr\x{e9}goire",
                                                               'Id' => '1'
                                                             },
                              'sparse' => bless( do{\(my $o = 0)}, 'JSON::PP::Boolean' )
                            },
           'time' => '2021-10-26T04:10:53.796-07:00'
         };
=cut

PUBLIC (Id          => OF 'num') = undef;
PUBLIC (CompanyName => OF 'str_ne');
PUBLIC (LegalName   => UNDEFOK OF 'strnull');

sub make_ref {
    my $self = shift;
    return new QuickBooks::Objects::CustomerRef value => $self->Id;
}

sub person {
    my $self = shift;
    die "Not setter" if @_;
    return join ' ', grep { length } $self->GivenName, $self->FamilyName;
}

sub phone {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryPhone) {
        return $self->PrimaryPhone->FreeFormNumber;
    }
    return undef;
}

sub email {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->PrimaryEmailAddr) {
        return $self->PrimaryEmailAddr->Address;
    }
    return undef;
}

sub billing_country {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->Country;
    }
    return undef;
}

sub shipping_country {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->Country;
    }
    return undef;
}

sub shipping_address {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->address;
    }
    return undef;
}

sub shipping_address_fmt {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->ShipAddr) {
        return $self->ShipAddr->address_fmt;
    }
    return undef;
}

sub billing_address {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->address;
    }
    return undef;
}

sub billing_address_fmt {
    my $self = shift;
    die "Not setter" if @_;
    if ($self->BillAddr) {
        return $self->BillAddr->address_fmt;
    }
    return undef;
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;

    return $res;
}

1;
