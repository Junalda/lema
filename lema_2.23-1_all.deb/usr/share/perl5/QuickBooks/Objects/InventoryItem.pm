package QuickBooks::Objects::InventoryItem;
use common::sense;
use Woof;

PUBLIC (Qty                 => OF 'float') = undef;
PUBLIC (ProductsAndService  => OF 'str_ne') = undef;
PUBLIC (SKU                 => UNDEFOK OF 'str') = undef;
PUBLIC (CalcAvg             => OF 'float') = undef;
PUBLIC (AssetValue          => OF 'float') = undef;

sub _Qty_ {
    my $self = shift;
    return 0 unless length $_[0];
    VALIDATE;
    return $_[0];
}


sub _CalcAvg_ {
    my $self = shift;
    return 0 unless length $_[0];
    VALIDATE;
    return $_[0];
}


sub _AssetValue_ {
    my $self = shift;
    return 0 unless length $_[0];
    VALIDATE;
    return $_[0];
}

1;
