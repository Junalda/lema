package QuickBooks::Objects::EntityRef;
use common::sense;
use Woof;

=head1 EXAMPLE
2020-10-16 09:41:49 +0200 +       "EntityRef" : {
2020-10-16 09:41:49 +0200 +          "type" : "Vendor",
2020-10-16 09:41:49 +0200 +          "value" : "123",
2020-10-16 09:41:49 +0200 +          "name" : "ABC LLC"
2020-10-16 09:41:49 +0200 +       },
=cut

PUBLIC (value => OF 'num');
PUBLIC (name  => OF 'str_ne');
PUBLIC (type  => OF 'str_ne');

1;
