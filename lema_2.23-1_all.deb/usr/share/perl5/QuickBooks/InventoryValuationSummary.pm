package QuickBooks::InventoryValuationSummary;
use common::sense;
use Carp;
use Data::Dumper;
use Try::Tiny;
use Safe::Isa;
use QuickBooks::Objects::Fault;
use QuickBooks::Globals;
use QuickBooks::Objects::InventoryItem;
use parent qw(QuickBooks::parent);

sub create {
    my ($self, $in) = @_;
    my $href;
    unless (ref $in) {
        my $display_name = $in;
        croak "Invalid display name"
            unless !ref $display_name && length $display_name;

        my $obj = new QuickBooks::Objects::Customer DisplayName => $display_name;
        $href = $self->qb->ua->http_post('customer',
                                            { DisplayName => $obj->DisplayName });

    } else {
        die "Invalid object" unless $in->$_isa('QuickBooks::Objects::Customer');
        my $obj = $in;
        AE::log trace => "Create customer from object: %s", Dumper+$obj;
        $href = $self->qb->ua->http_post('customer', $obj->OUTWOOF);
    }

    return new QuickBooks::Objects::Customer $href->{Customer};
}

sub upsert {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Customer');

        $obj->Id(undef);
        my $exists = $self->query_by_display_name($obj->DisplayName);
        if ($exists) {
            $obj->SyncToken($exists->SyncToken);
            $obj->Id($exists->Id);
        }

    return $self->create($obj);
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Customer}}) {
        my $obj = new QuickBooks::Objects::Customer $_;
        push @list, $obj;
    }

    @list
}


sub query {
    my $self = shift;
    my $href = $self->qb->ua->http_get("reports/InventoryValuationSummary");

    die "No columns in inventory response" unless $href->{Columns};
    die "No column data in inventory response" unless $href->{Columns}{Column};

    my $cols = $href->{Columns}{Column};
    die "Invalid column data" unless ref $cols eq 'ARRAY';

    return unless $href->{Rows} && $href->{Rows}{Row};
    my $rows = $href->{Rows}{Row};

    my %header_ids;
    my @all;

    my %col_datas;
    for (my $n = 0; $n < @$rows; $n++) {
        my $hash = $rows->[$n];

        if (ref $hash->{Rows} eq 'HASH' &&
            ref $hash->{Rows}{Row} eq 'ARRAY' &&
            ref $hash->{Header} eq 'HASH' &&
            ref $hash->{Header}{ColData} eq 'ARRAY' &&
            ref $hash->{Header}{ColData}[0] eq 'HASH' &&
            length $hash->{Header}{ColData}[0]{value}) {
            my $header = $hash->{Header}{ColData}[0]{value};
            $header_ids{$hash->{Header}{ColData}[0]{id}} = 1;

            my $inner_rows = $hash->{Rows}{Row};
            for (my $k = 0; $k < @$inner_rows; $k++) {
                push @{$col_datas{$header}}, $inner_rows->[$k]->{ColData};
            }
        } else {
            push @{$col_datas{''}}, $hash->{ColData};
        }
    }

    for my $header (sort keys %col_datas) {
        my $aref = $col_datas{$header};

        for (my $n = 0; $n < @$aref; $n++) {
            my $row = $aref->[$n];

            if (length $row->[0]{id}) {
                next if $header_ids{$row->[0]{id}};
            } else {
                next;
            }

            my %new;
            for (my $i = 0; $i < @$row; $i++) {
                my $title = $cols->[$i]->{ColTitle} || $cols->[$i]->{ColType};
                $title =~ s/\W//g;
                die "Title is empty" unless length $title;

                my $value = $row->[$i]->{value};
                $value = undef unless length $value;

                $new{$title} = $value;
            }

            if ($new{ProductsAndService} eq 'TOTAL' &&
                $new{SKU} eq ' ' &&
                $n + 1 == @$rows) {
                next;
            }

            if (!length $new{ProductsAndService}) {
                next;
            }

            $new{ProductsAndService} = "$header:$new{ProductsAndService}"
                if length $header;

            my $item = QuickBooks::Objects::InventoryItem->new(\%new);
            push @all, $item;
        }
    }

    return @all;
}

sub query_by_display_name {
    my ($self, $display_name) = @_;

    croak "Invalid display name"
        unless !ref $display_name && length $display_name;

    AE::log debug => "Find customer by Display Name %s...", $display_name;
    my @list = $self->_query(
        qq{select * from Customer where DisplayName = '$display_name'}
    );

    return undef unless @list;

    if (@list > 1) {
        my @ids   = map { $_->Id } @list;
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_DUP_ON_QUERY,
            'Multiple number of customers with the same display name',
            sprintf('Multiple customers with the same display name: %s',
                    join(', ', @ids));

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    return $list[0];
}

sub query_by_id {
    my ($self, $id) = @_;

    croak "Invalid ID"
        unless !ref $id && length $id;

    AE::log debug => "Find customer by ID %s...", $id;
    my @list = $self->_query(
        qq{select * from Customer where Id = '$id'}
    );

    return undef unless @list;
    return $list[0];
}

sub find_or_insert {
    my ($self, $in) = @_;

    my $customer = try {
        $self->create($in);
    } catch {
        if ($_->$_isa('QuickBooks::Objects::Fault') && $_->is_duplicate) {
            AE::log info => "Customer with the display name already exists";
        } else {
            die $_;
        }

        my $display_name = ref $in ? $in->DisplayName : $in;
        my @list = $self->query_by_display_name($display_name);
        return $list[0];
    };

    return $customer;
}


1;
