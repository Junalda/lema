package QuickBooks::TaxCode;
use common::sense;
use Carp;
use Data::Dumper;
use QuickBooks::Globals;
use QuickBooks::Objects::TaxCode;
use parent qw(QuickBooks::parent);


sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{TaxCode}}) {
        my $obj = new QuickBooks::Objects::TaxCode $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from TaxCode STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find tax code by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from TaxCode where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Tax code with ID %s is not found", $id;
        return undef;
    }

    return $list[0];
}

=head1
sub query_by_fqn {
    my ($self, $fqn) = @_;

    croak "Invalid fully qualified name"
        unless !ref $fqn && length $fqn;

    my @list = $self->_query(
        qq{select * from Account where FullyQualifiedName = '$fqn'});

    if (@list > 1) {
        my @ids   = map { $_->Id } @list;
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_DUP_ON_QUERY,
            'Multiple number of accounts with the same fully qualified name',
            sprintf('Multiple accounts with the same fully qualified name: %s',
                    join(', ', @ids));

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    return $list[0];
}
=cut

1;
