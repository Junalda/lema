package QuickBooks::Bill;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use QuickBooks::Objects;
use QuickBooks::Globals;
use parent qw(QuickBooks::parent);

sub create {
    my ($self, $bill) = @_;
    croak "Invalid bill in arguments"
        unless $bill->$_isa('QuickBooks::Objects::Bill');
    die "Bill object is with ID" if $bill->Id;

    my $hash = $bill->OUTWOOF;
    my $href = $self->qb->ua->http_post('bill', $hash);
    return QuickBooks::Objects::Bill->new($href->{Bill});
}

sub update {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Bill');
    die "No bill ID" unless $obj->Id;

    my $exists = $self->query_by_id($obj->Id);
    die "No bill found to update\n" unless $exists;

    $obj->SyncToken($exists->SyncToken);

    my $hash = $obj->OUTWOOF;
    my $href = $self->qb->ua->http_post('bill', $hash);
    return new QuickBooks::Objects::Bill $href->{Bill};
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Bill}}) {

        my $obj = new QuickBooks::Objects::Bill $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Bill STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_doc_number {
    my ($self, $doc_number) = @_;
    die "Invalid document number\n"
        unless !ref $doc_number && length $doc_number &&
               $doc_number !~ /(\s|\:|\')/;

    my @list = $self->_query(
        qq{select * from Bill where DocNumber = '$doc_number'}
    );

    die "Multiple bills returned for document number" if @list > 1;
    return @list ? $list[0] : undef;
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find bill by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from Bill where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Bill with ID %s is not found", $id;
        return undef;
    }
    return $list[0];
}

sub find_by_doc_numbers {
    my $self = shift;
    my @res;

    croak "No document numbers to find bills" unless @_;

    for my $doc_number (@_) {
        my @list = $self->query_by_doc_number($doc_number);

        unless (@list) {
            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_REC_NOT_FOUND,
                'Not found bill by document number',
                'Not found bill by document number ' . $doc_number;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        my $last_value;
        for (@list) {
            unless (defined $last_value) {
                $last_value = $_->CustomerRef->value;
                next;
            }

            next if $_->CustomerRef->value == $last_value;

            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_DATA_CONFLICT,
                'Different customers in bill finding results',
                'Different customers in bills: ' .
                join(', ', map({ $_->CustomerRef->value } @list))
            ;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        push @res, @list;
    }

    @res
}

sub find_or_insert {
    my ($self, $bill) = @_;

    croak "Invalid bill in arguments"
        unless $bill->$_isa('QuickBooks::Objects::Bill');

    croak "No document num of bill to insert"
        unless defined $bill->DocNumber;

    my $new_bill = try {
        return $self->create($bill);
    }
    catch {
        die $_ unless $_->$_isa('QuickBooks::Objects::Fault') &&
                      $_->is_duplicate;

        my @list = $self->query_by_doc_number($bill->DocNumber);

        my $el = $list[0];


        return $list[0];
    };

    $new_bill
}

sub read : method {
    my ($self, $bill_id) = @_;

    croak "No valid bill ID"
        unless length $bill_id;

    my $href = $self->qb->ua->http_get("bill/$bill_id");

    return new QuickBooks::Objects::Bill $href->{Bill};
}

sub delete_by_doc_num {
    my ($self, $doc_num) = @_;
    my $bill = $self->query_by_doc_number($doc_num);
    return unless $bill;


    my $href = $self->qb->ua->http_post(
        "bill",
        { Id => $bill->Id, SyncToken => $bill->SyncToken },
        { operation => 'delete'}
    );


    ()
}

sub delete_by_id {
    my ($self, $id) = @_;

    my $bill = $self->find_by_id($id);

    unless ($bill) {
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_REC_NOT_FOUND,
            "Not found bill by ID",
            "Not found bill by ID: $id";

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    my @ret;

    my $href = $self->qb->ua->http_post(
        "bill",
        { Id => $bill->Id, SyncToken => $bill->SyncToken },
        { operation => 'delete'}
    );

    unless ($href->{Bill}) {
        die "Couldn't delete bill\n";
    }
    ()
}

sub find_by_id {
    my ($self, $id) = @_;
    croak "No valid bill ID" unless length $id;

    my $href = $self->qb->ua->http_get("bill/$id");
    return new QuickBooks::Objects::Bill $href->{Bill};
}

1;
