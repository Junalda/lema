package QuickBooks::Term;
use common::sense;
use Carp;
use Data::Dumper;
use QuickBooks::Globals;
use QuickBooks::Objects::Term;
use parent qw(QuickBooks::parent);

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Term}}) {
        my $obj = new QuickBooks::Objects::Term $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    return $self->_query(qq{select * from Term MAXRESULTS 1000});
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find term by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from Term where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Term with ID %s is not found", $id;
        return undef;
    }

    return $list[0];
}

1;
