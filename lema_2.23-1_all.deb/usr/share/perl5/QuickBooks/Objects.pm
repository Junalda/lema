package QuickBooks::Objects;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Math::BigFloat;
use QuickBooks::Objects::Credentials;
use QuickBooks::Objects::Customer;
use QuickBooks::Objects::CompanyInfo;
use QuickBooks::Objects::AccountRef;
use QuickBooks::Objects::TxnTaxDetail;
use QuickBooks::Objects::CurrencyRef;
use QuickBooks::Objects::Item;
use QuickBooks::Objects::ItemRef;
use QuickBooks::Objects::ItemAccountRef;
use QuickBooks::Objects::CustomerRef;
use QuickBooks::Objects::Detail;
use QuickBooks::Objects::Invoice;
use QuickBooks::Objects::PaymentMethodRef;
use QuickBooks::Objects::Purchase;
use QuickBooks::Objects::PurchaseOrder;
use QuickBooks::Objects::Bill;
use QuickBooks::Objects::Vendor;
use QuickBooks::Objects::_TxnDateMethods;

sub dateYYYYMMDD::INWOOF() {
    my @args = @_;
    my $err;

    if (@args == 1) {
        $err = try {
            QuickBooks::Objects::_TxnDateMethods::__validate_txndate_format(
                $args[0]);
            return undef;
        } catch {
            return $_;
        };
    }
    else {
        $err = "Bad number of INWOOF arguments";
    }

    if (defined $err) {
        Carp::croak("Invalid date `$_->{name}': ", $err, " (arguments are ",
                    join(',', map { $_ // '<undef>' } @args),
                    ")");
    }

    $_->referent = '' . $args[0];

    ()
}

sub dateYYYYMMDD::OUTWOOF { $_[0] }

sub create_sales_item_line_detail($$) {
    my ($amount, $item_ref) = @_;

    return new QuickBooks::Objects::Detail {
            "DetailType" => "SalesItemLineDetail",
            "Amount"     => $amount,
            "SalesItemLineDetail" => {
                ItemRef => $item_ref,
                ItemAccountRef => undef,
            },
    };
}

sub create_sales_item_line_detail_from_qty($$$) {
    my ($qty, $unit_price, $item_ref) = @_;

    my $amount = new Math::BigFloat $unit_price;
    $amount = $amount * $qty;

    return new QuickBooks::Objects::Detail {
            "DetailType" => "SalesItemLineDetail",
            "Amount"     => ''.$amount,
            "SalesItemLineDetail" => {
                Qty       => $qty,
                UnitPrice => $unit_price,
                ItemRef   => $item_ref,
                ItemAccountRef => undef,
            },
    };
}

sub create_transaction($$;$) {
    my ($amount, $txn_id_or_txn, $txn_type) = @_;

    if (@_ == 3) {
        return new QuickBooks::Objects::Transaction
            Amount    => $amount,
            LinkedTxn => [ { TxnId => $txn_id_or_txn, TxnType => $txn_type } ];
    }

    return new QuickBooks::Objects::Transaction
        Amount    => $amount,
        LinkedTxn => [ $txn_id_or_txn ];
}

1;
