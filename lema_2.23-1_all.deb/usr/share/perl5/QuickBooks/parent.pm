package QuickBooks::parent;
use common::sense;
use Carp;
use Safe::Isa;
use Scalar::Util;

sub new {
    my ($class, $qb) = @_;

    croak "No QuickBooks parent class"
        unless $qb->$_isa('QuickBooks');

    my $self = { qb => $qb };
    bless $self, $class;

    Scalar::Util::weaken($self->{qb});

    $self
}

sub qb {
    croak "No QuickBooks parent class"
        unless $_[0]{qb};

    $_[0]{qb}
}

1;
