package QuickBooks::Vendor;
use common::sense;
use Carp;
use Data::Dumper;
use Try::Tiny;
use Safe::Isa;
use QuickBooks::Globals;
use QuickBooks::Objects::Vendor;
use parent qw(QuickBooks::parent);

sub create {
    my ($self, $in) = @_;
    my $href;
    unless (ref $in) {
        my $display_name = $in;
        croak "Invalid display name"
            unless !ref $display_name && length $display_name;

        my $obj = new QuickBooks::Objects::Vendor DisplayName => $display_name;
        $href = $self->qb->ua->http_post('vendor',
                                            { DisplayName => $obj->DisplayName });

    } else {
        die "Invalid object" unless $in->$_isa('QuickBooks::Objects::Vendor');
        my $obj = $in;
        AE::log trace => "Create vendor from object: %s", Dumper+$obj;
        $href = $self->qb->ua->http_post('vendor', $obj->OUTWOOF);
    }

    return QuickBooks::Objects::Vendor->new($href->{Vendor});
}


sub _query {
    my ($self, $query) = @_;
    croak "No valid query string" unless !ref $query && length $query;
    my $href = $self->qb->ua->http_get('query', { query => $query });

    my @list;
    for (@{$href->{QueryResponse}{Vendor}}) {
        my $obj = new QuickBooks::Objects::Vendor $_;


        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Vendor STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_display_name {
    my ($self, $display_name) = @_;

    croak "Invalid display name"
        unless !ref $display_name && length $display_name;

    my @list = $self->_query(
        qq{select * from Vendor where DisplayName = '$display_name'}
    );

    if (@list > 1) {
        my @ids   = map { $_->Id } @list;
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_DUP_ON_QUERY,
            'Multiple number of vendors with the same display name',
            sprintf('Multiple vendors with the same display name: %s',
                    join(', ', @ids));

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    @list
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find vendor by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from Vendor where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Vendor with ID %s is not found", $id;
        return undef;
    }
    return $list[0];
}

sub upsert {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Vendor');

    $obj->Id(undef);
    my $exists = $self->query_by_display_name($obj->DisplayName);
    if ($exists) {
        $obj->SyncToken($exists->SyncToken);
        $obj->Id($exists->Id);
    }

    return $self->create($obj);
}

sub update {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Vendor');
    die "No vendor ID" unless $obj->Id;

    my $exists = $self->query_by_id($obj->Id);
    die "No vendor found to update\n" unless $exists;

    $obj->SyncToken($exists->SyncToken);

    return $self->create($obj);
}

sub find_or_insert {
    my ($self, $display_name) = @_;

    croak "Invalid display name"
        unless !ref $display_name && length $display_name;

    my $vendor = try {
        $self->create($display_name);
    } catch {
        die $_ if !$_->$_isa('QuickBooks::Objects::Fault') || !$_->is_duplicate;

        my @list = $self->query_by_display_name($display_name);
        return $list[0];
    };

    return $vendor;
}


1;
