package QuickBooks::Utils::Date;
use common::sense;
use Data::Dumper;
use POSIX;
use Carp;
use Try::Tiny;
use Date::Language;
use Date::Parse;
use Date::Format qw(time2str);

our @LANG_ORDER = qw(
        English German French Italian Russian Chinese Chinese_GB

        Afar
        Amharic                 Gedeo
        Austrian                                        Sidama
        Brazilian               Greek                   Somali
                                Hungarian               Spanish
                                Icelandic               Swedish
        Czech                                           Tigrinya
        Danish                  Norwegian               TigrinyaEritrean
        Dutch                   Oromo                   TigrinyaEthiopian
                                Romanian                Turkish
        Finnish                                         Bulgarian
);

sub str_to_epoch($) {
    my $date = shift;
    croak "Invalid date string in argument" if ref $date;
    return undef unless length $date;

    if ($date =~ /^\d{1,8}$/) {
        return undef if $date < 1000_00_00;
    }

    if ($date =~ m!^(\d{2})/(\d{2})/(\d{4})$!) {
        $date = "$3-$2-$1";
    }

    my $epoch;
    for my $lang (@LANG_ORDER) {
        my $l   = Date::Language->new($lang);
        my $ptr = \$date;

        $epoch = try {
            $l->str2time($$ptr, 'GMT')

        } catch {
            return undef;
        };

        last if $epoch;
    }

    if (!$epoch && $date =~ /^(\d+)(\.\d+)?$/) {
        $epoch = $1;
    }

    return $epoch ? int($epoch) : undef;
}

sub str_to_gmt_datenum($) {
    my $epoch = str_to_epoch($_[0]);

    if ($epoch) {
        my $datenum = time2str("%Y%m%d", int($epoch), 'GMT');
        return int $datenum if $datenum;
    }

    return undef;
}

sub str_to_gmt_date($) {
    my $epoch = str_to_epoch($_[0]);

    if ($epoch) {
        my $datenum = time2str("%Y-%m-%d", int($epoch), 'GMT');
        return $datenum if $datenum;
    }

    return undef;
}

sub today_YYYYMMDD() {
    my $today = POSIX::strftime('%Y%m%d', gmtime);
    return int $today;
}

sub epoch_to_date($) {
    croak "Invalid epoch to make the date"
        unless !ref $_[0] && $_[0] > 0;

    my $epoch = int $_[0];
    my $date = time2str("%Y-%m-%d %H:%M:%S GMT", $epoch, 'GMT');
    return $date;
}

sub epoch_into_filename($) {
    croak "Invalid epoch to make the date"
        unless !ref $_[0] && $_[0] > 0;

    my $epoch = int $_[0];
    my $date = time2str("%Y-%m-%dT%H%M%SZ", $epoch, 'GMT');

    return $date;
}

1;
