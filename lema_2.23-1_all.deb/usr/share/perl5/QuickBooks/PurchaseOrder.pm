package QuickBooks::PurchaseOrder;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use QuickBooks::Objects;
use QuickBooks::Objects::PurchaseOrder;
use QuickBooks::Globals;
use parent qw(QuickBooks::parent);

our $DOC_NUMBER_IS_UNIQUE = 1;


sub create {
    my ($self, $in) = @_;
    my $href;
    die "Invalid purchase order object" unless $in->$_isa('QuickBooks::Objects::PurchaseOrder');
    my $obj = $in;
    AE::log trace => "Create purchase order from object: %s", Dumper+$obj;
    $href = $self->qb->ua->http_post('purchaseorder', $obj->OUTWOOF);
    return QuickBooks::Objects::PurchaseOrder->new($href->{PurchaseOrder});
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{PurchaseOrder}}) {
        my $obj = new QuickBooks::Objects::PurchaseOrder $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from PurchaseOrder STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}


sub query_by_vendor_id {
    my ($self, $vendor_id) = @_;
    croak "No vendor ID" unless !ref $vendor_id && length $vendor_id;
    croak "Invalid vendor ID" unless $vendor_id =~ /^\d+$/;
    return $self->_query(qq{select * from PurchaseOrder where VendorRef = '$vendor_id'});
}

sub query_vvv {
    my ($self, $vendor_id) = @_;
    croak "No vendor ID" unless !ref $vendor_id && length $vendor_id;
    croak "Invalid vendor ID" unless $vendor_id =~ /^\d+$/;
    return $self->_query(qq{select * from VendorCredit});
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find purchase order by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from PurchaseOrder where Id = '$id'
    });

    unless (@list) {
        die sprintf "Purchase Order with ID %s is not found\n", $id;
    }
    return $list[0];
}

sub copy_to_bill {
    my ($self, $po) = @_;
    die "Invalid purchase order object"
        unless $po->$_isa('QuickBooks::Objects::PurchaseOrder');
    die "No purchase order ID"
        unless $po->Id;
    die "Purchase order already is with linked bill"
        if $po->has_linked_bill_id;

    my $href = $po->OUTWOOF;
    $href->{APAccountRef} = { value => 83 };

    delete $href->{Id};
    delete $href->{SyncToken};
    delete $href->{PrivateNote};

    for (1 .. 2) {
        my $bill = QuickBooks::Objects::Bill->new($href);
        $bill->link_purchase_order_id($po->Id);
        $bill->Balance($po->TotalAmt);
        $bill->TotalAmt($po->TotalAmt);

        my $bill_updated = $self->qb->bill->create($bill);

        if ($bill_updated->has_linked_purchase_order_id) {
            AE::log info => "Bill for purchase order has been created";
            return $bill_updated->Id;
        }


        my $tmp = $self->qb->bill->query_by_id($bill_updated->Id);
        if ($tmp->has_linked_purchase_order_id) {
            AE::log info => "Bill for purchase order has been created";
            return $bill_updated->Id;
        }

        $self->qb->bill->delete_by_id($tmp->Id);
    }

    die "Failed to link new Bill w/ Purchase Order\n";
    ()
}

sub link_bill {
    my ($self, $po, $bill) = @_;
    die "Invalid purchase order object"
        unless $po->$_isa('QuickBooks::Objects::PurchaseOrder');
    die "No purchase order ID"
        unless $po->Id;
    die "Purchase order already is with some linked bill"
        if $po->has_linked_bill_id;
    die "Invalid bill object"
        unless $bill->$_isa('QuickBooks::Objects::Bill');
    die "No bill ID"
        unless $bill->Id;
    die "Bill already is with some linked purchase order"
        if $bill->has_linked_purchase_order_id;

    if ($po->VendorRef->value != $bill->VendorRef->value) {
        die sprintf "Bill with ID %s (document number %s) has not " .
                    "the same supplier as Purchase Order with ID %s " .
                    "(document number %s)\n",
                    $bill->Id, $bill->DocNumber, $po->Id, $po->DocNumber;
    }

    for (1 .. 2) {
        $bill->link_purchase_order_id($po->Id);
        $bill->Balance($po->TotalAmt);
        $bill->TotalAmt($po->TotalAmt);

        my $bill_updated = $self->qb->bill->update($bill);

        if ($bill_updated->has_linked_purchase_order_id) {
            AE::log info => "Bill for purchase order has been created";
            return $bill_updated->Id;
        }

        my $tmp = $self->qb->bill->query_by_id($bill_updated->Id);
        if ($tmp->has_linked_purchase_order_id) {
            AE::log info => "Bill for purchase order has been created";
            return $bill_updated->Id;
        }

        $bill = $tmp;
    }

    die "Failed to link existing Bill with ID ", $bill->Id,
        "to Purchase Order\n";
    ()
}

sub update {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::PurchaseOrder');
    die "No purchase order ID" unless $obj->Id;

    my $exists = $self->query_by_id($obj->Id);
    die "No purchase order found to update\n" unless $exists;

    $obj->SyncToken($exists->SyncToken);

    return $self->create($obj);
}

sub query_by_doc_number {
    my ($self, $doc_number) = @_;

    croak "Invalid document number"
        unless !ref $doc_number && length $doc_number &&
               $doc_number !~ /(\s|\:|\')/;

    my @list = $self->_query(
        qq{select * from PurchaseOrder where DocNumber = '$doc_number'}
    );

    return undef unless @list;
    return $list[0];
}

sub find_by_doc_numbers {
    my $self = shift;
    my @res;

    croak "No document numbers to find purchases" unless @_;

    for my $doc_number (@_) {
        my @list = $self->query_by_doc_number($doc_number);

        unless (@list) {
            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_REC_NOT_FOUND,
                'Not found purchase by document number',
                'Not found purchase by document number ' . $doc_number;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        my $last_value;
        for (@list) {
            unless (defined $last_value) {
                $last_value = $_->CustomerRef->value;
                next;
            }

            next if $_->CustomerRef->value == $last_value;

            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_DATA_CONFLICT,
                'Different customers in purchase finding results',
                'Different customers in purchases: ' .
                join(', ', map({ $_->CustomerRef->value } @list))
            ;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        push @res, @list;
    }

    @res
}

sub find_or_insert {
    my ($self, $purchase) = @_;

    croak "Invalid purchase in arguments"
        unless $purchase->$_isa('QuickBooks::Objects::Purchase');

    croak "No document num of purchase to insert"
        unless defined $purchase->DocNumber;

    my $new_purchase = try {
        return $self->create($purchase);
    }
    catch {
        die $_ unless $_->$_isa('QuickBooks::Objects::Fault') &&
                      $_->is_duplicate;

        my @list = $self->query_by_doc_number($purchase->DocNumber);

        my $el = $list[0];



        return $list[0];
    };

    $new_purchase
}

sub find_by_id {
    my ($self, $id) = @_;
    croak "No valid purchase order ID" unless length $id;

    my $href = $self->qb->ua->http_get("purchaseorder/$id");
    return new QuickBooks::Objects::PurchaseOrder $href->{PurchaseOrder};
}

sub _delete_by {
    my ($self, $doc_num, $id) = @_;

    my @list = defined $doc_num
             ? $self->query_by_doc_number($doc_num)
             : $self->find_by_id($id);

    unless (@list) {
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_REC_NOT_FOUND,
            'Not found purchase by doc num or ID to delete',
            'Not found purchase by doc num or ID to delete: ' .
                ($doc_num // $id);

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    my @ret;
    for (@list) {
        my $href = $self->qb->ua->http_post(
            "purchase",
            { Id => $_->Id, SyncToken => $_->SyncToken },
            { operation => 'delete'}
        );

        $href->{Purchase}{PaymentType} = $_->PaymentType;
        $href->{Purchase}{EntityRef}   = $_->EntityRef;
        $href->{Purchase}{AccountRef}  = $_->AccountRef;

        my $obj = new QuickBooks::Objects::Purchase $href->{Purchase};
        push @ret, $obj;
    }

    @ret
}

sub delete_by_doc_num {
    my ($self, $doc_num) = @_;
    return $self->_delete_by($doc_num, undef);
}

sub delete_by_id {
    my ($self, $id) = @_;

    my @list = $self->find_by_id($id);

    unless (@list) {
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_REC_NOT_FOUND,
            "Not found purchase order by ID",
            "Not found purchase order by ID: $id";

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    my @ret;
    for (@list) {
        my $href = $self->qb->ua->http_post(
            "purchaseorder",
            { Id => $_->Id, SyncToken => $_->SyncToken },
            { operation => 'delete'}
        );

        if ($href->{PurchaseOrder}) { return 1; }
        die "Couldn't delete purchase order\n";
    }

}

1;
