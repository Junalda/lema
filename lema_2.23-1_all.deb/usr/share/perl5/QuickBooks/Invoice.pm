package QuickBooks::Invoice;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use QuickBooks::Objects;
use QuickBooks::Globals;
use parent qw(QuickBooks::parent);

sub create {
    my ($self, $invoice) = @_;
    croak "Invalid invoice in arguments"
        unless $invoice->$_isa('QuickBooks::Objects::Invoice');
    die "Invoice object is with ID" if $invoice->Id;

    my $href = $self->qb->ua->http_post('invoice', $invoice->OUTWOOF);
    return QuickBooks::Objects::Invoice->new($href->{Invoice});
}

sub update {
    my ($self, $obj) = @_;
    die "Invalid object" unless $obj->$_isa('QuickBooks::Objects::Invoice');
    die "No invoice ID" unless $obj->Id;

    my $exists = $self->query_by_id($obj->Id);
    die "No invoice found to update\n" unless $exists;

    $obj->SyncToken($exists->SyncToken);

    my $href = $self->qb->ua->http_post('invoice', $obj->OUTWOOF);
    return new QuickBooks::Objects::Invoice $href->{Invoice};
}

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Invoice}}) {
        my $obj = new QuickBooks::Objects::Invoice $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    my @all;
    my ($start, $max) = (1, 1000);
    while () {
        my @chunk = $self->_query(qq{select * from Invoice STARTPOSITION $start MAXRESULTS $max});
        push @all, @chunk if @chunk;
        last if @chunk < $max;
        $start += $max;
    }
    return @all;
}

sub query_by_doc_number {
    my ($self, $doc_number) = @_;
    die "Invalid document number\n"
        unless !ref $doc_number && length $doc_number &&
               $doc_number !~ /(\s|\:|\')/;

    my @list = $self->_query(
        qq{select * from Invoice where DocNumber = '$doc_number'}
    );

    die "Multiple invoices returned for document number" if @list > 1;
    return @list ? $list[0] : undef;
}

sub query_by_id {
    my ($self, $id) = @_;
    croak "Invalid ID" unless !ref $id && length $id;

    AE::log debug => "Find invoice by ID %s...", $id;
    my @list = $self->_query(qq{
        select * from Invoice where Id = '$id'
    });

    unless (@list) {
        AE::log error => "Invoice with ID %s is not found", $id;
        return undef;
    }
    return $list[0];
}

sub find_by_doc_numbers {
    my $self = shift;
    my @res;

    croak "No document numbers to find invoices" unless @_;

    for my $doc_number (@_) {
        my @list = $self->query_by_doc_number($doc_number);

        unless (@list) {
            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_REC_NOT_FOUND,
                'Not found invoice by document number',
                'Not found invoice by document number ' . $doc_number;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        my $last_value;
        for (@list) {
            unless (defined $last_value) {
                $last_value = $_->CustomerRef->value;
                next;
            }

            next if $_->CustomerRef->value == $last_value;

            my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
                QB_ERROR_DATA_CONFLICT,
                'Different customers in invoices finding results',
                'Different customers in invoices: ' .
                join(', ', map({ $_->CustomerRef->value } @list))
            ;

            AE::log trace => "Local error JSON: %s", $fault->JSON;
            die $fault;
        }

        push @res, @list;
    }

    @res
}

sub find_or_insert {
    my ($self, $invoice) = @_;

    croak "Invalid invoice in arguments"
        unless $invoice->$_isa('QuickBooks::Objects::Invoice');

    croak "No document num of invoice to insert"
        unless defined $invoice->DocNumber;

    my $new_invoice = try {
        return $self->create($invoice);
    }
    catch {
        die $_ unless $_->$_isa('QuickBooks::Objects::Fault') &&
                      $_->is_duplicate;

        my @list = $self->query_by_doc_number($invoice->DocNumber);

        my $el = $list[0];



        return $list[0];
    };

    $new_invoice
}

sub read : method {
    my ($self, $invoice_id) = @_;

    croak "No valid invoice ID"
        unless length $invoice_id;

    my $href = $self->qb->ua->http_get("invoice/$invoice_id");

    return new QuickBooks::Objects::Invoice $href->{Invoice};
}

sub delete_by_doc_num {
    my ($self, $doc_num) = @_;
    my $invoice = $self->query_by_doc_number($doc_num);
    return unless $invoice;


    my $href = $self->qb->ua->http_post(
        "invoice",
        { Id => $invoice->Id, SyncToken => $invoice->SyncToken },
        { operation => 'delete'}
    );


    ()
}

sub delete_by_id {
    my ($self, $id) = @_;

    my $invoice = $self->find_by_id($id);

    unless ($invoice) {
        my $fault = QuickBooks::Objects::Fault::LOCAL_ERROR
            QB_ERROR_REC_NOT_FOUND,
            "Not found invoice by ID",
            "Not found invoice by ID: $id";

        AE::log trace => "Local error JSON: %s", $fault->JSON;
        die $fault;
    }

    my @ret;

    my $href = $self->qb->ua->http_post(
        "invoice",
        { Id => $invoice->Id, SyncToken => $invoice->SyncToken },
        { operation => 'delete'}
    );

    unless ($href->{Invoice}) {
        die "Couldn't delete invoice\n";
    }
    ()
}

sub find_by_id {
    my ($self, $id) = @_;
    croak "No valid invoice ID" unless length $id;

    my $href = $self->qb->ua->http_get("invoice/$id");
    return new QuickBooks::Objects::Invoice $href->{Invoice};
}

1;
