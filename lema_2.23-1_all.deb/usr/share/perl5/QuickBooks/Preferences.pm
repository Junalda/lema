package QuickBooks::Preferences;
use common::sense;
use Carp;
use Data::Dumper;
use QuickBooks::Globals;
use QuickBooks::Objects::Preferences;
use parent qw(QuickBooks::parent);

sub _query {
    my ($self, $query) = @_;

    croak "No valid query string"
        unless !ref $query && length $query;

    my $href = $self->qb->ua->http_get('query', {
        query => $query,
    });

    my @list;
    for (@{$href->{QueryResponse}{Preferences}}) {
        my $obj = new QuickBooks::Objects::Preferences $_;
        push @list, $obj;
    }

    @list
}

sub query {
    my $self = shift;
    return $self->_query(qq{select * from Preferences MAXRESULTS 1000});
}

sub read {
    my $self = shift;
    my @list = $self->query;
    die "No QBO company preferences\n" unless @list;
    return $list[0];
}

1;
