package LEMA::Util::PDF;
use common::sense;
use File::Temp;

sub generate($) {
    my ($html) = @_;
    die "No HTML data for PDF\n" unless length $html;

    my $html_fh = File::Temp->new(UNLINK => 1, SUFFIX => '.html');
    binmode $html_fh;
    print $html_fh $html;
    $html_fh->flush;
    my $html_path = "$html_fh";

    my $pdf_fh   = File::Temp->new(UNLINK => 1, SUFFIX => '.pdf');
    my $pdf_path = "$pdf_fh";

    system("wkhtmltopdf", "--page-size", "A4", $html_path, $pdf_path);

    open my $fh, '<', $pdf_path or die "PDF file is not found: $!\n";
    binmode $fh;
    my $pdf_bin = do { local $/ = undef; <$fh> };
    close $fh;

    close $pdf_fh;
    close $html_fh;

    return $pdf_bin;
}

1;
