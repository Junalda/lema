package LEMA::Logging;
use common::sense;
use Scalar::Util;
use POSIX ();
use LEMA::Util::Log;

our $VERSION = $LEMA::VERSION;

our $LOG_FILE //= "lema.log";

my ($is_debug, $is_trace, $level) = (0, 0, 'info');

sub is_debug() { $is_debug }
sub is_trace() { $is_trace }

sub setup {
    my $debug = !!shift;
    my $cb    = shift;

    LEMA::Util::Log::setup(*STDERR, 'warn', $cb);

    $is_debug = !!($ENV{SC_DEBUG} || $ENV{SC_TRACE} || $debug);
    $is_trace = !!($ENV{SC_TRACE});

    if ($is_trace) {
        $level = 'trace';
    } elsif ($is_debug) {
        $level = 'debug';
    } else {
        $level = 'info';
    }

    $AnyEvent::Log::FILTER->level($level);

    ()
}

sub enable_log_to_file() {
    $AnyEvent::Log::COLLECT->attach (
       new AnyEvent::Log::Ctx log_to_file => $LOG_FILE);
    ()
}

sub AnyEvent::Log::default_format($$$$) {
    our ($now_int, $now_str);

    if ($_[3] =~ /^autoloaded model/i) {
        return undef;
    }

    my $ts = do {
        my $i = int $_[0];

        if ($now_int != $i) {
            $now_int = $i;
            $now_str = POSIX::strftime "%Y-%m-%d %H:%M:%S %z", localtime $i;
        }

        $now_str
    };

    my $pkg = $_[1][0];
    $pkg =~ s!:+!/!g;
    $pkg = lc $pkg;
    $pkg =~ s!anyevent!event!g;
    $pkg =~ s!carp!logging!g;

    my $ct = " ";
    my @res;

    for (split /\n/,
               sprintf "[%d] [%-5s] %s: %s",
                       $$, $AnyEvent::Log::LEVEL2STR[$_[2]], $pkg, $_[3]) {
        push @res, "$ts$ct$_\n";
        $ct = " + ";
    }

    return join "", @res;
}

sub level(;$) {
    my $new_level  = shift;
    my $prev_level = $level;

    if (length $new_level) {
        $AnyEvent::Log::FILTER->level($new_level);
    }

    return $prev_level;
}

1;
