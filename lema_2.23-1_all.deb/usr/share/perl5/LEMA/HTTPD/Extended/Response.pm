package LEMA::HTTPD::Extended::Response;
use common::sense;
use boolean;
use Carp;
use Scalar::Util;
use LEMA::Template::Static;

our $JSON_CODER;

sub __json_coder() {
    $JSON_CODER //= eval { require JSON::XS; JSON::XS->new->utf8 } ||
                     do  { require JSON::PP; JSON::PP->new->utf8 };

    $JSON_CODER->pretty(1)
               ->relaxed(1)
               ->convert_blessed(1);

    return $JSON_CODER;
}

sub UNIVERSAL::TO_JSON {
    if (Scalar::Util::blessed $_[0]) {
        if ($_[0]->can('as_hashref')) {
            return $_[0]->as_hashref(-outfit => 1);
        } elsif ($_[0]->can('as_arrayref')) {
            return $_[0]->as_arrayref(-outfit => 1);
        } elsif ($_[0]->can('as_string')) {
            return $_[0]->as_string;
        } else {
            croak "No idea how to convert class `", ref $_[0], "' to JSON";
        }
    }

    undef
}

sub new {
    my ($class) = @_;

    my $self = {
            code     => 200,
            status   => "OK",
            json     => 0,
            template => undef,
            debug    => 0,

            username => undef,
            role     => undef,
            showback => undef,

            success  => boolean::false,
            detail   => undef,
            error    => undef,

            reply    => +{},
    };

    bless $self, $class
}

sub debug {
    @_ > 1 ? ($_[0]{debug} = !!$_[1]) : $_[0]{debug};
}

sub username {
    @_ > 1 ? ($_[0]{username} = $_[1]) : $_[0]{username};
}

sub role {
    @_ > 1 ? ($_[0]{role} = $_[1]) : $_[0]{role};
}

sub showback {
    @_ > 1 ? ($_[0]{showback} = $_[1]) : $_[0]{showback};
}

sub code {
    croak "No code setter" if @_ > 1;
    return $_[0]{code};
}

sub status {
    croak "No status setter" if @_ > 1;
    return $_[0]{status};
}

sub success {
    my $self = shift;

    if (@_) {
        $self->{success} = $_[0] ? boolean::true : boolean::false;
        return $self;
    }

    return $self->{success};
}

sub detail {
    my $self = shift;

    if (@_) {
        if (defined $_[0]) {
            unless (!ref $_[0] && length $_[0]) {
                $self->{detail} = '' . $_[0];
            }
        }

        $self->{detail} = $_[0];
        return $self;
    }

    return $self->{detail};
}

sub error {
    my $self = shift;

    if (@_) {
        if (defined $_[0]) {
            croak "Invalid error code"
                unless !ref $_[0] && $_[0] =~ /^\d+$/;

            my $err = int $_[0];

            croak "Invalid error code number"
                unless $err >= 0 && $err <= 0xFFFFFFFF && $_[0] eq $err;

            croak "Error is being set for successfull response"
                if $self->success;

            $self->{error} = $err;
        }
        else {
            $self->{error} = undef;
        }

        return $self;
    }

    return $self->{error};
}

sub set_e {
    my ($self, $e) = @_;

    croak "Invalid exception"
        unless is_e $e;

    $self->error(int $e);
    $self->detail("" . $e);
    ()
}

sub json {
    my $self = shift;

    if (@_) {
        $self->{json} = $_[0] ? 1 : 0;
        return $self;
    }

    return $self->{json};
}

sub template {
    my $self = shift;

    if (@_) {
        if (defined $_[0]) {
            croak "Invalid template filename"
                unless !ref $_[0] && length $_[0];
        }

        $self->{template} = $_[0];
        return $self;
    }

    return $self->{template};
}

sub reply {
    my $self = shift;

    if (@_) {
        my %reply = @_;

        for (keys %reply) {
            $self->{reply}{$_} = $reply{$_};
        }

        return $self;
    }

    return $self->{reply};
}


sub get_headers {
    my %headers;
    if ($_[0]->json) {
        $headers{'Content-Type'} = 'application/json';
    } else {
        $headers{'Content-Type'} = 'text/html';
        $headers{'SC-Trace-Log'} = 0;
    }
    return \%headers;
}

sub get_vars {
    my $self = shift;

    my $ret  = {
        success => $self->success,
        detail  => $self->detail,
        error   => $self->error,
        reply   => $self->reply,
    };

    return $ret;
}

sub get_output {
    my $self = shift;

    if ($self->json) {
        return __json_coder->encode($self->get_vars);
    }
    else {
        my $tmpl = new LEMA::Template::Static TRIM => 1, NOXSS => 1;

        croak "No template filename set"
            unless defined $self->template;

        my $vars = $self->get_vars;

        $vars->{localtime} = localtime;
        $vars->{username}  = $self->username;
        $vars->{role}      = $self->role;
        $vars->{role}      = 1 unless defined $vars->{username};
        $vars->{level}     = $ENV{SC_LEVEL};
        $vars->{version}   = $LEMA::VERSION;

        unless (defined $self->showback) {
            $vars->{showback} = 1;
        } else {
            $vars->{showback} = $self->showback ? 1 : 0;
        }

        if ($self->debug) {
            my $app = LEMA::App->singleton;
            $vars->{internals}{table} = $app->db->inited
                                      ? $app->db->properties->table
                                      : undef;

            my %debug;
            $debug{data}   = __json_coder->pretty(1)->encode($vars);
            $vars->{debug} = \%debug;
        }

        $tmpl->process_static($self->template, $vars, \ my $output);

        if (utf8::is_utf8 $output) {
            utf8::encode $output;
        }


        return $output;
    }
}

sub noreply {
    my $self = shift;
    $self->{reply} = +{};
    $self
}

1;
