package LEMA::Object::ConfigData;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use URI;
use Safe::Isa;
use ACME::E
    O_CFG_DATA_INVALID_INPUT  => [ 4201, "Invalid input for config data" ],
;

our $VERSION = 0.01;

sub new {
    my ($class, $in) = @_;

    if (defined $in) {
        die e40 O_CFG_DATA_INVALID_INPUT
            unless ref $in eq 'HASH';
    } else {
        $in = +{};
    }

    my $self = bless +{}, $class;

    $self->_init_with_all_params($in);
    return $self;
}

sub __prepare_mongodb_uri($) {
    my ($uri) = @_;
    die "No MongoDB connection string\n" unless length $uri;
    die "MongoDB connection string must be not redacted " .
        "(please provide password in connection string)\n"
        if $uri =~ m!\[\*\*REDACTED\*\*\]!;

    my $u = URI->new($uri);

    unless ($u->scheme eq 'mongodb' || $u->scheme eq 'mongodb+srv') {
        die "Invalid scheme in MongoDB connection string (it must begin " .
            "with 'mongodb+srv' or 'mongodb')\n";
    }

    die "No MongoDB database host in connection string\n"
        unless length $u->opaque;
    die "No MongoDB database path in connection string\n"
        unless length $u->path && $u->path =~ m!/(\S+)$!;
    return $u->as_string;
}

sub _init_with_all_params {
    my ($self, $href) = @_;
    my @mongodb;

    if (ref $href->{mongodb} eq 'ARRAY') {
        for (@{$href->{mongodb}}) {
            next unless ref $_ eq 'HASH';
            next unless length $_->{uri};
            my $uri  = __prepare_mongodb_uri($_->{uri});
            my %hash = (uri => $uri, active => boolean::false);
            push @mongodb, \%hash;
        }
    }

    $mongodb[-1]{active} = boolean::true
        if @mongodb;


    $self->{mongodb} = \@mongodb;

    ()
}

sub mongodb {
    my $self = shift;
    return undef unless @{$self->{mongodb}};
    return $self->{mongodb}[-1];
}

sub mongodb_set_uri {
    my ($self, $uri) = @_;
    my $uri = __prepare_mongodb_uri($uri);

    my %hash = (uri    => $uri,
                active => boolean::true);

    unless (@{$self->{mongodb}}) {
        push @{$self->{mongodb}}, \%hash;
    } else {
        $self->{mongodb}[-1] = \%hash;
    }
    ()
}

sub mongodb_get_uri {
    my ($self) = @_;
    unless (@{$self->{mongodb}}) {
        return undef;
    }
    return $self->{mongodb}[-1]{uri};
}

sub mongodb_get_uri_redacted {
    my ($self) = @_;
    my $uri = $self->mongodb_get_uri;
    return undef unless defined $uri;
    $uri =~ s!(\://)([^\:]+\:)[^\@]+!$1 . $2 . '[**REDACTED**]'!ge;
    return $uri;
}

sub as_hashref {
    my $self = shift;
    my %copy = %$self;

    for (keys %copy) {
        if (ref $copy{$_} eq 'HASH') {
            my %inner_copy = %{$copy{$_}};
            $copy{$_} = \%inner_copy;
        }
        elsif (ref $copy{$_} eq 'ARRAY') {
            my @inner_copy = @{$copy{$_}};
            $copy{$_} = \@inner_copy;
        }
    }

    return \%copy;
}

1;
