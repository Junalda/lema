package LEMA::Object::Bill;
use common::sense;
use boolean;
use Safe::Isa;
use BSON::OID;
use Data::Dumper;
use QuickBooks::Objects::VendorRef;
use LEMA::Object::ItemRef;
use parent qw(QuickBooks::Objects::Bill);
use Woof;
use ACME::E;

PUBLIC (error         => UNDEFOK OF 'strnull')   = undef;


PUBLIC (properties    => UNDEFOK OF 'LEMA::DB::Properties::Doc') = undef;


sub extend {
    my ($class, $item) = @_;
    die "Invalid QBO purchase order object"
        unless $item->$_isa('QuickBooks::Objects::Bill');

    return $item if $item->$_isa('LEMA::Object::Bill');

    bless $item, $class;

    my $error;

    unless (length $item->DocNumber =~ /^\d{4}-\d{4}$/) {
        $error //= "Purchase order without LEMA SMAPP document number";
    }

    unless (defined $error) {
        my $line = $item->Line;
        my $has_extended_item = 0;

        if (ref $line eq 'ARRAY' && @$line) {


            for my $detail (@$line) {
                my $item_detail = $detail->ItemBasedExpenseLineDetail;
                unless ($item_detail) {
                    next;
                }

                my $item_ref = $item_detail->ItemRef;

                unless ($item_ref) {
                    next;
                }
                LEMA::Object::ItemRef->extend($item_ref, $detail->Description);
                if ($item_ref->extended) {
                    $has_extended_item = 1;
                }
            }
        } else {
            $error //= "Purchase order without items";
        }

        unless ($has_extended_item) {
            $error //= "No inventory products supported by LEMA SMAPP";
        }
    }

    unless (defined $error) {
        $item->error(undef);
        $item->properties(undef);
    } else {
        $item->error($error);
    }

    return $item;
}

sub root {
    my ($self) = @_;
    return QuickBooks::Objects::Bill->new($self->OUTWOOF);
}




sub txndate_fmt {
    my $tmp = $_[0]->TxnDate;
    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub creation_date_fmt {
    my $self = shift;
    return undef unless $self->properties;
    return undef unless $self->properties->creation_date;
    my $tmp = $self->properties->creation_date;

    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub duedate_fmt {
    my $tmp = $_[0]->DueDate;
    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub totalamt_fmt {
    my $tmp = $_[0]->TotalAmt;
    use ACME::Data;
    return ACME::Data::print_amount($tmp);
}

sub subtotal_amount_fmt {
    my $self = shift;
    return ACME::Data::print_amount($self->totalamt_fmt - $self->vat_amount_fmt);
}

sub vat_amount_fmt {
    my $self = shift;
    if ($self->TxnTaxDetail && $self->TxnTaxDetail->TaxLine) {
        my $vat_amount_total = 0;
        for (@{$self->TxnTaxDetail->TaxLine}) {
            $vat_amount_total += $_->Amount;
        }
        return ACME::Data::print_amount($vat_amount_total);
    }

    return undef;
}

sub prepare_product_list {
    my ($self, $hashout, %args) = @_;
    die "Hashout is not defined in arguments" unless ref $hashout eq 'HASH';
    return undef if $self->error;

    my %used;
    my $line = $self->Line;


    for my $detail (@$line) {
        next unless $detail->DetailType eq 'ItemBasedExpenseLineDetail';
        my $extended_item_ref = $detail->ItemBasedExpenseLineDetail->ItemRef;
        next unless $extended_item_ref->extended;
        my $qty = $detail->ItemBasedExpenseLineDetail->Qty;

        my $href = $hashout->{$extended_item_ref->product_key} ||= {
            qty   => 0,
            name  => $extended_item_ref->name,
            value => $extended_item_ref->value,
            item  => $extended_item_ref->clone,
            txn_count => 0,
        };

        unless ($args{-revert}) {
            $href->{qty} += $qty;
        } else {
            $href->{qty} -= $qty;
        }
        $used{$href} = $href;
    }

    return %used ? [ values %used ] : undef;
}


sub existing_properies_hash {
    my $self = shift;
    return () if defined $self->error;
    return () unless $self->properties;
    return $self->properties->as_hash;
}

sub delivered {
    my ($self) = @_;
    return undef if defined $self->error;
    return boolean::false;
}

sub linked_bill_id {
    return undef;
}

sub populate_vat_on_lines {
    my ($self, $vat_struct) = @_;
    die "No VAT structure used on QBO\n" unless ref $vat_struct eq 'ARRAY';

    my $detail = $self->TxnTaxDetail;

    return undef unless $detail;

    my $aref = $detail->TaxLine;
    return unless $aref && @$aref;

    my @candidates;
    for my $el (@$aref) {
        my $line = $el->TaxLineDetail;
        next unless $line;

        for (@$vat_struct) {
            if ($_->{id} == $line->TaxRateRef->value) {
                if ("$_->{rate_value}" == "" . $line->TaxPercent) {
                    push @candidates, { %$_ };
                }
            }
        }
    }

    return unless @candidates;

    $self->enum_item_qty(sub {
        my ($detail, $sale, $item_ref) = @_;

        return unless $sale->TaxCodeRef;
        my $tax_code_id = $sale->TaxCodeRef->value;

        my $attached;
        for my $struct (@$vat_struct) {
            next unless $struct->{tax_code_id} eq $tax_code_id;


            my $tax = LEMA::Object::ItemRef::Tax->new(
                    tax_code_id => $tax_code_id,
                    net_amount  => $detail->Amount,
                    candidates  => \@candidates,
            );

            $item_ref->tax($tax);
        }

        ()
    });

    ()
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{txndate_fmt}        = $_[0]->txndate_fmt;
    $res->{totalamt_fmt}       = $_[0]->totalamt_fmt;
    $res->{creation_date_fmt}        = $_[0]->creation_date_fmt;
    $res->{delivered}          = $_[0]->delivered;
    $res->{has_linked_bill_id} = boolean::false;
    $res->{linked_bill_id}     = $_[0]->linked_bill_id;
    return $res;
}

1;
