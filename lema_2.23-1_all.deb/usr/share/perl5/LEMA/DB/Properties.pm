package LEMA::DB::Properties;
BEGIN { our $VERSION = 0.01; }
use LEMA::DB::Export;

package LEMA::DB::Properties::Doc;

use constant ORDER_ISSUED   => 1;
use constant ORDER_INVOICED => 20;
use constant ORDER_PACKING  => 25;
use constant ORDER_DEPARTED => 30;
use constant ORDER_ARRIVED  => 40;


package LEMA::DB::Properties::Recipient;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Try::Tiny;
use Woof;
use ACME::Data;
use ACME::Claim;
use ACME::E;

use constant TRIGGER_ANY_EVENT => 0;

use constant ADDRESS_EMAIL     => 1;
use constant ADDRESS_USERNAME  => 2;

use constant STATE_NONE        => 1;
use constant STATE_ERROR       => 2;
use constant STATE_SENT        => 3;

PUBLIC (package    => OF 'str_ne') = __PACKAGE__;
PUBLIC (version    => OF 'float')  = $LEMA::DB::Properties::VERSION;
PUBLIC (method     => OF 'str_ne') = "TO/CC";
PUBLIC (type       => OF 'int');
PUBLIC (address    => OF 'str_ne');
PUBLIC (trigger    => OF 'num');
PUBLIC (state      => OF 'num') = STATE_NONE;
PUBLIC (error      => UNDEFOK OF 'strnull') = undef;
PUBLIC (email_link => UNDEFOK OF 'strnull') = undef;
PUBLIC (triggered  => UNDEFOK OF 'boolean') = undef;

sub PRUNE();
sub PRUNE() { \&PRUNE }

sub _method_ {
    my $self = shift;
    die "Invalid notification method\n"
        unless $_[0] eq 'TO/CC' || $_[0] eq 'BCC';
    return $_[0];
}

sub validate_trigger($) {
    my $trigger = shift;
    try {
        LEMA::DB::Properties::Doc::validate_order_status($trigger);
    } catch {
        die "Invalid trigger type for recipient\n";
    };
    ()
}

sub _trigger_ {
    my ($self, $in) = @_;
    VALIDATE;
    unless ($in == TRIGGER_ANY_EVENT) {
        try {
            validate_trigger($in);
        } catch { $in = LEMA::DB::Properties::Doc::ORDER_ISSUED; }
    }
    return $in;
}

sub _type_ {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid address type\n"
        unless $in == ADDRESS_EMAIL || $in == ADDRESS_USERNAME;
    return $in;
}

sub _address_ {
    my $self = shift;
    die "Empty address\n" unless length $_[0];
    if ($self->type == ADDRESS_EMAIL) {
        die "Invalid email address\n"
            unless ACME::Data::is_valid_email $_[0];
    } else {
        die e40 O_USERS_INVALID_USERNAME
            unless $_[0] =~ /^\@(.*)$/;
        my $username = $1;
        die "Empty username\n"
            unless length $username;
        die e40 O_USERS_INVALID_USERNAME
            unless ACME::Data::is_valid_username $username;
    }

    return $_[0];
}

sub _state_ {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid recipient state\n"
        unless $in == STATE_NONE || $in == STATE_ERROR || $in == STATE_SENT;
    return $in;
}

sub _error_ {
    my ($self, $in) = @_;
    $in = undef unless length $in;

    if ($self->state != STATE_ERROR) {
        die "Recipient state is not error to set error details" if defined $in;
    }
    else {
        die "Error cannot be set when state is not error" unless defined $in;
    }
    VALIDATE;
    return $in;
}

sub is_triggered {
    my ($self, $trigger) = @_;
    return 1 if $trigger       == TRIGGER_ANY_EVENT;
    return 1 if $self->trigger == TRIGGER_ANY_EVENT;
    validate_trigger($trigger);

    if ($self->trigger == $trigger) {
        return 1;
    }
    return 0;
}

sub is_email_type {
    return $_[0]->type == ADDRESS_EMAIL ? 1 : 0;
}

sub is_username_type {
    return $_[0]->type == ADDRESS_USERNAME ? 1 : 0;
}

sub address_line_fmt {
    my $self = shift;
    return sprintf "%s|%s|%s", $self->address, $self->method, $self->trigger;
}

sub address_line_no_method_fmt {
    my $self = shift;
    return sprintf "%s|%s", $self->address, $self->trigger;
}

sub address_line_no_method_lc_fmt {
    my $self = shift;
    return lc $self->address_line_no_method_fmt;
}

sub trigger_fmt {
    my $self = shift;
    return "Any" if $self->trigger == TRIGGER_ANY_EVENT;
    return LEMA::DB::Properties::Doc::order_status_to_string($self->trigger);
}

package LEMA::DB::Properties::Recipients;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use Woof;
use ACME::Claim;
PUBLIC (package => OF 'str_ne') = __PACKAGE__;
PUBLIC (version => OF 'float')  = $LEMA::DB::Properties::VERSION;
PUBLIC (count   => OF 'int')   = 0;
PUBLIC (list    => OF 'ARRAY') = sub { [] };

sub _list_ {
    my ($self, $in) = @_;
    VALIDATE;
    if (ref $in eq 'CODE') { $in = $in->(); }

    my %uniq;
    my @new;
    for my $el (@$in) {
        next unless length $el->{address};
        if ($el->{type} == LEMA::DB::Properties::Recipient::ADDRESS_USERNAME) {
            next if $el->{address} eq '@';
        }
        my $recp = LEMA::DB::Properties::Recipient->new($el);
        if (exists $uniq{$recp->address_line_no_method_lc_fmt}) {
            next;
        }
        $uniq{$recp->address_line_no_method_lc_fmt}++;
        push @new, $recp;
    }

    $self->count(scalar @new);
    return \@new;
}

sub enum {
    my ($self, $cb) = @_;
    if ($self->count) {
        for my $el (@{$self->list}) {
            my $ret = $cb->($el);

            if ($ret eq LEMA::DB::Properties::Recipient::PRUNE) {
                last;
            }
        }
    }
    ()
}

sub get_email_to {
    my ($self, $trigger) = @_;
    my $to;

    $self->enum(sub {
        my $recp = shift;
        if ($recp->is_triggered($trigger)) {
            if ($recp->method eq 'TO/CC') {
                if ($recp->is_email_type) {
                    $to = $recp->address;
                    return $recp->PRUNE;
                } else {
                    $to = $recp->email_link;
                    return $recp->PRUNE if defined $to;
                }
            }
        }
    });

    return $to;
}

sub get_email_ccs {
    my ($self, $trigger) = @_;

    my %uniq;
    my @ccs;
    $self->enum(sub {
        my $recp = shift;
        if ($recp->is_triggered($trigger)) {
            if ($recp->method eq 'TO/CC') {
                if ($recp->is_email_type) {
                    my $to = $recp->address;
                    push @ccs, $to unless exists $uniq{$to};
                    $uniq{$to}++;
                } else {
                    my $to = $recp->email_link;
                    if (defined $to) {
                        push @ccs, $to unless exists $uniq{$to};
                        $uniq{$to}++;
                    }
                }
            }
        }
    });

    return @ccs ? \@ccs : undef;
}

sub get_email_bccs {
    my ($self, $trigger) = @_;

    my %uniq;
    my @bccs;
    $self->enum(sub {
        my $recp = shift;
        if ($recp->is_triggered($trigger)) {
            if ($recp->method eq 'BCC') {
                if ($recp->is_email_type) {
                    my $to = $recp->address;
                    push @bccs, $to unless exists $uniq{$to};
                    $uniq{$to}++;
                } else {
                    my $to = $recp->email_link;
                    if (defined $to) {
                        push @bccs, $to unless exists $uniq{$to};
                        $uniq{$to}++;
                    }
                }
            }
        }
    });

    return @bccs ? \@bccs : undef;
}

sub addresses_line_fmt {
    my $self = shift;
    my $line;
    for (@{$self->list}) {
        $line .= "," if length $line;
        $line .= $_->address_line_fmt;
    }
    return $line;
}

sub any_to {
    my $self = shift;
    my $to   = $self->get_email_to(LEMA::DB::Properties::Recipient::TRIGGER_ANY_EVENT);

    unless (defined $to) {
        my $bccs;
        $bccs = $self->get_email_bccs(LEMA::DB::Properties::Recipient::TRIGGER_ANY_EVENT);
        if (defined $bccs) {
            $to = $bccs->[0];
        }
    }

    return $to;
}

sub any_bcc_comma_sep {
    my $self = shift;

    my $to = $self->any_to;
    return undef unless $to;

    my $bccs_1 = $self->get_email_bccs(LEMA::DB::Properties::Recipient::TRIGGER_ANY_EVENT);
    my %uniq;
    my @bccs;

    for (@$bccs_1) {
        next if exists $uniq{$_} || $_ eq $to;
        $uniq{$_}++;
        push @bccs, $_;
    }

    return undef unless @bccs;
    return join ', ', @bccs;
}

sub any_cc_comma_sep {
    my $self = shift;

    my $to = $self->any_to;
    return undef unless $to;

    my $bccs_comma = $self->any_bcc_comma_sep;
    my $bccs;
    if (length $bccs_comma) {
        $bccs = [ split(/\s*,\s*/, $bccs_comma) ];
    }

    my %ignore;
    if ($bccs) {
        $ignore{$_}++ for @$bccs;
    }

    my $ccs_1 = $self->get_email_ccs(LEMA::DB::Properties::Recipient::TRIGGER_ANY_EVENT);
    my %uniq;
    my @ccs;

    for (@$ccs_1) {
        next if exists $uniq{$_} || $_ eq $to || exists $ignore{$_};
        $uniq{$_}++;
        push @ccs, $_;
    }

    return undef unless @ccs;
    return join ', ', @ccs;
}


package LEMA::DB::Properties::Doc;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use ACME::Claim;
use Woof;
use constant TYPE_PURCHASE_ORDER => 1;
use constant TYPE_INVOICE        => 2;
use constant TYPE_ADJUST         => 3;
use constant DELIVERY_LOCAL      => 1;
use constant DELIVERY_OVERSEAS   => 2;
use constant DELIVERY_EU         => 3;

PUBLIC (_id         => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (doc_number  => OF 'int');
PUBLIC (doc_type    => OF 'int');
PUBLIC (doc_sub     => UNDEFOK OF 'int') = undef;
PUBLIC (updated_on  => OF 'float');
PUBLIC (partner_id  => OF 'int');
PUBLIC (revision    => OF 'int');



PUBLIC (creation_date  => UNDEFOK OF 'strnull') = undef;
PUBLIC (arrival_date   => UNDEFOK OF 'strnull') = undef;
PUBLIC (departure_date => UNDEFOK OF 'strnull') = undef;
PUBLIC (vat_number     => UNDEFOK OF 'strnull') = undef;
PUBLIC (eori           => UNDEFOK OF 'strnull') = undef;
PUBLIC (remarks        => UNDEFOK OF 'strnull') = undef;
PUBLIC (status         => UNDEFOK OF 'int')     = undef;
PUBLIC (sale_cond      => UNDEFOK OF 'strnull') = undef;
PUBLIC (delivery_type  => UNDEFOK OF 'int')     = undef;
PUBLIC (bank_account   => UNDEFOK OF 'strnull') = undef;
PUBLIC (extra_addr     => UNDEFOK OF 'QuickBooks::Objects::Addr') = undef;
PUBLIC (username       => UNDEFOK OF 'strnull') = undef;
PUBLIC (recipients_e   => UNDEFOK OF 'LEMA::DB::Properties::Recipients') = undef;
PUBLIC (recipients_u   => UNDEFOK OF 'LEMA::DB::Properties::Recipients') = undef;
PUBLIC (euro_pallets   => UNDEFOK OF 'strnull') = undef;
PUBLIC (block_pallets  => UNDEFOK OF 'strnull') = undef;
PUBLIC (export         => UNDEFOK OF 'LEMA::DB::Properties::Export') = undef;

sub order_status_to_string($) {
    return "Rolling (Issued)"
        if $_[0] == LEMA::DB::Properties::Doc::ORDER_ISSUED;
    return "Rolling (Invoiced)"
        if $_[0] == LEMA::DB::Properties::Doc::ORDER_INVOICED;
    return "Rolling (Packing)"
        if $_[0] == LEMA::DB::Properties::Doc::ORDER_PACKING;
    return "Rolling (Departed)"
        if $_[0] == LEMA::DB::Properties::Doc::ORDER_DEPARTED;
    return "Delivered"
        if $_[0] == LEMA::DB::Properties::Doc::ORDER_ARRIVED;
    die "Invalid order type\n";
}

sub validate_order_status($) {
    die "Invalid order status\n"
        unless $_[0] == LEMA::DB::Properties::Doc::ORDER_ISSUED   ||
               $_[0] == LEMA::DB::Properties::Doc::ORDER_INVOICED ||
               $_[0] == LEMA::DB::Properties::Doc::ORDER_DEPARTED ||
               $_[0] == LEMA::DB::Properties::Doc::ORDER_ARRIVED  ||
               $_[0] == LEMA::DB::Properties::Doc::ORDER_PACKING;
    ()
}

sub as_hash {
    my $self = shift;
    my $reserved;
    my $extra_addr = $self->extra_addr;
    if ($extra_addr) {
        $reserved   = $extra_addr->{reserved};
        $extra_addr = $self->extra_addr->OUTWOOF;
        if ($reserved) {
            $extra_addr->{reserved} = $reserved;
        }
    }

    return (
        doc_sub        => $self->doc_sub,
        creation_date  => $self->creation_date,
        arrival_date   => $self->arrival_date,
        departure_date => $self->departure_date,
        vat_number     => $self->vat_number,
        eori           => $self->eori,
        remarks        => $self->remarks,
        status         => $self->status,
        status_fmt     => $self->status_fmt,
        sale_cond      => $self->sale_cond,
        delivery_type  => $self->delivery_type,
        bank_account   => $self->bank_account,
        extra_addr     => $extra_addr,
        recipients_e   => $self->recipients_e ? $self->recipients_e->OUTWOOF : undef,
        recipients_u   => $self->recipients_u ? $self->recipients_u->OUTWOOF : undef,
        euro_pallets   => $self->euro_pallets,
        block_pallets  => $self->block_pallets,
        export         => $self->export,
    );
}


sub _partner_id_ {
    my ($self, $in) = @_;
    VALIDATE;
    die "Partner/contragent ID must be greater than 0\n"
        unless $in > 0;
    return $in;
}

sub _doc_number {
    my ($self, $in) = @_;
    VALIDATE;
    LEMA::check_id($in);
    return $in;
}

sub _doc_type {
    my ($self, $in) = @_;
    VALIDATE;
    die "Invalid document type for properies\n"
        unless $in == TYPE_PURCHASE_ORDER ||
               $in == TYPE_INVOICE ||
               $in == TYPE_ADJUST;
    return $in;
}


sub _departure_date {
    my ($self, $in) = @_;
    $in = undef unless length $in;
    if (defined $in) {
        $in =~ s!\D!!g;
        die "Invalid departure date\n"
            unless length $in == 8;
        $in =~ m!^(\d{4})(\d{2})(\d{2})$!;
        return "$1-$2-$3";
    }
    return undef;
}

sub _arrival_date {
    my ($self, $in) = @_;
    $in = undef unless length $in;
    if (defined $in) {
        $in =~ s!\D!!g;
        die "Invalid departure date\n"
            unless length $in == 8;
        $in =~ m!^(\d{4})(\d{2})(\d{2})$!;
        return "$1-$2-$3";
    }
    return undef;
}

sub _creation_date {
    my ($self, $in) = @_;
    $in = undef unless length $in;
    if (defined $in) {
        $in =~ s!\D!!g;
        die "Invalid document date\n"
            unless length $in == 8;
        $in =~ m!^(\d{4})(\d{2})(\d{2})$!;
        return "$1-$2-$3";
    }
    return undef;
}

sub _status_ {
    my $self = shift;
    VALIDATE;
    if (defined $_[0]) {
        return ORDER_ISSUED
            unless $_[0] == ORDER_ISSUED   ||
                   $_[0] == ORDER_INVOICED ||
                   $_[0] == ORDER_DEPARTED ||
                   $_[0] == ORDER_ARRIVED  ||
                   $_[0] == ORDER_PACKING;
    } else {
        return ORDER_ISSUED;
    }
    return $_[0];
}

sub _revision_ {
    my $self = shift;
    VALIDATE;
    die "Revision number must be greater than 0\n"
        unless $_[0] >= 1;
    return $_[0];
}

sub _sale_cond_ {
    my ($self, $in) = @_;
    return undef unless length $in;
    die "Invalid sale condition\n" unless $in =~ /^(EXW|DDP|DAP)$/;
    return $in;
}

sub _delivery_type_ {
    my ($self, $in) = @_;
    return undef unless length $in;
    if ($in == DELIVERY_LOCAL) {
        $in = DELIVERY_EU;
    }
    unless (#$in == DELIVERY_LOCAL ||
            $in == DELIVERY_OVERSEAS ||
            $in == DELIVERY_EU) {
        die "Invalid delivery type\n";
    }
    VALIDATE;
    return $in;
}

sub is_overseas { $_[0]->delivery_type == DELIVERY_OVERSEAS }

sub _export_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    unless ($self->doc_type == TYPE_INVOICE) {
        die "Export is allowed only for order confirmations\n";
    }
    return $in;
}

sub _extra_addr_ {
    my ($self, $in) = @_;
    return undef unless defined $in;
    my $addr = QuickBooks::Objects::Addr->new_mod($in);
    return $addr;
}

sub creation_date_fmt {
    my $tmp = $_[0]->creation_date;
    if ($tmp =~ m!^(\d{4})-(\d{2})-(\d{2})$!) {
        return "$3/$2/$1";
    }
    return undef;
}

sub departure_date_fmt {
    my $self = shift;
    my $date = $self->departure_date;
    if (defined $date) {
        $date =~ m!^(\d{4})\D?(\d{2})\D?(\d{2})$!;
        return "$3/$2/$1";
    }
    return undef;
}

sub arrival_date_fmt {
    my $self = shift;
    my $date = $self->arrival_date;
    if (defined $date) {
        $date =~ m!^(\d{4})\D?(\d{2})\D?(\d{2})$!;
        return "$3/$2/$1";
    }
    return undef;
}

sub doc_type_fmt {
    my $self = shift;
    my $type = $self->doc_type;
    if ($type == TYPE_INVOICE) {
        return "Order Confirmation";
    } elsif ($type == TYPE_PURCHASE_ORDER) {
        return "Purchase Order";
    } elsif ($type == TYPE_ADJUST) {
        return "Stock Adjust";
    } else {
        return "Unknown";
    }
}

sub updated_on_fmt {
    my $self = shift;
    return ACME::Data::localtime_tz($self->updated_on);
}

sub doc_number_year {
    my ($self) = @_;
    die "Disabled";
    $self->doc_number =~ m!^(\d+)\-\d+$!;
    my $year = $1;
    claim { $year > 0 };
    return $year;
}

sub doc_number_number {
    my ($self) = @_;
    die "Disabled";
    $self->doc_number =~ m!^\d+\-(\d+)$!;
    my $number = $1;
    claim { $number > 0 };
    return $number;
}

sub is_delivered {
    my ($self) = @_;
    return $self->status == ORDER_ARRIVED ? 1 : 0;
}

sub status_fmt {
    my $self = shift;
    return order_status_to_string($self->status);
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{doc_type_fmt}       = $_[0]->doc_type_fmt;
    $res->{updated_on_fmt}     = $_[0]->updated_on_fmt;
    $res->{departure_date_fmt} = $_[0]->departure_date_fmt;
    $res->{arrival_date_fmt}   = $_[0]->arrival_date_fmt;
    return $res;
}

package LEMA::DB::Properties;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::Claim;
use ACME::E;
use parent qw(LEMA::DB::base);

our $TABLE = 'properties' . $LEMA::DB::TABLE_NAME_POSTFIX;

sub initialize {
    my ($self) = @_;
    my $table = $self->table;
    my $coll  = $self->coll;

    my $indexes = $coll->indexes;
    $indexes->create_one([ doc_type => 1, doc_number => 1,
                         ],
                        { unique => 1});

    $indexes->create_one([ doc_type => 1, customer_id => 1 ]);
    ()
}

sub create {
    my ($self, $inv_or_bill, %props) = @_;
    my $properties;

    if ($inv_or_bill->$_isa('LEMA::Object::Invoice')) {
        my $inv = $inv_or_bill;
        die "Invoice is not supported by LEMA SMAPP: " . $inv->error
            if defined $inv->error;

        my %existing_props = $inv->existing_properies_hash;


        my $new_export = LEMA::DB::Properties::Export->new_from_invoice($inv);

        my $old_export = delete $props{old_export};
        if ($old_export->$_isa('LEMA::DB::Properties::Export')) {
        } else {
            die "Old export must be object" if defined $old_export;
        }

        my $update_export = delete $props{export};
        LEMA::check_id($inv->Id);

        $properties = LEMA::DB::Properties::Doc->new({
            export      => undef,
            %existing_props,
            revision    => 1,
            %props,

            updated_on  => AE::time,
            doc_type    => LEMA::DB::Properties::Doc::TYPE_INVOICE,
            doc_number  => $inv->Id,
            partner_id  => $inv->CustomerRef->value,
        });

        if ($properties->is_overseas) {
            $properties->export($old_export || $new_export);

            if ($old_export) {
                $properties->export->merge($new_export);
            }

            if ($update_export) {
                $properties->export->update($update_export);
            }

            $properties->export->activate_lines($inv);
        }
    }
    elsif ($inv_or_bill->$_isa('LEMA::Object::Bill')) {
        my $bill = $inv_or_bill;
        die "Purchase order is not supported by LEMA SMAPP: " . $bill->error
            if defined $bill->error;

        LEMA::check_id($bill->Id);
        $properties = LEMA::DB::Properties::Doc->new({
            doc_type   => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
            doc_number => $bill->Id,
            partner_id => $bill->VendorRef->value,
            $bill->existing_properies_hash,
            revision   => 1,
            %props,
            updated_on => AE::time,
        });
    }
    else {
        claim { 0 };
    }

    return $properties;
}



sub get_last_recipients_for_invoice {
    my ($self, $partner_id, $partner_sub_id) = @_;

    $partner_id += 0;
    die "Invalid partner ID\n"
        if $partner_id != 0 && $partner_id < 0;

    $partner_sub_id += 0;
    die "Invalid partner sub ID\n"
        if $partner_sub_id != 0 && $partner_sub_id < 0;

    $partner_sub_id = 0 unless $partner_id;

    my @docs = $self->coll->find({
        doc_type => LEMA::DB::Properties::Doc::TYPE_INVOICE,
        $partner_id     == 0 ? () : (partner_id => $partner_id),
        $partner_sub_id == 0 ? () : (doc_sub    => $partner_sub_id),
    })->sort({ doc_number => -1,
               updated_on => -1 })->limit(1)->all;

    unless (@docs && $partner_sub_id != 0) {
        @docs = $self->coll->find({
                doc_type => LEMA::DB::Properties::Doc::TYPE_INVOICE,
                $partner_id == 0 ? () : (partner_id => $partner_id),
            })->sort({ doc_number => -1,
                       updated_on => -1 })->limit(1)->all;
    }

    if (@docs) {
        my $doc = LEMA::DB::Properties::Doc->new($docs[0]);
        return [ $doc->recipients_e, $doc->recipients_u ];
    }

    return undef;
}

sub get_last_recipients_for_purchase_order {
    my ($self, $partner_id) = @_;
    $partner_id += 0;
    unless ($partner_id == 0) {
        die "Invalid partner ID\n" unless $partner_id > 0;
    }

    my @docs = $self->coll->find({
        doc_type   => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
        $partner_id == 0 ? () : (partner_id => $partner_id),
    })->sort({ doc_number => -1,
               updated_on => -1 })->limit(1)->all;

    if (@docs) {
        my $doc = LEMA::DB::Properties::Doc->new($docs[0]);
        return [ $doc->recipients_e, $doc->recipients_u ];
    }

    return undef;
}

sub populate_bill {
    my ($self, $po) = @_;
    die "Invalid PO object"
        unless $po->$_isa('LEMA::Object::PurchaseOrder') ||
               $po->$_isa('LEMA::Object::Bill');
    die "PO is not supported by LEMA SMAPP: " . $po->error
        if defined $po->error;

    LEMA::check_id($po->Id);

    my @docs = $self->coll->find({
        doc_type   => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
        doc_number => $po->Id,
    })->all;

    my $doc;
    if (@docs) {
        $doc = LEMA::DB::Properties::Doc->new($docs[0]);
    } else {
        $doc = LEMA::DB::Properties::Doc->new({
            doc_type   => LEMA::DB::Properties::Doc::TYPE_INVOICE,
            doc_number => $po->Id,
            partner_id => $po->VendorRef->value,
            revision   => 1,
            status     => LEMA::DB::Properties::Doc::ORDER_ISSUED,
            updated_on => AE::time,
        });
    }

    $po->properties($doc);
    ()
}

=head1
sub find_purchase_order {
    my ($self, $po) = @_;
    die "Invalid PO object"
        unless $po->$_isa('LEMA::Object::PurchaseOrder') ||
               $po->$_isa('LEMA::Object::Bill');
    die "PO is not supported by LEMA SMAPP: " . $po->error
        if defined $po->error;

    my @docs = $self->coll->find({
        doc_type   => LEMA::DB::Properties::Doc::TYPE_PURCHASE_ORDER,
        doc_number => $po->DocNumber,
    })->all;

    my $doc;
    if (@docs) {
        $doc = LEMA::DB::Properties::Doc->new($docs[0]);
    } else {
        $doc = LEMA::DB::Properties::Doc->new({
            doc_type   => LEMA::DB::Properties::Doc::TYPE_INVOICE,
            doc_number => $po->DocNumber,
            state_id   => $po->lema_state_id,
            partner_id => $po->VendorRef->value,
            revision   => 1,
            status     => LEMA::DB::Properties::Doc::ORDER_ISSUED,
            updated_on => AE::time,
        });
    }

    $po->properties($doc);
    ()
}
=cut

sub upsert {
    my ($self, $properties) = @_;
    die "Invalid properties object"
        unless $properties->$_isa('LEMA::DB::Properties::Doc');

    my $reserved;
    if ($properties->extra_addr) {
        $reserved = $properties->extra_addr->{reserved};
    }

    my $hash = $properties->OUTWOOF;
    delete $hash->{_id};
    delete $hash->{doc_type};
    delete $hash->{doc_number};
    if ($reserved) {
        $hash->{extra_addr}{reserved} = $reserved;
    }

    $self->coll->update_one(
        { doc_type   => $properties->doc_type,
          doc_number => $properties->doc_number,
        },
        { '$set'         => $hash,
        },
        { upsert => 1 },
    );
    ()
}

sub upsert_invoice {
    my ($self, $inv, %props) = @_;
    my $properties = $self->create($inv, %props);
    $self->upsert($properties);
    $inv->properties($properties);

    if (my $e = $inv->properties->recipients_e) {
    }
    ()
}

sub upsert_bill {
    my ($self, $bill, %props) = @_;
    my $properties = $self->create($bill, %props);
    $self->upsert($properties);
    $bill->properties($properties);
    ()
}

sub populate_invoice {
    my ($self, $po) = @_;
    die "Invalid invoice object"
        unless $po->$_isa('LEMA::Object::Invoice');
    die "Invoice is not supported by LEMA SMAPP: " . $po->error
        if defined $po->error;

    LEMA::check_id($po->Id);

    my @docs = $self->coll->find({
        doc_type   => LEMA::DB::Properties::Doc::TYPE_INVOICE,
        doc_number => $po->Id,
    })->all;

    my $doc;
    if (@docs) {
        $doc = LEMA::DB::Properties::Doc->new($docs[0]);


    } else {
        $doc = LEMA::DB::Properties::Doc->new({
            doc_type   => LEMA::DB::Properties::Doc::TYPE_INVOICE,
            doc_number => $po->Id,
            status     => LEMA::DB::Properties::Doc::ORDER_ISSUED,
            partner_id => $po->CustomerRef->value,
            revision   => 1,
            updated_on => AE::time,
        });
    }

    $po->properties($doc);
    ()
}

1;
