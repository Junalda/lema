package LEMA::DB::Settings;

package LEMA::DB::Settings::Inventory;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use AnyEvent;
use ACME::Object::Users;
use ACME::Object::SMTP;
use QuickBooks::Objects::Credentials;
use Woof;
PUBLIC (income_account => OF 'int');
PUBLIC (expense_account => OF 'int');
PUBLIC (asset_account => OF 'int');

sub _income_account_ {
    my $self = shift;
    die "No income account\n" unless length $_[0];
    die "Invalid income account\n" unless $_[0] =~ /^\d+$/;
    return int $_[0];
}

sub _expense_account_ {
    my $self = shift;
    die "No expense account\n" unless length $_[0];
    die "Invalid expense account\n" unless $_[0] =~ /^\d+$/;
    return int $_[0];
}

sub _asset_account_ {
    my $self = shift;
    die "No asset account\n" unless length $_[0];
    die "Invalid asset account\n" unless $_[0] =~ /^\d+$/;
    return int $_[0];
}

package LEMA::DB::Settings::Profile::Doc;
use common::sense;
use boolean;
use Data::Dumper;
use BSON::OID;
use Safe::Isa;
use AnyEvent;
use ACME::Object::Users;
use ACME::Object::SMTP;
use QuickBooks::Objects::Credentials;
use Woof;
PUBLIC (_id         => OF 'BSON::OID') = sub { BSON::OID->new };
PUBLIC (removed     => OF 'boolean')   = sub { boolean::false };
PUBLIC (active_     => OF 'boolean')   = sub { boolean::false };
PUBLIC (index       => OF 'int');
PUBLIC (qbo         => UNDEFOK OF 'QuickBooks::Objects::Credentials') = undef;
PUBLIC (users       => OF 'ACME::Object::Users');
PUBLIC (smtp        => UNDEFOK OF 'ACME::Object::SMTP') = undef;
PUBLIC (inventory   => UNDEFOK OF 'LEMA::DB::Settings::Inventory') = undef;
PUBLIC (dd_inventory => UNDEFOK OF 'LEMA::DB::Settings::Inventory') = undef;
PUBLIC (created_on  => OF 'float') = sub { AE::time };
PUBLIC (updated_on  => OF 'float') = sub { AE::time };

sub _index_ {
    my $self = shift;
    VALIDATE;
    die "Profile index cannot be negative"
        unless $_[0] >= 0;
    return $_[0];
}

sub _qbo_ {
    my $self = shift;
    VALIDATE;
    return undef unless defined $_[0];

    die "No company name provided by caller"
        unless defined $_[0]->company_name;

    return $_[0];
}

sub created_on_fmt {
    return ACME::Data::localtime_tz($_[0]->created_on);
}

sub updated_on_fmt {
    return ACME::Data::localtime_tz($_[0]->updated_on);
}

sub TO_JSON {
    my $res = Woof::_Blesser::TO_JSON @_;
    $res->{created_on_fmt}     = $_[0]->created_on_fmt;
    $res->{updated_on_fmt}     = $_[0]->updated_on_fmt;
    return $res;
}

package LEMA::DB::Settings;
use common::sense;
use Carp;
use AnyEvent::Log;
use Try::Tiny;
use Data::Dumper;
use Safe::Isa;
use JSON::XS;
use LEMA;
use LEMA::Object::ID;
use ACME::E;
use ACME::Claim;
use parent qw(LEMA::DB::base);

our $TABLE            = 'settings' . $LEMA::DB::TABLE_NAME_POSTFIX;
our $DEFAULT_USERNAME = "lema";
our $DEFAULT_PASSWORD = "password";

sub initialize {
    my ($self) = @_;

    my $indexes = $self->coll->indexes;
    $indexes->create_one([ index => 1 ], { unique => 1});

    my $profile;
    my $activate_profile = undef;
    my $doc              = $self->coll->find_one({ global => boolean::true });

    unless ($doc) {
        AE::log info => "No profile to use is specified in the database";
        $profile = $self->find_profile_by_index(0);
        unless ($profile) {
            AE::log info => "Create profile No. 0...";
            $profile = $self->new_profile_object_with_index(0);
            $self->upsert_profile($profile);
        } else {
            if ($profile->removed) {
                die "Profile No. 0 is marked as removed\n";
            }
            AE::log info => "Profile No. 0 is found, but it's not activated...";
        }

        $activate_profile = 0;
    }
    else {
        my $active_profile_index = $doc->{profile_index};
        unless (defined $active_profile_index) {
            AE::log info => "Profile to use is not defined in the database";

            $profile = $self->find_profile_by_index(0);
            unless ($profile) {
                AE::log info => "Create profile No. 0...";
                $profile = $self->new_profile_object_index(0);
                $self->upsert_profile($profile);
            } else {
                if ($profile->removed) {
                    die "Profile No. 0 is marked as removed\n";
                }
                AE::log info => "Profile No. 0 is found...";
            }

            $activate_profile = 0;
        }
        else {
            AE::log info => "Profile to use is specified in the database: %d",
                            $active_profile_index;

            $profile = $self->find_profile_by_index($active_profile_index);
            unless ($profile) {
                $profile = $self->new_profile_object_index(0);
                $self->upsert_profile($profile);
                $activate_profile = 0;
            }
            else {
                if ($profile->removed) {
                    die sprintf "Profile No. %d is marked as removed\n",
                                $profile->index;
                }
                AE::log info => "Profile No. %d is activated and found",
                                $active_profile_index;
            }
        }
    }

    claim { defined $profile };

    if (defined $activate_profile) {
        $self->activate_profile_by_index($activate_profile);
    } else {
        $self->{_active_profile} = $profile;
        $profile->active_(1);
    }

    ()
}

sub active_profile {
    my $self = shift;
    claim { !!$self->{_active_profile} };
    return $self->{_active_profile};
}

sub activate_profile_by_index {
    my ($self, $profile_index) = @_;
    die "Invalid profile index" unless $profile_index =~ /^\d+$/;
    $profile_index = int $profile_index;

    AE::log info => "Activate profile No. %d...", $profile_index;

    die "Profile is already activated\n"
        if $self->{_active_profile} &&
           $self->active_profile->index == $profile_index;

    my $profile = $self->find_profile_by_index($profile_index);
    die sprintf "Profile No. %d to activate is not found\n", $profile_index
        unless $profile;

    $self->coll->update_one(
        { global => boolean::true, },
        { '$set' => { profile_index => $profile_index,
                      index         => undef,
                      updated_on    => AE::time } },
        { upsert => 1 },
    );

    $self->{_active_profile} = $profile;
    $profile->active_(1);

    ()
}

sub new_profile_object_with_index {
    my ($self, $profile_index) = @_;
    my $default_user = { username => $DEFAULT_USERNAME,
                         password => $DEFAULT_PASSWORD,
                         role     => ACME::Object::User::ROLE_ADMINISTRATOR };
    return LEMA::DB::Settings::Profile::Doc->new({
            index      => $profile_index,
            users      => ACME::Object::Users->new(list => [ $default_user ]),
    });
}

sub upsert_profile {
    my ($self, $doc) = @_;
    die "Invalid settings object"
        unless $doc->$_isa('LEMA::DB::Settings::Profile::Doc');

    my $hash = $doc->OUTWOOF;
    delete $hash->{_id};
    delete $hash->{index};
    $hash->{updated_on} = AE::time;

    $self->coll->update_one(
        { index => $doc->index, },
        { '$set' => $hash },
        { upsert => 1 },
    );

    $doc->updated_on($hash->{updated_on});
    ()
}

sub insert_profile {
    my ($self, $doc) = @_;
    die "Invalid settings object"
        unless $doc->$_isa('LEMA::DB::Settings::Profile::Doc');

    my $hash = $doc->OUTWOOF;

    my $res = $self->coll->insert_one($hash);

    die "Couldn't insert new profile into database\n"
        unless $res->$_isa('MongoDB::InsertOneResult') &&
               $res->inserted_id;
    ()
}

sub find_profile_by_index {
    my ($self, $profile_index) = @_;
    die "Invalid profile index" unless $profile_index =~ /^\d+$/;
    $profile_index = int $profile_index;

    my @docs = $self->coll->find({
        index => $profile_index,
    })->all;

    my $doc;
    if (@docs) {
        $doc = shift @docs;
        $doc = LEMA::DB::Settings::Profile::Doc->new($doc);
    } else {
        return undef;
    }

    return $doc;
}

sub upsert_active_profile {
    my ($self) = @_;
    $self->upsert_profile($self->active_profile);
    ()
}

sub find_all_profiles {
    my ($self, %args) = @_;
    my $active_profile = $self->active_profile;

    my @docs = $self->coll->find({ index => { '$ne' => undef } })
                          ->sort({ index => 1 })
                          ->all;
    claim { !!@docs };

    my @res;
    for (@docs) {
        my $doc = LEMA::DB::Settings::Profile::Doc->new($_);

        unless ($args{-include_removed}) {
            next if $doc->removed;
        }

        $doc->active_(0);
        if ($active_profile->index == $doc->index) {
            $doc->active_(1);
        }

        push @res, $doc;
    }

    return \@res;
}

sub get_next_free_profile_index {
    my ($self) = @_;
    my @docs = $self->coll->find({ index => { '$ne' => undef } })
                          ->sort({ index => -1 })
                          ->limit(1)
                          ->all;
    claim { @docs == 1 };
    my $doc = LEMA::DB::Settings::Profile::Doc->new($docs[0]);
    return $doc->index + 1;
}

sub remove_profile_by_index {
    my ($self, $profile_index) = @_;
    die "Invalid profile index" unless $profile_index =~ /^\d+$/;
    $profile_index = int $profile_index;

    die "Unable to remove active profile\n"
        if $self->active_profile->index == $profile_index;

    my $res = $self->coll->update_one(
        { index  => $profile_index, },
        { '$set' => { removed    => boolean::true,
                      updated_on => AE::time } },
    );

    die "Couldn't remove profile\n"
        unless $res->$_isa('MongoDB::UpdateResult');
    die "Profile with index $profile_index is not found\n"
        unless $res->matched_count;
    ()
}

sub update_qbo_by_index {
    my ($self, $profile_index, $qbo) = @_;
    die "Invalid profile index"
        unless $profile_index =~ /^\d+$/;
    die "Invalid QBO creds objects"
        unless $qbo->$_isa('QuickBooks::Objects::Credentials');

    my $hash = $qbo->OUTWOOF;

    my $res = $self->coll->update_one(
        { index  => $profile_index, },
        { '$set' => { qbo        => $hash,
                      updated_on => AE::time } },
    );

    die "Couldn't remove profile\n"
        unless $res->$_isa('MongoDB::UpdateResult');
    die "Profile with index $profile_index is not found\n"
        unless $res->matched_count;
    ()
}

1;
