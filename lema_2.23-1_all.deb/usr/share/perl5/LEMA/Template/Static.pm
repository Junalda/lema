package LEMA::Template::Static;
use strict;
use warnings;
use Scalar::Util;
use Carp;
use parent qw(LEMA::Template::Tiny);

sub process_static {
    my $self  = shift;
    my $file  = shift;
    my $stash = shift;
    my $data  = LEMA::Static::find_html5($file);

    Carp::croak "No static file found `$file'"
        unless defined $data;

    if (Scalar::Util::blessed($stash)) {
        my %stash = %$stash;
        $stash = \%stash;
    }

    return $self->process(\$data, $stash, @_);
}

1;
