package LEMA::Web::Notifications;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use AnyEvent;
use AnyEvent::Tools;
use Email::MIME;
use LEMA::Util::PDF;
use ACME::Claim;
use ACME::AnyEvent::SMTP;
use ACME::AnyEvent::SMTP::Client;
use ACME::E
    NOTIFICATION_NO_SMTP => [ 3580, "No SMTP server details provided in the settings" ],
;

our $SINGLETON;
our $INTERVAL = 2 * 60;

sub new {
    my ($class, %args) = @_;

    die "No config" unless $args{-config}->$_isa('LEMA::Config');

    AE::log fatal => "Invalid app object"
        unless $args{-app}->$_isa('LEMA::App');

    my $self = bless \%args, $class;

    AE::log info => "Start notification watcher...";
    $self->_run_shipment_watcher(undef)
        unless $ENV{LEMA_NO_EMAILING};

    return $SINGLETON = bless $self, $class;
}

sub app      { $_[0]{-app}     }
sub config   { $_[0]{-config}  }

sub singleton {
    my ($class) = @_;
    die "No config singleton" unless $SINGLETON;
    return $SINGLETON;
}

sub _run_shipment_watcher {
    my ($self, $delay) = @_;
    $delay //= 16;

    my $w = AE::timer $delay, 0, sub {

        my $cb = sub {
            AE::log debug => "Setup next notification watcher...";
            my $now       = AE::time + 1;
            my $new_delay = ($INTERVAL - ($now % $INTERVAL));


            $self->{_w} = undef;
            AE::log debug => "Next notification watcher will be called in %s seconds", $new_delay;
            $self->_run_shipment_watcher($new_delay);
            ()
        };

        if ($self->{_async_for_w}) {
            AE::log debug => "One notification sender is still working";
            $cb->();
        }

        try {
            $self->_shipment_watcher($cb);
        } catch {
            if (is_e && $_ == NOTIFICATION_NO_SMTP) {
                AE::log debug => "%s", $_;
            } else {
                AE::log error => "Error in shipment watcher: %s", $_;
            }
            $cb->();
        };

        ()
    };

    $self->{_w} = $w;
    ()
}

sub _shipment_watcher {
    my ($self, $cb) = @_;
    my @messages;


    my $docs = $self->app->db->notifications->fetch_notifications_to_send;

    unless (@$docs) {
        AE::log debug => "No new notifications to send";
        $cb->();
        return;
    }

    my %group;
    for my $notification (@$docs) {
        my $key  = $notification->make_key;
        my $aref = $group{$key} ||= [];

        if (@$aref) {
            my $prev_notification = $aref->[-1];
            if ($notification->trigger <= $prev_notification->trigger) {
                for (@$aref) {

                    $_->error("Emailing is cancelled due to changes in notification queue.");
                    $_->success(0);
                    $self->app->db->notifications->update_process($_);
                }

                @$aref = ();
            }
        }

        push @$aref, $notification;
    }
    undef %group;

    my @effective;
    for my $notification (@$docs) {
        if (defined $notification->success) {
            next;
        }

        unless ($notification->has_recipients) {
            $notification->success(1);
            $self->app->db->notifications->update_process($notification);
            next;
        }


        my $files = $notification->files;
        if ($files->count) {
            my $updated = 0;

            AE::log debug => "Create PDF if needed";
            $files->enum(sub {
                my ($file) = @_;
                if ($file->type eq 'text/html') {
                    AE::log debug => "Convert file to PDF";
                    my $pdf_bin = LEMA::Util::PDF::generate($file->octets);
                    $_[0] = LEMA::DB::Notifications::File->new({
                        octets  => $pdf_bin,
                        is_utf8 => 0,
                        type    => 'application/pdf',
                        name    => $file->name,
                    });
                    $updated = 1;
                    ()
                }
                elsif ($file->type eq 'application/pdf') {
                    AE::log debug => "PDF is already created";
                }
                else {
                    AE::log debug => "File is not in format to convert in PDF";
                }
            });

            if ($updated) {
                AE::log debug => "Update files converted to PDF (success flag is %s)",
                                 $notification->success // '<undef>';
                $self->app->db->notifications->update_files($notification)
            }
        }

        push @effective, $notification;
    }




    unless (@effective) {
        AE::log debug => "No new notifications to send after checking";
        $cb->();
        return;
    }

    my $smtp = $self->app->db->settings->active_profile->smtp;
    die e40 NOTIFICATION_NO_SMTP unless $smtp;

    $self->_send_all($smtp, \@effective, $cb);
    ()
}

sub _send_all {
    my ($self, $smtp, $docs, $cb) = @_;
    die "Invalid array with notifications to send" unless ref $docs eq 'ARRAY';

    $self->{_async_for_w} = AnyEvent::Tools::async_foreach
            $docs, sub {

        my ($guard, $notification, $index, $first_flag, $last_flag) = @_;
        my $sendmail_w;

        my $cb_inner = sub {
            my ($ok, $err) = @_;
            undef $sendmail_w;

            try {
                if ($err) {
                    $ok = 0;
                    $notification->error($err);
                    AE::log error => "Failed to send email: %s", $err;
                    $notification->success(undef);
                }
                if ($ok) {
                    $notification->error(undef);
                    $notification->success(1);
                }

                $self->app->db->notifications->update_process($notification);
            } catch {
                AE::log error => "%s", $_;
            };

            undef $guard;
            ()
        };

        try {
            $sendmail_w = $self->_sendmail($smtp, $notification, $cb_inner);
        } catch {
            AE::log error => "Exception: %s", $_;
            $cb_inner->(undef, $_);
        };
        ()
    },
    sub {
        $self->{_async_for_w} = undef;

        $cb->();
    };

    ()
}

sub _sendmail {
    my ($self, $smtp, $notification, $cb_sent) = @_;
    claim { $notification->$_isa('LEMA::DB::Notifications::Doc') };

    my $email_text = $notification->message // "Test email with document";

    utf8::decode($email_text);
    my @parts = (
        Email::MIME->create(
            attributes => {
                content_type => "text/plain",
                charset      => "UTF-8",
                encoding     => "base64",
            },
            body_str => $email_text,
        ),
    );

    my $files = $notification->files;

    $files->enum(sub {
        my $file   = shift;
        my $octets = $file->octets;

        if ($file->type eq 'application/pdf') {
        } else {
            AE::log error => "Not supported file to send in notification: %s",
                             $file->type;
            next;
        }

        unshift @parts, Email::MIME->create(
            attributes => {
                filename     => $file->name_with_extension,
                content_type => $file->type,
                encoding     => "base64",
                disposition  => "attachment",
                name         => $file->name,
            },
            body => $octets,
        );
    });

    my $h_to  = [ $notification->email_to_fmt ];
    my $h_cc  = $notification->email_ccs_fmt;
    my $h_bcc = $notification->email_bccs_fmt;

    my @all_tos;
    push @all_tos, $h_to->[0];
    if ($h_cc)  { push @all_tos, $_ for @$h_cc;  }
    if ($h_bcc) { push @all_tos, $_ for @$h_bcc; }

    my $subject = $notification->subject // "Document notification";
    my $company = $smtp->from_email_company;

    utf8::decode($subject);

    my $msg = Email::MIME->create(
        header_str => [
            From    => $smtp->from_email_with_fullname,
            To      => $h_to,
            $h_cc  ? (Cc  => $h_cc)  : (),
            $h_bcc ? (Bcc => $h_bcc) : (),
            length $company ? (Organization => $company) : (),
            Subject => $subject,
        ],
        parts => [ @parts ],
    );

    my $data = $msg->as_string;
    AE::log trace => "Send email with data: %s", $data;

    ACME::AnyEvent::SMTP::Client::sendmail
        host     => $smtp->host,
        port     => $smtp->port,
        username => $smtp->username,
        password => $smtp->password,
        from     => $smtp->from_email_address,
        to       =>
                   \@all_tos,
        timeout  => 45,
        data     => $data,
        cb       => sub {
            my ($ok, $err) = @_;

            if ($err) {
                $ok = 0;
                my $msg = "Failed to send email(s): $err";
                AE::log error => "%s", $msg;
            }
            if ($ok) {
                AE::log info => "Email has been sent";
            }

            $cb_sent->($ok, $err);
            ()
        }
    ;

    ()
}


sub main {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';
    my $resp = $req->response->template('/notifications/main.html');

    return 0;

    $resp->success(1);
    $req->finish_response;
    1
}

sub send_file {
    my ($self, $httpd, $req, $notification_id, $file_idx) = @_;
    return 0 if $req->method ne 'GET';

    my ($ct, $bin) = $self->app->db->notifications->get_file(
                            $notification_id, $file_idx);

    unless (defined $bin) {
        return 0;
    }

    $req->respond([ 200 => "OK", { 'Content-Type' => $ct }, $bin ]);
    $req->finish_response;
    1
}

sub messages_activate {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);

    $self->app->db->notifications->activate(
        $vars->{notification_id},
        $vars->{email_subject},
        $vars->{email_message},
    );

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Settings app called (%s)", $req->url;
        $httpd->stop_request;

        my $ok;
        if ($req->method eq 'GET' && $req->url eq '/lema/v1/notifications') {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/notifications/([^/]+)/files/(\d+)(\?|$)!) {
            $ok = $self->send_file($httpd, $req, $1, $2);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/notifications/messages(\?|$)!) {
            $ok = $self->messages_activate($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
