package LEMA::Web::Stock;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use LEMA::Web::Accounts;
use ACME::Claim;
use parent qw(LEMA::Web::base LEMA::Web::cache_obj
              LEMA::Web::contragent);
use ACME::E;

sub singleton : lvalue { our $SINGLETON }

sub cache_get {
    my $self = shift;
    return LEMA::Web::cache_with_product->products;
}

sub main {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;


    $vars{sort}  = "qty" unless $vars{sort} =~ /^(qty|name)$/;
    $vars{order} = "desc"         unless length $vars{order};

    local *_main_template = sub { '/stock/main.tmpl' };
    local *_allowed_sort  = sub {
        return qr{^(name|qty)$};
    };

    local *_filter = sub {

        1
    };

    my $txn_count_per_product = LEMA::Web::CustomersOrders->singleton->products;
    local *_query_hook = sub {
        my $items = $_[1];
    };

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub flow {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my $started = AE::time;
    my %vars    = $req->vars;
    my $is_json = delete $vars{is_json};
    my $resp    = $req->response
                      ->template("/stock/flow.tmpl");

    $vars{order} = 'desc' unless length $vars{order};

    my $db = LEMA::DB::singleton;
    my $stockflow = $db->stockflow;

    unless ($is_json =~ /^(1|true)$/i) {
        if ($vars{submit} =~ /reset/i) {
            delete $vars{search};
            delete $vars{limit};
            delete $vars{sort};
            delete $vars{order};
        }

        $stockflow->_validate_query(\%vars);

        my %copy = %vars;
        delete $copy{page};
        delete $copy{limit};

        my $url = URI->new;
        $url->query_form(%copy);

        $vars{is_json} = boolean::false;

        $resp->success(1)
             ->json(0)
             ->reply(query_string => $url->query,
                     query        => \%vars);

        $req->finish_response;
        return 1;
    }

    $resp->json(1)->reply(items => []);

    my %perf = (timing => undef, cache_key => undef);

    my $res = $stockflow->query(\%vars, \ my $total);

    unless (@$res) {
        if ($vars{search} =~ /^product_id:(\d+)$/) {
        }
    }

    $resp->success(1)
         ->reply(items => $res,
                 total => int $total,
                 query => \%vars,
                 perf  => \%perf);

    $req->finish_response;
    1
}

sub summary {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';
    my $resp = $req->response->template("/stock/summary.tmpl");

    my $products = LEMA::Web::Products->singleton->cache_get;

    my $total_qty         = 0;
    my $total_calc_avg    = 0;
    my $total_asset_value = 0;
    my $total_smapp_qty   = 0;
    my $total_txn_count   = 0;

    my @summary;

    for (values %$products) {
        my $inv;
        next unless $inv = $_->inventory;
        my $qbo_id = $_->Id;

        my %hash = (qbo_id          => $qbo_id,
                    qbo_qty         => $inv->Qty,
                    qbo_calc_avg    => $inv->CalcAvg,
                    qbo_asset_value => $inv->AssetValue,
                    qbo_name        => $inv->ProductsAndService);

        my $smapp_qty    = 0;
        $hash{txn_count} = 0;

        my $smapp_products = LEMA::Web::cache_with_product->get_products_by_qbo_id($qbo_id);

        if ($qbo_id == 3) {
        }

        for (@$smapp_products) {
            $smapp_qty       += $_->{qty};
            $hash{txn_count} += $_->{txn_count};
            $total_txn_count += $_->{txn_count};
            $total_smapp_qty += $_->{qty};
        }

        $hash{smapp_qty} = $smapp_qty;

        for (qw(qbo_calc_avg qbo_asset_value)) {
            $hash{$_} = ACME::Data::print_amount($hash{$_});
        }

        push @summary, \%hash;

        $total_qty         += $inv->Qty;
        $total_calc_avg    += $inv->CalcAvg;
        $total_asset_value += $inv->AssetValue;
    }

    if (@summary) {
        @summary = sort { $b->{qbo_qty} <=> $a->{qbo_qty}
                            or
                          $a->{qbo_name} cmp $b->{qbo_name} } @summary;
    }

    my $total_asset_avg = $total_qty ? ($total_asset_value / $total_qty)
                                     : 0;

    $resp->reply(summary           => @summary ? \@summary : undef,
                 total_qty         => $total_qty,
                 total_asset_value => ACME::Data::print_amount($total_asset_value),
                 total_calc_avg    => ACME::Data::print_amount($total_asset_avg),
                 total_smapp_qty   => $total_smapp_qty,
                 total_txn_count   => $total_txn_count,
    );

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;


        my $ok;
        if ($req->url =~ m!/lema/v1/stock(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->url =~ m!/lema/v1/stock/flow(\?|$)!) {
            $ok = $self->flow($httpd, $req);
        }
        elsif ($req->url =~ m!/lema/v1/stock/summary(\?|$)!) {
            $ok = $self->summary($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
