package LEMA::Web::File;
use common::sense;
use LEMA::HTTPD::MIME;
use LEMA::Static;
use Carp;
use Data::Dumper;
use Digest::CRC qw(crc32);

my %STORE;
my $UNIQ_PREF = $$ . AE::time;
$UNIQ_PREF =~ s/\D//g;

sub new {
    my ($class, %args) = @_;
    bless \%args, $class
}

sub app {
    my ($self, $httpd, $req) = @_;

    my $headers  = $req->headers;
    my @segments = $req->url->path_segments;

    $httpd->throw_404 unless @segments >= 5 && $segments[0] == '';
    $httpd->throw_404 unless $segments[1] == 'lema' &&
                             $segments[2] == 'v1' &&
                             $segments[3] == 'assets';

    for (@segments) {
        $httpd->throw_404 if $_ eq '..' || $_ eq '.';
    }

    splice @segments, 1, 2;

    my $filepath = join '/', @segments;
    my $crc32    = crc32($filepath);
    my $etag     = $UNIQ_PREF . $crc32;

    if ($headers->{'if-none-match'} eq $etag && $STORE{$crc32} eq $filepath) {
        $req->respond([ 304 => "Not Changed", {
            'Content-Type' => 'text/plain',
        }, 'Not Changed' ]);
        return;
    }

    my $bin      = LEMA::Static::find_html5 $filepath;

    $httpd->throw_404 if $filepath =~ /\.tmpl$/;

    unless (defined $bin) {
        $filepath .= '/' unless $filepath =~ m!/$!;
        $filepath .= 'index.html';
        $bin = LEMA::Static::find_html5 $filepath;
        unless (defined $bin) {
            AE::log debug => "File not found: '%s'", $filepath;
        }
    }

    $httpd->throw_404 unless defined $bin;

    my $ct = LEMA::HTTPD::MIME->mime_type($filepath) || 'text/plain';

    $STORE{$crc32} = $filepath;

    $req->respond([ 200 => "OK", { 'SC-Trace-Log' => 0,
                                   'ETag'         => $etag,
                                   'Content-Type' => $ct }, $bin ]);
    ()
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        $self->app(@_);
    }
}

1;
