package LEMA::Web::Settings;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::Settings::base
              LEMA::Web::Settings::remote_service);
use ACME::E;

sub main {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';
    my $resp = $req->response->template('/settings/main.html');

    $resp->reply(mongodb_redacted_uri =>
                    $self->config->data->mongodb_get_uri_redacted);

    if ($self->app->db->inited) {
        $resp->reply(db => boolean::true);

        my $profile  = $self->app->db->settings->active_profile;
        my $profiles = $self->app->db->settings->find_all_profiles;
        my $accounts;
        my $dd_inventory;
        my $inventory;

        try {
            $accounts     = LEMA::Web::Accounts->singleton->cache_get_as_aref;
            $inventory    = $profile->inventory;
            $dd_inventory = $profile->dd_inventory;
        } catch {
            AE::log debug => "%s", $_;
        };

        if ($accounts && ($inventory || $dd_inventory)) {
            for (@$accounts) {
                if ($inventory) {
                    if ($_->Id eq $inventory->income_account) {
                        $_->{selected_income_account} = 1;
                    }
                    if ($_->Id eq $inventory->expense_account) {
                        $_->{selected_expense_account} = 1;
                    }
                    if ($_->Id eq $inventory->asset_account) {
                        $_->{selected_asset_account} = 1;
                    }
                }
                if ($dd_inventory) {
                    if ($_->Id eq $dd_inventory->income_account) {
                        $_->{selected_dd_income_account} = 1;
                    }
                    if ($_->Id eq $dd_inventory->expense_account) {
                        $_->{selected_dd_expense_account} = 1;
                    }
                    if ($_->Id eq $dd_inventory->asset_account) {
                        $_->{selected_dd_asset_account} = 1;
                    }
                }
            }
        }

        if ($accounts && @$accounts) {
            @$accounts = sort { lc($a->DisplayName) cmp lc($b->DisplayName) }
                              @$accounts;
        }

        $resp->reply(
            profiles => $profiles,
            users    => $profile->users,
            smtp     => $profile->smtp,
            qbo      => $profile->qbo,
            accounts => $accounts,
        );
    }
    else {
        $resp->reply(db => boolean::false);
    }


    $resp->success(1);
    $req->finish_response;
    1
}

sub database {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp     = $req->response->json(1);
    my %vars     = $req->vars;
    my $uri      = $vars{uri};
    my $old_uri  = $self->config->data->mongodb_get_uri;

    try {
        $self->config->data->mongodb_set_uri($uri);
        $self->app->change_db_and_profile(undef);
        $self->config->save_data;
    }
    catch {
        my $excp = $_;

        if (is_e $_ && $_ == O_APP_QBO_NO_API_CREDS) {
            $self->config->save_data;
        }
        else {
            if (length $old_uri) {
                $self->config->data->mongodb_set_uri($old_uri);
            }
            $self->app->change_db_and_profile(undef);
            die $excp;
        }
    };

    $self->{_w_database_change} = AE::timer 2, 0, sub {
        AE::log info => "Database change is under progress";
        exit -1;
    };

    die "Database change is underway. Please wait a few minutes, then refresh the page.\n";

    $resp->success(1);
    $req->finish_response;
    1
}

sub activate_profile {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    my %vars = $req->vars;

    $self->app->change_db_and_profile($vars{index});

    $resp->success(1);
    $req->finish_response;
    1
}

sub remove_profile {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    my %vars = $req->vars;

    $self->app->db->settings->remove_profile_by_index($vars{index});

    $resp->success(1);
    $req->finish_response;
    1
}

sub create_profile {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp    = $req->response->json(1);
    my %vars    = $req->vars;
    my $idx     = $self->app->db->settings->get_next_free_profile_index;
    my $profile = $self->app->db->settings->new_profile_object_with_index($idx);

    $self->app->db->settings->insert_profile($profile);

    $resp->success(1);
    $req->finish_response;
    1
}

sub smtp {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    my %vars = $req->vars;
    my $smtp = ACME::Object::SMTP->new(\%vars);

    $self->app->db->settings->active_profile->smtp($smtp);
    $self->app->db->settings->upsert_active_profile;

    $resp->success(1);
    $req->finish_response;
    1
}

sub inventory {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    my $vars = $req->same_vars_struct;
    my $wd   = $vars->{wd};
    my $dd   = $vars->{dd};

    my $inventory = LEMA::DB::Settings::Inventory->new($wd);
    $self->app->db->settings->active_profile->inventory($inventory);

    my $inventory = LEMA::DB::Settings::Inventory->new($dd);
    $self->app->db->settings->active_profile->dd_inventory($inventory);

    $self->app->db->settings->upsert_active_profile;

    $resp->success(1);
    $req->finish_response;
    1
}

sub restart {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);

    $self->{_w_restart} = AE::timer 2, 0, sub {
        AE::log info => "Application restart is under progress";
        exit -1;
    };

    die "Restart is underway. Please wait a few minutes, then refresh the page.\n";

    $resp->success(1);
    $req->finish_response;
    1
}

sub update {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';
    my $resp = $req->response->template('/settings/update.html');
    my %vars = $req->vars;
    return 0 unless exists $vars{filedata};

    my $filename;
    my $content;
    if (ref $req->{parm}{filedata}    eq 'ARRAY' &&
        ref $req->{parm}{filedata}[0] eq 'ARRAY') {
        $filename = $req->{parm}{filedata}[0][2];
        $content  = $req->{parm}{filedata}[0][0];
    }

    unless ($filename =~ /\.(deb)/i) {
        die "Invalid file extension. Expected .deb\n";
    }

    unless (length $content) {
        die "Uploaded file is empty.\n";
    }

    $filename = "/tmp/" . AE::time . ".deb";

    open my $fh, '>', $filename or die "Couldn't open file for writing: $!";
    binmode $fh;
    print $fh $content;
    close $fh;

    $self->{_w_update} = AE::timer 2, 0, sub {
        AE::log info => "Application update is under progress";
        my $output = `apt-get install --reinstall -y --allow-downgrades \"$filename\" 2>&1 &`;
        AE::log info => "Application update status:\n%s", $output;
    };

    $resp->success(1);
    $req->finish_response;
    1
}

sub quickbooks {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp    = $req->response->json(1);
    my %vars    = $req->vars;
    my $creds   = QuickBooks::Objects::Credentials->new(\%vars);
    my $profile = $self->app->db->settings->active_profile;

    my $old = $profile->qbo;
    if ($old) {
        if ($old->are_same_tokens($creds)) {
            my $company_info = $self->app->qbo->company_info->read;
            $old->company_name($company_info->CompanyName);
            $self->app->db->settings->upsert_active_profile;
            $resp->reply(company_name => $old->company_name);
            $resp->success(1);
            $req->finish_response;
            return;
        }

        if ($old->RealmID ne $creds->RealmID) {
            die "RealmID as well as QBO company cannot be changed in " .
                "the same profile. Please create a new LEMA SMAPP profile.\n";
        }
    }

    my $profiles = $self->app->db->settings->find_all_profiles;
    for (@$profiles) {
        next if $_->removed;
        next unless $_->qbo;
        next if $_->index == $profile->index;
        if ($creds->RealmID eq $_->qbo->RealmID) {
            die sprintf "Company %s (defined by RealmID %s) already exists in " .
                        "LEMA SMAPP\n", $_->qbo->company_name, $_->qbo->RealmID;
        }
    }
    undef $profiles;

    my $qbo = QuickBooks->new(
        -credentials => $creds,
        -write_cb    => sub {
            my ($credentials) = @_;
            ()
        },
    );

    my $company_info = $qbo->company_info->read;
    $creds->company_name($company_info->CompanyName);

    $self->app->db->settings->active_profile->qbo($creds);
    $self->app->db->settings->upsert_active_profile;

    $self->app->change_db_and_profile(undef);

    $self->{_w_qbo_creds_restart} = AE::timer 2, 0, sub {
        AE::log info => "QuickBooks settings change is under progress";
        exit -1;
    };

    die "QuickBooks settings are being applied. Please wait a few minutes, then refresh the page.\n";

    $resp->reply(company_name => $creds->company_name);
    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Settings app called (%s)", $req->url;
        $httpd->stop_request;


        my $ok;
        if ($req->url eq '/lema/v1/settings') {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/database') {
            $ok = $self->database($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/profiles/activate') {
            $ok = $self->activate_profile($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/profiles/remove') {
            $ok = $self->remove_profile($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/profiles') {
            $ok = $self->create_profile($httpd, $req);
        }

        elsif ($req->url eq '/lema/v1/settings/users') {
            $ok = $self->users($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/smtp') {
            $ok = $self->smtp($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/quickbooks') {
            $ok = $self->quickbooks($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/inventory') {
            $ok = $self->inventory($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/restart') {
            $ok = $self->restart($httpd, $req);
        }
        elsif ($req->url eq '/lema/v1/settings/update') {
            $ok = $self->update($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
