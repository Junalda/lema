package LEMA::Web::Webhook;
use common::sense;
use boolean;
use Carp;
use Guard;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::base);
use ACME::Data;
use ACME::E;
use ACME::Claim;
use LEMA::Web::Preferences;
use JSON::XS;

our $JSON = JSON::XS->new->utf8->convert_blessed->pretty;
our $QBO_VERIFIER_TOKEN = 'c2421695-63d7-4d84-a94f-b8bc0776f796';

sub singleton : lvalue { our $SINGLETON }

sub new {
    my ($class, @args) = @_;
    my $self = $class->SUPER::new(@args);

    $self->{_events}  = [];
    $self->{_w_count} = 0;

    my $self_w = $self;
    Scalar::Util::weaken($self_w);

    $self->{_w} = AE::timer 0, 10, sub {
        return unless $self_w && $self_w->{_w};
        try {
            $self_w->_process_events;
            $self_w->{_w_count}++;
            $self_w->{_w_count} = 0 if $self_w->{_w_count} >= 0x7FFFFFFF;
        } catch {
            AE::log error => "%s", $_;
            ()
        };
    };

    $self->{_w2} = AE::timer 0, 10, sub {
        return unless $self_w && $self_w->{_w2};
        if ($self_w->{_initialized}) {
            delete $self_w->{_w2};
            return;
        }
        $self_w->_initilize_local_db;
        ()
    };

    $self->_initilize_local_db;
    return $self;
}

sub _w_count { $_[0]{_w_count} }
sub _events  { $_[0]{_events}  }

sub _initilize_local_db {
    my ($self) = @_;
    AE::log debug => "Initializing local database with all objects...";
    claim { !$self->{_initialized} };

    try {
        LEMA::Web::Preferences->singleton->initialize_local_db;
        LEMA::Web::Term->singleton->initialize_local_db;
        LEMA::Web::Customers->singleton->initialize_local_db;
        LEMA::Web::Suppliers->singleton->initialize_local_db;
        LEMA::Web::CustomersOrders->singleton->initialize_local_db;
        LEMA::Web::SuppliersOrders->singleton->initialize_local_db;
        LEMA::Web::Products->singleton->initialize_local_db;
        $self->{_initialized} = 1;
    } catch {
        if ($ENV{SC_TRACE} || $ENV{SC_DEBUG}) {
            AE::log fatal => "(DEBUG) Failed to initialize local DB: %s", $_;
        }
        AE::log error => "Failed to initialize local DB: %s", $_;
        ()
    };
    ()
}

sub _merge_events {
    my ($self, $new_events) = @_;
    AE::log debug => "Merge events...";
    unless ($new_events && @$new_events) {
        AE::log debug => "Nothing to merge";
        return;
    }
    my $events = $self->_events;
    for (@$events) {
        last unless @$new_events;
        next if defined $_;
        AE::log debug => "Set new events in undefined array element...";
        $_ = shift @$new_events;
    }

    unless (@$new_events) {
        AE::log debug => "No more new events to merge";
    }
    else {
        AE::log debug => "Add %u events...", scalar keys @$new_events;
        for (@$new_events) {
            push @$events, $_;
        }
    }

    AE::log debug => "Sort events by 'updated_on' value...";

    my %per_id;
    for my $ev (sort { $a->{updated_on} <=> $b->{updated_on} } @$events) {
        my $v = $per_id{$ev->{id}} ||= [];
        push @$v, $ev;
    }

    AE::log trace => "Sorted events per ID: %s", Dumper+\%per_id;
    AE::log debug => "Set sorted events as active...";

    my @new_events;
    for (sort { $a <=> $b } keys %per_id) {
        my $aref = $per_id{$_};
        AE::log debug => "Got %u events for ID: %u", scalar @$aref, $_;
        if (@$aref == 1) {
            push @new_events, $aref->[0];
            next;
        }

        AE::log debug => "Collect all event names (e.g. Invoice) per ID %u", $_;
        my %names;
        for my $ev (@$aref) {
            $names{$ev->{name}}++;
        }

        if (keys %names > 1) {
            AE::log error => "Event for ID %u has more than one name: %s",
                             $_, Dumper+\%names;
            push @new_events, @$aref;
            next;
        }

        AE::log debug => "Remove 'Delete' before 'Create' and others";

        for (my $i = 0; $i < @$aref; $i++) {
            my $ev = $aref->[$i];
            if ($ev->{operation} eq 'Delete' && ($i + 1) < @$aref) {
                AE::log trace => "Ignore event 'Delete' because " .
                                 "there are others: %s", Dumper+$aref;
                next;
            }

            push @new_events, $ev;
        }
    }

    AE::log trace => "Prepared final %u events for processing after merge: %s",
                     scalar @new_events, Dumper+\@new_events;

    @{$self->_events} = @new_events;

    ()
}

sub _process_events {
    my $self   = shift;
    my $events = $self->_events;
    AE::log debug => "Processing QBO events...";
    unless (@$events) {
        AE::log debug => "No QBO events for processing";
        return;
    }
    else {
        my $count = 0;
        for (@$events) {
            $count++ if defined $_;
        }
        AE::log debug => "Found %u QBO events for processing", $count;
        return unless $count;
    }

    for my $ev (@$events) {
        next unless defined $ev;
        AE::log trace => "Event under process: %s", Dumper+$ev;
        unless (ref $ev eq 'HASH') {
            AE::log error => "QBO event data is not hashref";
            $ev = undef;
            next;
        }

        my $id = $ev->{id};
        unless ($id > 0) {
            AE::log error => "QBO event doesn't contains valid id: `%s`\n%s",
                             $id, Dumper+$ev;
            $ev = undef;
            next;
        }

        if ($ev->{name} eq 'Customer') {
            try {
                LEMA::Web::Customers->singleton->fetch($id);
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Vendor') {
            try {
                LEMA::Web::Suppliers->singleton->fetch($id);
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Term') {
            try {
                LEMA::Web::Term->singleton->initialize_local_db();
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Preferences') {
            try {
                LEMA::Web::Preferences->singleton->initialize_local_db();
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Bill') {
            try {
                if ($ev->{operation} eq 'Delete') {
                    LEMA::Web::SuppliersOrders->singleton->cache_remove($id);
                } else {
                    LEMA::Web::SuppliersOrders->singleton->fetch($id);
                }
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Invoice') {
            try {
                if ($ev->{operation} eq 'Delete') {
                    LEMA::Web::CustomersOrders->singleton->cache_remove($id);
                } else {
                    LEMA::Web::CustomersOrders->singleton->fetch($id, -merge_emails => 1);
                }
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        elsif ($ev->{name} eq 'Item') {
            try {
                LEMA::Web::Products->singleton->fetch($id);
                $ev = undef;
            } catch {
                AE::log error => "%s", $_;
                ()
            };
        }
        else {
            $ev = undef;
        }
    }

    ()
}

sub main {
    my ($self, $httpd, $req) = @_;

    my $resp = $req->response->json(1);
    my %vars = $req->vars;
    my $hash;
    my $verifier_token = $QBO_VERIFIER_TOKEN;

    try {
        $hash = $JSON->decode($req->content);
        unless (ref $hash eq 'HASH') {
            $hash = undef;
            die "Received JSON is not hash\n";
        }
    } catch {
        AE::log error => "Couldn't decode JSON notification " .
                         "from QBO: Error: %s; JSON: %s", $_, $req->content;
    };

    die "Failed to decode JSON" unless $hash;

    AE::log trace => "Received notification from QBO:\n%s", Dumper+$hash;

    my @events;
    my $events = $hash->{eventNotifications};
    die "Invalid arrayref\n" unless ref $events eq 'ARRAY';

    my $profile = $self->app->db->settings->active_profile;
    my $qbo     = $profile->qbo;


    for my $ev (@$events) {
        my $realm_id = $ev->{realmId};
        next unless $realm_id =~ /^\d+$/;
        my $data = $ev->{dataChangeEvent};
        next unless ref $data eq 'HASH';
        my $entities = $data->{entities};
        next unless ref $entities eq 'ARRAY';

        AE::log trace => "Notification from QBO:\n%s", Dumper+$ev;

        unless ($realm_id eq $qbo->RealmID) {
            AE::log warn => "Non existing RealmID in notification: " .
                            "%s not equal to %s",
                            $realm_id, $qbo->RealmID;
            next;
        }

        for my $entity (@$entities) {
            my $last_updated = $entity->{lastUpdated};
            my $operation    = $entity->{operation};
            my $id           = $entity->{id};
            my $name         = $entity->{name};

            $entity->{updated_on} = ACME::Data::epoch_from_yyyy_mm_dd_hh_mm_ss_ms($entity->{lastUpdated});




            AE::log trace => "Stored event entity: %s", Dumper+$entity;
            push @events, $entity;
        }
    }


    $self->_merge_events(\@events);
    $self->_process_events;

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "QBO webook app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;

        my $ok;
        if ($req->url =~ m!/lema/v1/qbo-webhook(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
