package LEMA::Web::Logs;
use common::sense;
use Carp;
use Data::Dumper;
use AnyEvent::Log;

our $MAX_LOG_LINES_BUFFER = 20_000;
our @LOG_BUF;

sub new {
    my ($class, %args) = @_;
    my $self = bless \%args, $class;
    $self->{_started} = AE::time;
    return $self;
}

sub log_collect {
    for (@_) {
        my @lines = split /(\r?\n)/, $_;
        push @LOG_BUF, @lines;

        if (@LOG_BUF > $MAX_LOG_LINES_BUFFER) {
            my $overflow = @LOG_BUF - $MAX_LOG_LINES_BUFFER;
            splice @LOG_BUF, 0, $overflow;
        }
    }
    ()
}

sub main {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my $resp = $req->response->template('/logs/main.tmpl');
    my $logs = join '', @LOG_BUF;

    my %uptime = (
        started_on => scalar localtime(int($self->{_started})),
        seconds    => int(AE::time - $self->{_started}),
    );

    $resp->reply(logs    => $logs,
                 uptime  => \%uptime,
                 version => $LEMA::VERSION);

    $resp->success(1);
    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Logs app called (%s %s)", $req->method, $req->url;
        $httpd->stop_request;

        my $ok;
        if ($req->url =~ m!/lema/v1/logs(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
