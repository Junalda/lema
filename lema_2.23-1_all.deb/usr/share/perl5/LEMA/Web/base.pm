package LEMA::Web::base;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;

sub new {
    my ($class, %args) = @_;

    die "No config"
        unless $args{-config}->$_isa('LEMA::Config');

    die "Invalid Parcelow app object"
        unless $args{-app}->$_isa('LEMA::App');

    my $self = bless \%args, $class;
    $self->singleton = $self;
    return $self;
}

sub app      { $_[0]{-app}     }
sub config   { $_[0]{-config}  }

1;
