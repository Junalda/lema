package LEMA::Web::Tax;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

sub _main_template { '/tax/main.tmpl' }
sub singleton : lvalue { our $SINGLETON }

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->tax_rate->query;
    } catch {
        die $_;
    };

    $self->cache_set_all(\@items);
    return \@items;
    ()
}

sub cache_get {
    my $self = shift;
    $self->fetch_all;
    return $self->SUPER::cache_get;
}


sub main {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;

    if ($vars{native}) {
        my @items = $self->app->qbo->tax_rate->query;
        die "Native rate output: ", Dumper+\@items;
    }

    delete $vars{search};
    $vars{limit} = 100 if $vars{limit} <= 0;


    local *_default_sort  = sub { 'RateValue' };
    local *_main_template = sub { '/tax/main.tmpl' };
    local *_allowed_sort  = sub {
        return qr{^(Name|RateValue)$};
    };

    local *_filter = sub {
        return 1 unless defined $_[2];
        return 0;
    };


    return $self->SUPER::main($httpd, $req, \%vars);
}

sub codes {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;

    if ($vars{native}) {
        my @items = $self->app->qbo->tax_code->query;
        die "Native code output: ", Dumper+\@items;
    }

    delete $vars{search};
    $vars{limit} = 100 if $vars{limit} <= 0;


    local *_default_sort  = sub { 'Name' };
    local *_main_template = sub { '/tax/codes.tmpl' };
    local *_allowed_sort = sub {
        return qr{^(Name)$};
    };

    local *_filter = sub {
        return 1 unless defined $_[2];
        return 0;
    };


    local *cache_get = sub {
        my $self = shift;
        my @items;
        try {
            @items = $self->app->qbo->tax_code->query;
        } catch {
            die $_;
        };

        my %cache;
        for (@items) {
            $cache{$_->Id} = $_;
        }

        return \%cache;
    };

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub build_array {
    my ($self, $selected_id, %args) = @_;
    my $all_tax_rate_aref = $self->fetch_all;
    my @all = $self->app->qbo->tax_code->query;


    my @tax_rates;
    for my $code (@all) {



        for my $method (qw(SalesTaxRateList PurchaseTaxRateList)) {
            if ($args{-purchase_only}) {
                next if $method eq 'SalesTaxRateList';
            }
            if ($args{-sales_only}) {
                next if $method eq 'PurchaseTaxRateList';
            }
            if ($args{-active_only}) {
                next unless $code->Active;
            }

            unless ($code->$method) {
                next;
            }

            my $aref = $code->$method->enum_tax_rate_ref(sub {
                my $tax_rate_ref  = shift;
                my $tax_rate_id   = $tax_rate_ref->value;
                my $tax_rate_name = $tax_rate_ref->name;
                return unless $tax_rate_id > 0;

                my $tax_rate_value;
                for my $el (@$all_tax_rate_aref) {
                    next unless $el->Id eq $tax_rate_id;
                    if ($el->agency_id != 1) {
                        return;
                    }

                    $tax_rate_value  = $el->effective_rate_now;
                    last;
                }

                return unless defined $tax_rate_value;


                my %hash = (
                    id          => $tax_rate_id,
                    name        => $tax_rate_name,
                    rate_value  => $tax_rate_value,
                    active      => $code->Active,
                    tax_code_id => $code->Id,
                    selected    => undef,
                    source      => $method,
                );

                if (length $selected_id) {
                    if ($selected_id == $tax_rate_id) {
                        $hash{selected} = 1;
                    }
                }

                push @tax_rates, \%hash;
                ()
            });
        }
    }
    @tax_rates = sort {
        $a->{rate_value} <=> $b->{rate_value}
            or
        $a->{name} cmp $b->{name}
    } @tax_rates;

    return \@tax_rates;
}

sub agency {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;

    if ($vars{native}) {
        my @items = $self->app->qbo->tax_agency->query;
        die "Native code output: ", Dumper+\@items;
    }

    delete $vars{search};
    $vars{limit} = 100 if $vars{limit} <= 0;


    local *_default_sort  = sub { 'DisplayName' };
    local *_main_template = sub { '/tax/agency.tmpl' };
    local *_allowed_sort = sub {
        return qr{^(DisplayName)$};
    };

    local *_filter = sub {
        return 1 unless defined $_[2];
        return 0;
    };


    local *cache_get = sub {
        my $self = shift;
        my @items;
        try {
            @items = $self->app->qbo->tax_agency->query;
        } catch {
            die $_;
        };

        my %cache;
        for (@items) {
            $cache{$_->Id} = $_;
        }

        return \%cache;
    };

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;

        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/accounts/tax(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/accounts/tax/codes(\?|$)!) {
            $ok = $self->codes($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/accounts/tax/agency(\?|$)!) {
            $ok = $self->agency($httpd, $req);
        }


        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
