package LEMA::Web::CustomersOrders;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use ACME::Data;
use Tie::IxHash;
use LEMA::Util::PDF;
use LEMA::DB::Stockflow;
use LEMA::Object::ItemRef;
use LEMA::Object::Invoice;
use parent qw(LEMA::Web::base
              LEMA::Web::cache_with_product
              LEMA::Web::contragent
              LEMA::Web::last_recipients
              LEMA::Web::mindoc);
use ACME::E;

my $JSON_CODER //= eval { require JSON::XS; JSON::XS->new->utf8 } ||
                    do  { require JSON::PP; JSON::PP->new->utf8 };

sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    $self->cache;
    ()
}

sub _allowed_sort {
    qr{^(DocNumber|CreationDate|DepartureDate|TxnDate|CustomerDisplayName)$};
}

sub _main_filter {
    return 0 if defined $_[1]->error;
    return 0 unless $_[1]->DocNumber =~ /^\d{4}-\d{4}$/;

    if (length $_[3] && $_[3] =~ /^docnumber\:(\S+)$/) {
        return 1 if $_[1]->DocNumber eq $1;
    }
    return 1 unless defined $_[2];

    return 1 if $_[1]->DocNumber =~ $_[2];

    return 1 if $_[1]->txndate_fmt   =~ $_[2];


    if ($_[1]->properties) {
        return 1 if $_[1]->properties->creation_date_fmt =~ $_[2];
        return 1 if $_[1]->properties->departure_date_fmt =~ $_[2];

    }

    my $customer_ref = $_[1]->CustomerRef;
    if ($customer_ref) {
        return 1 if $customer_ref->name =~ $_[2];
    }

    return 0;
}

sub fetch {
    my ($self, $id, %args) = @_;
    my $obj = $self->app->qbo->invoice->query_by_id($id);

    LEMA::Object::Invoice->extend($obj);
    unless (length $obj->error) {
        $self->app->db->properties->populate_invoice($obj);

    }

    $self->cache_set($obj);
    return $obj;
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->invoice->query;
    } catch {
        die $_;
    };

    for (@items) {
        die "Invoice without ID\n" unless $_->Id;
        LEMA::Object::Invoice->extend($_);
        unless (length $_->error) {
            $self->app->db->properties->populate_invoice($_);
        }
    }

    $self->cache_set_all(\@items);
    return \@items;
}

sub query {
    my ($self, $query, $ptotal) = @_;
    my $all = $self->SUPER::query($query, $ptotal);

    for my $po (@$all) {
    }
    return $all;
}

sub main {
    my ($self, $httpd, $req, $type) = @_;
    $type ||= "confirmations";
    my %vars = $req->vars;

    if (delete($vars{submit}) =~ /reset/i) {
        delete $vars{search};
        delete $vars{limit};
        delete $vars{sort};
        delete $vars{order};
    }

    local *_main_template = sub {
        if ($type eq 'confirmations') {
            return '/customers-orders/main.tmpl';
        } elsif ($type eq 'invoice') {
            return '/customers-orders/invoice.tmpl';
        } elsif ($type eq 'packing') {
            return '/customers-orders/packing.tmpl';
        }
        die "No template";
    };

    local *_filter = $type ne 'packing'
                   ? \&_main_filter
                   : sub {
        my $ret  = $_[0]->_main_filter($_[1], $_[2], $_[3]);
        return 0 unless $ret;
        return 0 if defined $_[1]->error;
        return 1;
    };

    $vars{sort}  = "DocNumber" unless length $vars{sort};
    $vars{order} = "desc"      unless length $vars{order};

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub show_new_form {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';
    my $resp      = $req->response->template('/customers-orders/details.tmpl');
    my $stock     = $self->app->db->stockflow->build_qty_hash;
    my $vat_rates = LEMA::Web::Tax->singleton->build_array(undef, -sales_only => 1, -active_only => 1);
    my $txn_date  = ACME::Data::local_yyyymmdd;
    my $doc_num   = $self->_get_next_docnumber($txn_date);

    my $products  = LEMA::Web::Products->singleton->existing_products;
    my @native;
    if ($products) {
        for (@{$products->{product}}) {
            next if $stock && exists $stock->{$_};
            push @native, $_;
        }
    }

    my $prefs         = LEMA::Web::Preferences->singleton->preferences;
    my $definition_id = $prefs->invoice_custom_field_id(LEMA::CUSTOM_FIELD_YOUR_REFERENCE);

    $resp->reply(
        customers   => LEMA::Web::Customers->singleton->build_array,
        vat_rates   => $vat_rates,
        invoice     => { TxnDate => $txn_date, DocNumber => $doc_num, properties => { creation_date => $txn_date } },
        stock_json  => $JSON_CODER->pretty(1)->encode($stock),
        native_json => $JSON_CODER->pretty(1)->encode(\@native),
        terms       => LEMA::Web::Term->singleton->existing_terms,
        custom_field_id => ($definition_id || 'undefined'),
    );

    $req->finish_response;
    1
}

sub _vars_to_obj {
    my ($self, $vars) = @_;


    my $products = LEMA::Web::Products->singleton;

    die "No customer selected\n"
        unless ref $vars->{CustomerRef} eq 'HASH' &&
               $vars->{CustomerRef}{value} =~ /^(\d+)(\.(\d+))?$/;

    $vars->{CustomerRef}{value} = int $vars->{CustomerRef}{value};

    die "No order date\n"
        unless length $vars->{creation_date};
    die "No arrival date\n"
        unless length $vars->{TxnDate};
    die "No order number\n"
        unless length $vars->{DocNumber};
    die "Invalid order number\n"
        if ref $vars->{DocNumber};
    die "Order number is not in format of YYYY-NNNN\n"
        unless $vars->{DocNumber} =~ /^\d{4}-\d{4}$/;
    die "No sales terms\n"
        unless $vars->{SalesTermRef}{value} > 0;
    die "No due date\n"
        unless length $vars->{DueDate};

    unless ($vars->{delivery_type} > 0) {
        die "Delivery type is not specified\n";
    }

    my $delivery_date = delete $vars->{departure_date};
    if (length $delivery_date) {
        die "Invalid delivery date\n"
            unless $delivery_date =~ /^\d{4}-\d{2}-\d{2}$/;
    } else {
        $delivery_date = undef;
    }

    my $your_ref = delete $vars->{your_ref};


    my $line = $vars->{Line};
    die "No products\n" unless @$line;




    tie my %txn_line_detail, 'Tie::IxHash';




    my $net_amount_total = 0;
    my @product_names;
    my $lineno = 0;
    for my $detail (@$line) {
        $lineno++;

        my $expense = $detail->{SalesItemLineDetail};
        $expense->{UnitPrice} = ACME::Data::adjust_amount($expense->{UnitPrice});
        $expense->{Qty}       = ACME::Data::adjust_int($expense->{Qty});

        $expense->{ServiceDate} = $delivery_date if length $delivery_date;

        die "No details for product\n"
            unless ref $expense eq 'HASH' && $expense->{ItemRef};

        my $item_ref = delete $expense->{ItemRef};
        my $name =
                    $item_ref->{name};

        my $lot = $item_ref->{lot};

        $detail->{Description} = $products->_row_to_product_description($item_ref);

        if (length $detail->{Description}) {
            die "No lot selected for product\n" unless length $lot;
            $detail->{Description} .= "/" . $lot;
        }


        push @product_names, QuickBooks::Objects::ItemRef->new({
                value => 1,
                name  => $name,
                lot   => $lot,
        });


        $product_names[-1]{_for_stock} ||=
            defined $detail->{Description} ? 1 : 0;

        if ($name =~ /(^|\s)Claims?\s*(DD|WD|DFS)$/i ||
            $name =~ /^(DD|WD|DFS)\s*Claims?($|\s)/) {
            $product_names[-1]{_for_stock} = 0;
        }

        die "Quantity is not defined\n" unless length $expense->{Qty};
        die "Product price is not defined\n"    unless length $expense->{UnitPrice};
        $expense->{Qty} += 0.0;
        die "Quantity must be greater than 0\n"
            unless $expense->{Qty} > 0;
        $expense->{UnitPrice} += 0.0;

        $expense->{ItemRef}   = $product_names[-1];

        $detail->{DetailType} = 'SalesItemLineDetail',
        $detail->{Amount}     = sprintf "%.2f",
                                        $expense->{Qty} * $expense->{UnitPrice};


        my $tax_tripple = $item_ref->{tax}{tripple};
        delete $item_ref->{tax};
        if ($tax_tripple =~ /^(\d*)\.(\d*)\.(\S+)$/) {
            my ($tax_rate_id, $tax_code_id, $tax_percent) = ($1, $2, $3);
            if (length $tax_code_id) {
                my $v = $txn_line_detail{$tax_tripple} ||= +{
                    tax_percent => $tax_percent,
                    tax_rate_id => $tax_rate_id,
                    tax_code_id => $tax_code_id,
                    net_amount_total => 0,
                };

                $expense->{TaxCodeRef} = { value => $tax_code_id };#, name => '9.0% S' };
                use bigint;
                $v->{net_amount_total} += $detail->{Amount};
            }
        }
        else {
            die "VAT is not defined on product line no. ", $lineno, "\n";
        }

        $net_amount_total += $detail->{Amount};
    }

    my $tax_amount_total = 0;
    if (%txn_line_detail) {
        $vars->{TxnTaxDetail} = { TotalTax => undef, TaxLine => [] };

        for my $tripple (keys %txn_line_detail) {
            my $v = $txn_line_detail{$tripple};

            my $total_tax = sprintf("%.2f",  ($v->{net_amount_total} *
                                             $v->{tax_percent}) / 100);

            push @{$vars->{TxnTaxDetail}{TaxLine}}, {
                    Amount     => $total_tax,
                    DetailType => 'TaxLineDetail',
                    TaxLineDetail  => {
                        TaxRateRef => {
                            value => $v->{tax_rate_id},
                        },
                        PercentBased     => 1,
                        TaxPercent       => $v->{tax_percent},
                        NetAmountTaxable => $v->{net_amount_total},
                    },
            };

            $vars->{TxnTaxDetail}{TotalTax} += $total_tax;
            $tax_amount_total += $total_tax;
        }
    }



    my $dfs_state = 0;
    for (@product_names) {
        next unless $_->{_for_stock};
        if ($_->name =~ /\sDFS$/i || $_->name =~ /^DFS\s/i || $_->name =~ /^DD\:/i) {
            $dfs_state |= 0b01;
        } else {
            $dfs_state |= 0b10;
        }
    }

    die "SMAPP needs at least one inventory product in this transaction\n"
        unless $dfs_state;
    die "SMAPP needs all inventory products to be of the same kind " .
        "(you have DFS and not DFS together)\n"
        if $dfs_state == 0b11;

    $products->populate_items_value(\@product_names, -die_if_not_found => 1);
    my $invoice = QuickBooks::Objects::Invoice->new_mod($vars);
    LEMA::Object::Invoice->extend($invoice);
    die "Couldn't prepare extended purchase order object: " . $invoice->error
        if defined $invoice->error;

    my $prefs = LEMA::Web::Preferences->singleton->preferences;
    my $definition_id = $prefs->invoice_custom_field_id(LEMA::CUSTOM_FIELD_YOUR_REFERENCE);
    die sprintf "Custom field '%s' is not detected on QBO for sales\n",
                LEMA::CUSTOM_FIELD_YOUR_REFERENCE()
        unless $definition_id =~ /^\d+$/;

    $invoice->set_your_ref($definition_id, $your_ref);

    return $invoice;
}

sub insert {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';
    my $resp = $req->response->json(1);
    my $vars = $req->same_vars_struct;

    my $invoice = $self->cache_find_by_doc_number($vars->{DocNumber});

    my %props = (
        creation_date  => $vars->{creation_date},
        departure_date => $vars->{departure_date},
        arrival_date   => $vars->{arrival_date},
        vat_number     => $vars->{vat_number},
        eori           => $vars->{eori},
        sale_cond      => $vars->{sale_cond},
        delivery_type  => $vars->{delivery_type},
        status         => LEMA::DB::Properties::Doc::ORDER_ISSUED,
        euro_pallets   => $vars->{euro_pallets},
        block_pallets  => $vars->{block_pallets},
        recipients_e   => $vars->{recipients_e},
        recipients_u   => $vars->{recipients_u},
        export         => undef,
    );

    my $customer_val = $vars->{CustomerRef}{value};
    if ($customer_val =~ /^(\d+)(\.(\d+))?$/ && $3 > 0) {
        $props{doc_sub} = $3;
    }

    my $invoice = $self->_vars_to_obj($vars);
    $props{old_export} = LEMA::DB::Properties::Export->new_from_invoice($invoice);


    $self->app->db->stockflow->check_stock_for_invoice($invoice);
    my $invoice = $self->app->qbo->invoice->create($invoice->root);
    LEMA::Object::Invoice->extend($invoice);
    $self->cache_set($invoice);

    $self->app->db->properties->upsert_invoice($invoice, %props);
    $self->app->db->properties->populate_invoice($invoice);

    my $bin = $self->_generate_pdf($invoice->Id, -local => 1, -type => 'oc');
    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_invoice(
        $invoice,
        { list => [
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'ORDER-CONFIRMATION-' . $invoice->DocNumber, },
          ]
        },
    );

    $self->app->db->notifications->insert($notification);
    $resp->reply(action  => $notification->as_action);
    $resp->reply(invoice => $invoice);
    $resp->success(1);
    $req->finish_response;
    1
}

sub view {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/customers-orders/details.tmpl');


    my $invoice   = $self->cache_find_strict($id);

    if ($invoice->error) {
        die "Order confirmation is not for SMAPP: ", $invoice->error, "\n";
    }

    my $customers = LEMA::Web::Customers->singleton->build_array($invoice);
    my $stock     = $self->app->db->stockflow->build_qty_hash($invoice);

    my $notifications = $self->app->db->notifications
                                      ->find_by_invoice($invoice, -without_octets => 1);


    my $products  = LEMA::Web::Products->singleton->existing_products;
    my @native;
    if ($products) {
        for (@{$products->{product}}) {
            next if $stock && exists $stock->{$_};
            push @native, $_;
        }
    }

    my $vat_rates_all = LEMA::Web::Tax->singleton->build_array;
    $invoice->populate_vat_on_lines($vat_rates_all);
    my $vat_rates = LEMA::Web::Tax->singleton->build_array(undef, -sales_only => 1, -active_only => 1);


    my $prefs         = LEMA::Web::Preferences->singleton->preferences;
    my $definition_id = $prefs->invoice_custom_field_id(LEMA::CUSTOM_FIELD_YOUR_REFERENCE());

    $resp->reply(
        invoice   => $invoice,
        customers => $customers,
        vat_rates => $vat_rates,
        notifications => $notifications,
        stock_json => $JSON_CODER->pretty(1)->encode($stock),
        native_json => $JSON_CODER->pretty(1)->encode(\@native),
        terms      => LEMA::Web::Term->singleton->existing_terms,
        custom_field_id => ($definition_id || 'undefined'),
    );
    $resp->success(1);
    $req->finish_response;
    1
}

sub update {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);
    my $po   = $self->app->qbo->invoice->query_by_id($id);
    LEMA::Object::Invoice->extend($po);
    die "Order Confirmation is not controlled by LEMA SMAPP\n"
        if length $po->error;

    my %props = (
        creation_date  => $vars->{creation_date},
        departure_date => $vars->{departure_date},
        arrival_date   => $vars->{arrival_date},
        vat_number     => $vars->{vat_number},
        eori           => $vars->{eori},
        sale_cond      => $vars->{sale_cond},
        delivery_type  => $vars->{delivery_type},
        euro_pallets   => $vars->{euro_pallets},
        block_pallets  => $vars->{block_pallets},
        recipients_e   => $vars->{recipients_e},
        recipients_u   => $vars->{recipients_u},
        status         => LEMA::DB::Properties::Doc::ORDER_ISSUED,
        export         => undef,
    );

    $self->app->db->properties->populate_invoice($po);
    if ($po->properties && $po->properties->export) {
        AE::log debug => "Got existing export properties";
        $props{old_export} = $po->properties->export;
    }

    my $customer_val = $vars->{CustomerRef}{value};
    if ($customer_val =~ /^(\d+)(\.(\d+))?$/ && $3 > 0) {
        $props{doc_sub} = $3;
    }

    $vars->{Id} = $id;

    my $po = $self->_vars_to_obj($vars);

    $self->app->db->stockflow->check_stock_for_invoice($po);
    $self->app->db->properties->upsert_invoice($po, %props);


    my $po = $self->app->qbo->invoice->update($po->root);
    LEMA::Object::Invoice->extend($po);
    $self->app->db->properties->populate_invoice($po);
    $self->cache_set($po);

    my $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'oc');
    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_invoice(
        $po,
        { list => [
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'ORDER-CONFIRMATION-' . $po->DocNumber, },
          ]
        },
    );

    $self->app->db->notifications->insert($notification);
    $resp->reply(action  => $notification->as_action);
    $resp->reply(invoice => $po);
    $resp->success(1);
    $req->finish_response;
    1
}

sub remove {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    die "No order confirmation ID" unless length $id;

    my $po = $self->app->qbo->invoice->query_by_id($id);
    if ($po) {
        LEMA::Object::Invoice->extend($po);
        unless (defined $po->error) {

            my $po = $self->app->qbo->invoice->delete_by_id($id);
        }
        else {
            my $po = $self->app->qbo->invoice->delete_by_id($id);
        }
    }

    $self->cache_remove($id);

    $resp->success(1);
    $req->finish_response;
    1
}

sub properties {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);
    die "No invoice ID" unless length $id;

    my $po = $self->app->qbo->invoice->query_by_id($id);
    LEMA::Object::Invoice->extend($po);
    die "Invoice is not controlled by LEMA SMAPP\n"
        if length $po->error;

    $self->app->db->properties->populate_invoice($po);

    my %props      = %$vars;
    $props{old_export} = $po->properties->export;
    my $properties = $self->app->db->properties->create($po, %props);
    $po->properties($properties);

    my @list;
    if ($properties->status == LEMA::DB::Properties::Doc::ORDER_ISSUED) {
        my $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'oc');
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'ORDER-CONFIRMATION-' . $po->DocNumber, },
        );
    }
    elsif ($properties->status == LEMA::DB::Properties::Doc::ORDER_PACKING) {
        my $bin;
        if ($po->properties->is_overseas) {
            $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'cpacking');
        } else {
            $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'packing');
        }
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'PACKING-LIST-' . $po->DocNumber, },
        );
    }
    elsif ($properties->status == LEMA::DB::Properties::Doc::ORDER_DEPARTED) {
        my $bin;
        if ($po->properties->is_overseas) {
            $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'cinvoice');
        } else {
            $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'invoice');
        }
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'INVOICE-' . $po->DocNumber, },
        );
    }
    elsif ($properties->status == LEMA::DB::Properties::Doc::ORDER_ARRIVED) {
    }

    $self->app->db->properties->upsert($properties);

    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_invoice(
        $po,
        { list => \@list },
    );

    $self->cache_set($po);
    $self->app->db->notifications->insert($notification);

    $resp->reply(status => $po->properties->status,
                 action => $notification->as_action);
    $resp->success(1);
    $req->finish_response;
    1
}


sub _generate_html {
    my ($self, $id, %args) = @_;

    die "Invalid document file type\n"
        unless $args{-type} =~ /^(oc|packing|invoice|cinvoice|cpacking)$/;

    my $po = $self->app->qbo->invoice->query_by_id($id);
    LEMA::Object::Invoice->extend($po);
    die "Invoice is not controlled by LEMA SMAPP: " . $po->error . "\n"
        if length $po->error;

    $self->app->db->properties->populate_invoice($po);

    if ($po->properties->is_overseas) {
        $args{-type} = 'cinvoice' if $args{-type} eq 'invoice';
        $args{-type} = 'cpacking' if $args{-type} eq 'packing';
    }

    my $customer = $self->app->qbo->customer->query_by_id($po->CustomerRef->value);

    my $term_name;
    if ($po->SalesTermRef && $po->SalesTermRef->value) {
        my $term_id = $po->SalesTermRef->value;
        my $terms   = LEMA::Web::Term->singleton->existing_terms;
        for (@$terms) {
            if ($_->Id == $term_id) {
                $term_name = $_->Name;
                last;
            }
        }
    }

    my $vat_rates_all = LEMA::Web::Tax->singleton->build_array;
    $po->populate_vat_on_lines($vat_rates_all);

    my $tmpl = LEMA::Template::Static->new(TRIM => 1, NOXSS => 1);
    my %vars = (
        reply => { invoice  => $po,
                   customer => $customer,
                   term_name => $term_name,
        },
    );
    if ($args{-local}) {
        $vars{local_fs}  = LEMA::Static::html5_fs_full_path;
        $vars{local_fs} .= "/" unless $vars{local_fs} =~ m!/$!;
    }

    if (LEMA::Logging::is_debug) {
        $vars{debug} = { data => LEMA::HTTPD::Extended::Response::__json_coder
                                        ->pretty(1)->encode(\%vars) };
    }

    my $tmpl_path;
    if ($args{-type} eq "packing") {
        $tmpl_path = "/customers-orders/print-packing.tmpl";
    } elsif ($args{-type} eq "invoice") {
            $tmpl_path = "/customers-orders/print-invoice-new.tmpl";
    } elsif ($args{-type} eq "cinvoice") {
        $tmpl_path = "/customers-orders/print-cinvoice.tmpl";
    } elsif ($args{-type} eq "cpacking") {
        $tmpl_path = "/customers-orders/print-cpacking.tmpl";
    } elsif ($args{-type} eq "oc") {
        $tmpl_path = "/customers-orders/print.tmpl";
    } else {
        die "Invalid document file type";
    }
    $tmpl->process_static($tmpl_path, \%vars, \ my $bin);

    if (utf8::is_utf8 $bin) {
        utf8::encode $bin;
    }

    if ($args{-local}) {
        $bin =~ s!/lema/v1/!!g;
    }

    return ($po, $bin);
}

sub _generate_pdf {
    my ($self, $id, %args) = @_;

    my ($po, $html) = $self->_generate_html($id, -local => 1,
                                                 -type  => $args{-type});

    my $pdf_bin = LEMA::Util::PDF::generate($html);
    return ($po, $pdf_bin);
}

sub html {
    my ($self, $httpd, $req, $id, $type) = @_;
    return 0 if $req->method ne 'GET';
    my ($po, $html) = $self->_generate_html($id, -local => 0,
                                                 -type  => $type);
    $req->respond([ 200 => "OK", { 'Content-Type' => "text/html" }, $html ]);
    $req->finish_response;
    1
}

sub pdf {
    my ($self, $httpd, $req, $id, $type) = @_;
    return 0 if $req->method ne 'GET';

    my ($po, $pdf_bin) = $self->_generate_pdf($id, -type => $type);
    if ($po->properties->is_overseas) {
        $type = 'cinvoice' if $type eq 'invoice';
        $type = 'cpacking' if $type eq 'packing';
    }

    my $prefix;
    if    ($type eq 'oc')      { $prefix = "ORDER-CONFIRMATION" }
    elsif ($type eq 'invoice') { $prefix = "INVOICE" }
    elsif ($type eq 'cinvoice') { $prefix = "INVOICE" }
    elsif ($type eq 'cpacking') { $prefix = "PACKING" }
    elsif ($type eq 'packing') { $prefix = "PACKING" }
    else {
        die "Invalid document file type";
    }

    my $filename = sprintf "%s-%s.pdf", $prefix, $po->DocNumber;

    $req->respond([ 200 => "OK", {
        'SC-Trace-Log' => 0,
        'Content-Type' => "application/pdf",
        'Content-Disposition' => qq{attachment; filename="$filename"} },
        $pdf_bin ]);

    $req->finish_response;
    1
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Supplier Orders app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;


        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/new(\?|$)!) {
            $ok = $self->show_new_form($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/invoices(\?|$)!) {
            $ok = $self->main($httpd, $req, 'invoice');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/packing(\?|$)!) {
            $ok = $self->main($httpd, $req, 'packing');
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/orders(\?|$)!) {
            $ok = $self->insert($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/(\d+)(\?|$)!) {
            $ok = $self->view($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/orders/(\d+)/delete(\?|$)!) {
            $ok = $self->remove($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/orders/(\d+)/properties(\?|$)!) {
            $ok = $self->properties($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/orders/(\d+)(\?|$)!) {
            $ok = $self->update($httpd, $req, $1);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'oc');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/invoices/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'invoice');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/packing/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'packing');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'oc');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/invoices/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'invoice');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/packing/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'packing');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/orders/last-recipients/(\d+)(\.(\d+))?/([ue])(\?|$)!) {
            $ok = $self->last_recipients($httpd, $req, 'customer', $1, $3, $4);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
