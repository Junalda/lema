package LEMA::Web::cache_obj;
use common::sense;

sub cache_obj {
    my $self = shift;
    $self->{cache_obj} ||= +{};
}

sub cache_obj_get { $_[0]->cache_obj }

sub cache_obj_available { defined $_[0]{cache_obj} }

sub cache_obj_set {
    my ($self, $name, $obj) = @_;
    $self->cache_obj->{$name} = $obj;
    ()
}

sub cache_obj_find {
    my ($self, $name) = @_;
    die "Cache is not created" unless $self->cache_obj_available;
    my $obj = $self->cache_obj->{$name};
    die "Object is not found\n" unless $obj;
    return $obj;
}

1;

__DATA__


sub CLEAN_ALL() {
    %CACHE = ();
    ()
}

sub cache_clean {
    my $self = shift;
    $CACHE{$self} = [];
    ()
}

sub cache_size {
    my $self = shift;
    my $cache = $CACHE{$self};
    return scalar @$cache;
}

sub cache_set {
    my ($self, $data) = @_;
    $CACHE{$self} = $data;
    ()
}

sub cache_get {
    my ($self) = @_;
    my $ret = $CACHE{$self} //= [];
    $CACHE{$self} = [];
    return $ret;
}

1;
