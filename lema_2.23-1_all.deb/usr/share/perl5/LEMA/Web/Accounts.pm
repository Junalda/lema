package LEMA::Web::Accounts;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

our $SINGLETON;

sub _main_template { '/accounts/main.tmpl' }

sub singleton : lvalue { our $SINGLETON }

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->account->query;
    } catch {
        die $_;
    };

    $self->cache_set_all(\@items);
    return \@items;
    ()
}

sub cache_get {
    my $self = shift;
    $self->fetch_all;
    return $self->SUPER::cache_get;
}

sub main {
    my ($self, $httpd, $req) = @_;
    my %vars = $req->vars;

    delete $vars{search};
    $vars{limit} = 100 if $vars{limit} <= 0;

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;

        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/accounts(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
