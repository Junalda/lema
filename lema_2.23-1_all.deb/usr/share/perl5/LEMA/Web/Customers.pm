package LEMA::Web::Customers;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use Digest::CRC qw(crc32);
use parent qw(LEMA::Web::base LEMA::Web::cache2 LEMA::Web::contragent);
use ACME::E;

sub _main_template { '/customers/main.tmpl' }
sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    $self->cache;
    ()
}

=head1
sub _validate_query {
    my ($self, $query) = @_;

    my %supported;
    @supported{qw(limit page source sort order available_max available_min
                  from_date to_date disable_cache)} = undef;

    for (keys %$query) {
        delete $query->{$_} unless exists $supported{$_};
    }

    $query->{limit}   = int $query->{limit};
    $query->{limit}   = 10 if $query->{limit} <= 0 || $query->{limit} > 500;
    $query->{page}    = int $query->{page};
    $query->{page}    = 1 if $query->{page} <= 0;
    $query->{order}   = 'desc'
        unless $query->{order} =~ /^(desc|asc)$/;

    for (qw(available_min available_max)) {
        if (length $query->{$_}) {
            if ($query->{$_} =~ /^\d+$/) {
                $query->{$_} = int $query->{$_};
                $query->{$_} = 0x7FFFFFFF
                    unless $query->{$_} <= 0x7FFFFFFF;
            }
            else {
                $query->{$_} = undef;
            }
        } else {
            $query->{$_} = undef;
        }
    }




    ()
}
=cut

sub fetch {
    my ($self, $id) = @_;
    my $obj = $self->app->qbo->customer->query_by_id($id);
    $self->app->db->agents->populate($obj);
    $self->cache_set($obj);
    return $obj;
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->customer->query;
    } catch {
        die $_;
    };

    for (@items) {
        $self->app->db->agents->populate($_);
    }

    $self->cache_set_all(\@items);
    return \@items;
}


=head1
sub query {
    my ($self, $query, $ptotal) = @_;
    $self->_validate_query($query);

    $self->fetch_all unless $self->cache_size;

    my $aref = $self->cache_get;
    my @sorted;
    my $func;

    if ($query->{sort} eq 'feerate_change') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->{feerate_change} <=> $a->{feerate_change}
            };
        } else {
            $func = sub {
                $a->{feerate_change} <=> $b->{feerate_change}
            };
        }
    } elsif ($query->{sort} eq 'closing_available') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->{closing_available} <=> $a->{closing_available}
            };
        } else {
            $func = sub {
                $a->{closing_available} <=> $b->{closing_available}
            };
        }
    }
    else {
        $func = sub { };
    }

    my $total = 0;
    my $limit = $query->{limit};
    my $skip  = ($query->{page} - 1) * $query->{limit};

    for (sort $func @$aref) {
        if (defined $query->{available_min}) {
            next unless $_->{closing_available} >= $query->{available_min};
        }
        if (defined $query->{available_max}) {
            next unless $_->{closing_available} <= $query->{available_max};
        }

        $skip--;
        if ($skip < 0 && @sorted < $limit) {
            push @sorted, $_;
        }

        $total++;
    }

    $$ptotal = $total if ref $ptotal eq 'SCALAR';
    return \@sorted;
}
=cut

=head1
sub main {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my $started = AE::time;
    my %vars    = $req->vars;
    my $is_json = delete $vars{is_json};
    my $resp    = $req->response
                      ->template('/customers/main.tmpl')
                      ->reply(version => $LEMA::VERSION);

    unless ($is_json == 1 || $is_json eq 'true') {
        $self->_validate_query(\%vars);

        my %copy = %vars;
        delete $copy{page};
        delete $copy{limit};

        my $url = new URI;
        $url->query_form(%copy);

        $vars{is_json} = boolean::false;

        $resp->success(1)
             ->json(0)
             ->reply(query_string => $url->query,
                     query        => \%vars);

        $req->finish_response;
        return 1;
    }

    my $total;
    my $res;
    my %perf = (timing    => undef,
                cache_key => undef);




    my $total;
    my $res = $self->query(\%vars, \$total);

    $resp->success(1)
         ->json(1)
         ->reply(customers => $res,
                 total     => $total,
                 query     => \%vars,
                 perf      => \%perf);

    $req->finish_response;
    1
}
=cut

sub show_insert_form {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/customers/new.tmpl');
    $resp->success(1);
    $req->finish_response;
    1
}

sub insert {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);

    die "Display Name must be defined\n"
        unless length $vars->{DisplayName};

    my $addresses = delete $vars->{addresses};
    my $eori      = delete $vars->{eori};
    my $customer  = QuickBooks::Objects::Customer->new_mod($vars);
    my $agent     = $self->app->db->agents->build($addresses, undef, $eori);
    my $customer  = $self->app->qbo->customer->create($customer);

    $self->app->db->agents->bind($customer => $agent);
    $self->cache_set($customer);

    $resp->reply(customer => $customer)->success(1);
    $req->finish_response;
    1
}

sub view {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'GET';

    my %vars     = $req->vars;
    my $resp     = $req->response->template('/customers/view.tmpl');
    my $customer = $self->cache_find_strict($id);

    $resp->reply(customer => $customer)->success(1);
    $req->finish_response;
    1
}

sub update {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);

    my $addresses = delete $vars->{addresses};
    my $eori      = delete $vars->{eori};
    my $customer  = QuickBooks::Objects::Customer->new_mod($vars);
    my $agent     = $self->app->db->agents->build($addresses, undef, $eori);
    my $customer  = $self->app->qbo->customer->update($customer);

    $self->app->db->agents->bind($customer => $agent);
    $self->cache_set($customer);

    $resp->reply(customer => $customer)->success(1);
    $req->finish_response;
    1
}

sub build_array {
    my ($self, $invoice) = @_;
    my ($customer_id, $customer_sub);
    if ($invoice) {
        die "Invalid invoice object: $invoice"
            unless $invoice->$_isa('LEMA::Object::Invoice');
        $customer_id = $invoice->CustomerRef->value;
        if ($invoice->properties) {
            $customer_sub = $invoice->properties->doc_sub // undef;
        }
    }

    my $cache = $self->cache;
    my @suppliers;
    for (sort { $a <=> $b } keys %$cache) {
        my $h = $cache->{$_};
        my $country;
        if ($h->billing_country || $h->shipping_country) {
            $country = sprintf "%s/%s",
                               $h->billing_country, $h->shipping_country;
        }

        my $basename = sprintf(length $country ? "%s (%s)" : "%s",
                            $h->DisplayName, $country);

        my $emails = $h->PrimaryEmailAddr
                   ? $h->PrimaryEmailAddr->Address
                   : undef;

        my %hash = (
            id         => $h->Id,
            label      => $basename,
            selected   => undef,
            vat_number => $h->PrimaryTaxIdentifier,
            eori       => undef,
            emails     => $emails,
        );

        if (my $ship_addr = $h->ShipAddr) {
            $hash{country}     = $ship_addr->Country;
            $hash{address}     = $ship_addr->address_lines_fmt;
            $hash{city}        = $ship_addr->City;
            $hash{state}       = $ship_addr->CountrySubDivisionCode;
            $hash{postal_code} = $ship_addr->PostalCode;
        }

        if ($customer_id && !$customer_sub) {
            $hash{selected} = 1 if $customer_id == $h->Id;
        }
        push @suppliers, \%hash;

        next unless $h->{reserved} && $h->{reserved}{agent};

        my $agent = $h->{reserved}{agent};
        $hash{eori} = $agent->eori;

        next unless $agent->addresses->count;

        my $selected = $customer_id ? $customer_id == $h->Id : 0;

        my $found_sub_addr = $customer_sub ? 0 : undef;
        $agent->addresses->enum(sub {
            my $addr = shift;
            my %copy = %hash;
            my $idx  = crc32($addr->{reserved}{name});
            $copy{label} = $basename . ': Location: ' . $addr->{reserved}{name};

            $copy{country}     = $addr->Country;
            $copy{address}     = $addr->address_lines_fmt;
            $copy{city}        = $addr->City;
            $copy{state}       = $addr->CountrySubDivisionCode;
            $copy{postal_code} = $addr->PostalCode;
            $copy{id}          = $copy{id} . '.' . $idx;

            if ($selected && $customer_sub && $customer_sub == $idx) {
                $copy{selected} = 1;
            } else {
                $copy{selected} = 0;
            }

            push @suppliers, \%copy;
        });

        if (defined $found_sub_addr && $found_sub_addr == 0) {
            $hash{selected} = 1 if $customer_id == $h->Id;
        }

    }
    @suppliers = sort { $a->{label} cmp $b->{label} } @suppliers;
    return \@suppliers;
}

sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Last Screen app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;

        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/(\d+)(\?|$)!) {
            $ok = $self->view($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/(\d+)(\?|$)!) {
            $ok = $self->update($httpd, $req, $1);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/customers/new(\?|$)!) {
            $ok = $self->show_insert_form($httpd, $req);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/customers/new(\?|$)!) {
            $ok = $self->insert($httpd, $req);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
