package LEMA::Web::cache_with_product;
use common::sense;
use boolean;
use Safe::Isa;
use Try::Tiny;
use Data::Dumper;
use parent qw(LEMA::Web::cache2);

our %PRODUCTS;

sub products {
    my $self = shift;
    return \%PRODUCTS;
}

sub get_products_by_qbo_id {
    my $qbo_id = pop;
    die "Invalid QBO product ID" unless $qbo_id > 0;
    my @res;
    for (values %PRODUCTS) {
        next unless $_->{value} == $qbo_id;
        push @res, $_;
    }

    return @res ? \@res : undef;
}

sub cache_remove {
    my ($self, $id) = @_;
    my $product_list;
    my $obj = $self->cache_find($id);

    my $mod = 0;
    $mod = -1 if $obj->$_isa('LEMA::Object::Invoice') && !defined $obj->error;
    $mod =  1 if $obj->$_isa('LEMA::Object::Bill')    && !defined $obj->error;


    if ($mod) {


        my $list = $obj->prepare_product_list($self->products, -revert => 1);
        for (@$list) {
            $_->{txn_count}--;
        }
    }

    return $self->SUPER::cache_remove($id);
}

sub cache_set {
    my ($self, $obj) = @_;

    my $id = $obj->Id;
    $self->cache_remove($obj->Id);

    my $mod = 0;
    $mod = -1 if $obj->$_isa('LEMA::Object::Invoice') && !defined $obj->error;
    $mod =  1 if $obj->$_isa('LEMA::Object::Bill')    && !defined $obj->error;

    if ($mod) {
        my $href = $obj->item_id_qty_href;

        my $list = $obj->prepare_product_list($self->products);

        for (@$list) {
            $_->{txn_count}++;
        }
    }

    $self->SUPER::cache_set($obj);
    ()
}

1;
