package LEMA::Web::SuppliersOrders;
use common::sense;
use boolean;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use ACME::Data;
use Tie::IxHash;
use File::Temp;
use LEMA::Util::PDF;
use LEMA::DB::Stockflow;
use LEMA::Object::ItemRef;
use LEMA::Object::Bill;
use parent qw(LEMA::Web::base
              LEMA::Web::cache_with_product
              LEMA::Web::contragent
              LEMA::Web::last_recipients
              LEMA::Web::mindoc);
use ACME::E;

sub singleton : lvalue { our $SINGLETON }

sub initialize_local_db {
    my $self = shift;
    $self->fetch_all;
    $self->cache;
    ()
}

sub _allowed_sort {
    qr{^(DocNumber|CreationDate|DepartureDate|TxnDate|SupplierDisplayName)$};
}

sub _main_filter {
    return 0 if defined $_[1]->error;
    return 0 unless $_[1]->DocNumber =~ /^\d{4}-\d{4}$/;

    if (length $_[3] && $_[3] =~ /^docnumber\:(\S+)$/) {
        return 1 if $_[1]->DocNumber eq $1;
    }
    return 1 unless defined $_[2];

    return 1 if $_[1]->DocNumber =~ $_[2];

    return 1 if $_[1]->txndate_fmt   =~ $_[2];


    if ($_[1]->properties) {
        return 1 if $_[1]->properties->creation_date_fmt =~ $_[2];
        return 1 if $_[1]->properties->departure_date_fmt =~ $_[2];

    }

    my $vendor_ref = $_[1]->VendorRef;
    if ($vendor_ref) {
        return 1 if $vendor_ref->name =~ $_[2];
    }

    return 0;
}

sub query {
    my ($self, $query, $ptotal) = @_;
    my $all = $self->SUPER::query($query, $ptotal);

    for my $po (@$all) {
    }
    return $all;
}

sub get_lot_by_txn_id {
    my ($self, $id) = @_;
    return undef unless $id > 0;
    my $po = $self->cache_find($id);
    return undef unless $po;
    my $lot = $po->DocNumber;
    return undef unless $lot =~ /^\d{4}-\d{4}$/;
    return $lot;
}

sub main {
    my ($self, $httpd, $req, $is_inbound) = @_;
    my %vars = $req->vars;

    if (delete($vars{submit}) =~ /reset/i) {
        delete $vars{search};
        delete $vars{limit};
        delete $vars{sort};
        delete $vars{order};
    }

    $vars{sort}  = "DocNumber" unless length $vars{sort};
    $vars{order} = "desc"      unless length $vars{order};

    local *_main_template = sub {
        $is_inbound ? '/suppliers-orders/inbound.tmpl'
                    : '/suppliers-orders/main.tmpl'
    };

    local *_filter = !$is_inbound
                   ? \&_main_filter
                   : sub {
        my $ret  = $_[0]->_main_filter($_[1], $_[2], $_[3]);
        return 0 unless $ret;
        return 0 if defined $_[1]->error;
        return 1;
    };

    return $self->SUPER::main($httpd, $req, \%vars);
}

sub fetch {
    my ($self, $id) = @_;
    my $obj = $self->app->qbo->bill->query_by_id($id);

    LEMA::Object::Bill->extend($obj);
    unless (length $obj->error) {
        $self->app->db->properties->populate_bill($obj);
    }

    $self->cache_set($obj);
    return $obj;
}

sub fetch_all {
    my $self = shift;
    my @items;
    try {
        @items = $self->app->qbo->bill->query;
    } catch {
        die $_;
    };

    for (@items) {
        LEMA::Object::Bill->extend($_);
        unless (length $_->error) {
            $self->app->db->properties->populate_bill($_);
        }
    }

    $self->cache_set_all(\@items);
    return \@items;
}

sub show_new_form {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'GET';
    my $resp     = $req->response->template('/suppliers-orders/details.tmpl');
    my $products = LEMA::Web::Products->singleton->existing_products;
    my $txn_date = ACME::Data::local_yyyymmdd;
    my $vat_rates = LEMA::Web::Tax->singleton->build_array(undef, -purchase_only => 1, -active_only => 1);
    my $doc_num  = $self->_get_next_docnumber($txn_date);


    $resp->reply(
        suppliers      => LEMA::Web::Suppliers->singleton->build_array,
        vat_rates      => $vat_rates,
        purchase_order => { TxnDate => $txn_date, DocNumber => $doc_num, properties => { creation_date => $txn_date } },
        products       => $products,
        terms          => LEMA::Web::Term->singleton->existing_terms,
    );

    $req->finish_response;
    1
}

sub _vars_to_obj {
    my ($self, $vars) = @_;
    my $products = LEMA::Web::Products->singleton;
    die "No supplier selected\n"
        unless ref $vars->{VendorRef} eq 'HASH' &&
               $vars->{VendorRef}{value} =~ /^(\d+)(\.(\d+))?$/;
    $vars->{VendorRef}{value} = int $vars->{VendorRef}{value};

    die "No order date\n"
        unless length $vars->{creation_date};
    die "No arrival date\n"
         unless length $vars->{TxnDate};
    die "No order number\n"
        unless length $vars->{DocNumber};
    die "Invalid order number\n"
        if ref $vars->{DocNumber};
    die "Order number is not in format of YYYY-NNNN\n"
        unless $vars->{DocNumber} =~ /^\d{4}-\d{4}$/;
    die "No sales terms\n"
        unless $vars->{SalesTermRef}{value} > 0;
    die "No due date\n"
        unless length $vars->{DueDate};

    my $inventory = $self->app->db->settings->active_profile->inventory;
    unless ($inventory) {
        die "Accounts for inventory products (WD) are not defined. " .
            "Please set them in the Settings.\n";
    }
    my $dd_inventory = $self->app->db->settings->active_profile->dd_inventory;
    unless ($dd_inventory) {
        die "Accounts for inventory products (DD) are not defined. " .
            "Please set them in the Settings.\n";
    }

    my $line = $vars->{Line};
    die "No products\n" unless @$line;

    tie my %txn_line_detail, 'Tie::IxHash';
    my $net_amount_total = 0;
    my $lineno = 0;

    my @product_names;
    my @extra_line;
    for my $detail (@$line) {
        $lineno++;

        my $expense = $detail->{ItemBasedExpenseLineDetail};
        $expense->{UnitPrice} = ACME::Data::adjust_amount($expense->{UnitPrice});
        $expense->{Qty}       = ACME::Data::adjust_int($expense->{Qty});

        die "No details for the product"
            unless ref $expense eq 'HASH' && $expense->{ItemRef};

        my $item_ref = delete $expense->{ItemRef};

        $detail->{Description} = $products->_row_to_product_description($item_ref);

        my $name =
                    $item_ref->{name};


        push @product_names, QuickBooks::Objects::ItemRef->new({
                value => 1,
                name  => $name,
                lot   => undef,
        });
        $product_names[-1]{_for_stock} ||=
            defined $detail->{Description} ? 1 : 0;

        if ($name =~ /(^|\s)Claims?\s*(DD|WD|DFS)$/i ||
            $name =~ /^(DD|WD|DFS)\s*Claims?($|\s)/) {
            $product_names[-1]{_for_stock} = 0;
        }

        die "Quantity is not defined\n" unless length $expense->{Qty};
        die "Product price is not defined\n" unless length $expense->{UnitPrice};
        $expense->{Qty} += 0.0;
        die "Quantity must be greater than 0\n"
            unless $expense->{Qty} > 0;
        $expense->{UnitPrice} += 0.0;

        $expense->{ItemRef}   = $product_names[-1];

        $detail->{DetailType} = 'ItemBasedExpenseLineDetail',
        $detail->{Amount}     = sprintf "%.2f",
                                        $expense->{Qty} * $expense->{UnitPrice};

        my $tax_tripple = $item_ref->{tax}{tripple};
        delete $item_ref->{tax};
        if ($tax_tripple =~ /^(\d*)\.(\d*)\.(\S+)$/) {
            my ($tax_rate_id, $tax_code_id, $tax_percent) = ($1, $2, $3);
            if (length $tax_code_id) {
                my $v = $txn_line_detail{$tax_tripple} ||= +{
                    tax_percent => $tax_percent,
                    tax_rate_id => $tax_rate_id,
                    tax_code_id => $tax_code_id,
                    net_amount_total => 0,
                };

                $expense->{TaxCodeRef} = { value => $tax_code_id };#, name => '9.0% S' };
                use bigint;
                $v->{net_amount_total} += $detail->{Amount};
            }
        }
        else {
            die "VAT is not defined on product line no. ", $lineno, "\n";
        }

        $net_amount_total += $detail->{Amount};

        my $account_id = !!($item_ref->{name} =~ /\sDFS$/i || $item_ref->{name} =~ /^DFS\s/i || $item_ref->{name} =~ /^DD\:/i)
                       ? $dd_inventory->expense_account
                       : $inventory->expense_account;

        if ($product_names[-1]{_for_stock} && !@extra_line) {
            push @extra_line, {
              'LinkedTxn' => [],
              'Amount' => 0,
              'AccountBasedExpenseLineDetail' => {
                                                   'BillableStatus' => 'NotBillable',
                                                   'TaxCodeRef' => $expense->{TaxCodeRef},
                                                   'AccountRef' => {
                                                                     'value' => $account_id,
                                                                   }
                                                 },
              'Id' => '3',
              'DetailType' => 'AccountBasedExpenseLineDetail'
            };
        } elsif (0) {
            push @extra_line, {
              'LinkedTxn' => [],
              'Amount' => 0.00,
              'AccountBasedExpenseLineDetail' => undef,
              'Id' => '3',
              'DetailType' => 'AccountBasedExpenseLineDetail'
            };
        }
    }

    for (@extra_line) {
    }

    my $tax_amount_total = 0;
    if (%txn_line_detail) {
        $vars->{TxnTaxDetail} = { TotalTax => undef, TaxLine => [] };

        for my $tripple (keys %txn_line_detail) {
            my $v = $txn_line_detail{$tripple};

            my $total_tax = sprintf("%.2f",  ($v->{net_amount_total} *
                                             $v->{tax_percent}) / 100);

            push @{$vars->{TxnTaxDetail}{TaxLine}}, {
                    Amount     => $total_tax,
                    DetailType => 'TaxLineDetail',
                    TaxLineDetail  => {
                        TaxRateRef => {
                            value => $v->{tax_rate_id},
                        },
                        PercentBased     => 1,
                        TaxPercent       => $v->{tax_percent},
                        NetAmountTaxable => $v->{net_amount_total},
                    },
            };

            $vars->{TxnTaxDetail}{TotalTax} += $total_tax;
            $tax_amount_total += $total_tax;
        }
    }



    my $dfs_state = 0;
    for (@product_names) {
        next unless $_->{_for_stock};
        if ($_->name =~ /\sDFS$/i || $_->name =~ /^DFS\s/i || $_->name =~ /^DD\:/i) {
            $dfs_state |= 0b01;
        } else {
            $dfs_state |= 0b10;
        }
    }

    die "SMAPP needs at least one inventory product in this transaction\n"
        unless $dfs_state;
    die "SMAPP needs all inventory products to be of the same kind " .
        "(you have DFS and not DFS together)\n"
        if $dfs_state == 0b11;

    $products->populate_items_value(\@product_names, -die_if_not_found => 0);

    my $po = QuickBooks::Objects::Bill->new($vars);
    $po->GlobalTaxCalculation('TaxExcluded');
    LEMA::Object::Bill->extend($po);



    die "Couldn't prepare extended purchase order object: " . $po->error
        if defined $po->error;

    return $po;
}

sub insert {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';
    my $resp = $req->response->json(1);
    my $vars = $req->same_vars_struct;

    my $po = $self->cache_find_by_doc_number($vars->{DocNumber});
    if ($po) {
        die "Document number $vars->{DocNumber} is already in use\n";
    }

    my %props = (
        creation_date => $vars->{creation_date},
        departure_date => $vars->{departure_date},
        arrival_date   => $vars->{arrival_date},
        vat_number     => $vars->{vat_number},
        remarks        => $vars->{remarks},
        sale_cond      => $vars->{sale_cond},
        bank_account   => $vars->{bank_account},
        extra_addr     => $vars->{extra_addr},
        euro_pallets   => $vars->{euro_pallets},
        block_pallets  => $vars->{block_pallets},
        recipients_e   => $vars->{recipients_e},
        recipients_u   => $vars->{recipients_u},
    );
    $props{status} = LEMA::DB::Properties::Doc::ORDER_ISSUED;

    my $customer_val = $vars->{VendorRef}{value};
    if ($customer_val =~ /^(\d+)(\.(\d+))?$/ && $3 > 0) {
        $props{doc_sub} = $3;
    }


    my $po = $self->_vars_to_obj($vars);

    my $po = $self->app->qbo->bill->create($po->root);
    LEMA::Object::Bill->extend($po);
    $self->cache_set($po);
    $self->app->db->properties->upsert_bill($po, %props);
    $self->app->db->properties->populate_bill($po);

    my $bin = $self->_generate_pdf($po->Id,  -local => 1, -type => 'po');
    my $bin2 = $self->_generate_pdf($po->Id, -local => 1, -type => 'bill');
    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_bill(
        $po,
        { list => [
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'PURCHASE-ORDER-' . $po->DocNumber, },
          ]
        },
    );

    $self->app->db->notifications->insert($notification);
    $resp->reply(purchase_order => $po);
    $resp->reply(action         => $notification->as_action);
    $resp->success(1);
    $req->finish_response;
    1
}

sub view {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'GET';

    my %vars = $req->vars;
    my $resp = $req->response->template('/suppliers-orders/details.tmpl')
                             ->reply(version => $LEMA::VERSION);

    my $po   = $self->cache_find_strict($id);

    if ($po->error) {
        die "Purchase order is not for SMAPP: ", $po->error, "\n";
    }

    my $suppliers = LEMA::Web::Suppliers
                        ->singleton
                        ->build_array($po);#$po->VendorRef->value);

    my $products  = LEMA::Web::Products->singleton->existing_products;


    my $notifications = $self->app->db->notifications
                                      ->find_by_purchase_order($po, -without_octets => 1);



    my $vat_rates_all = LEMA::Web::Tax->singleton->build_array;
    $po->populate_vat_on_lines($vat_rates_all);
    my $vat_rates = LEMA::Web::Tax->singleton->build_array(undef, -purchase_only => 1, -active_only => 1);

    $resp->reply(
        purchase_order => $po,
        vat_rates => $vat_rates,
        suppliers      => $suppliers,
        products       => $products,
        notifications  => $notifications,
        terms          => LEMA::Web::Term->singleton->existing_terms,
    );
    $resp->success(1);
    $req->finish_response;
    1
}

sub update {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);
    my $po   = $self->app->qbo->bill->query_by_id($id);
    LEMA::Object::Bill->extend($po);
    die "Bill is not controlled by LEMA SMAPP\n" if length $po->error;

    my %props = (
        creation_date  => $vars->{creation_date},
        departure_date => $vars->{departure_date},
        arrival_date   => $vars->{arrival_date},
        sale_cond      => $vars->{sale_cond},
        vat_number     => $vars->{vat_number},
        remarks        => $vars->{remarks},
        bank_account   => $vars->{bank_account},
        extra_addr     => $vars->{extra_addr},
        euro_pallets   => $vars->{euro_pallets},
        block_pallets  => $vars->{block_pallets},
        recipients_e   => $vars->{recipients_e},
        recipients_u   => $vars->{recipients_u},
    );



    my $customer_val = $vars->{VendorRef}{value};
    if ($customer_val =~ /^(\d+)(\.(\d+))?$/ && $3 > 0) {
        $props{doc_sub} = $3;
    }

    $vars->{Id} = $id;
    $vars->{APAccountRef} = $po->APAccountRef;

    my $po = $self->_vars_to_obj($vars);

    $self->app->db->properties->upsert_bill($po, %props);

    my $po = $self->app->qbo->bill->update($po->root);
    LEMA::Object::Bill->extend($po);
    $self->app->db->properties->populate_bill($po);

    my $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'po');
    my $bin2 = $self->_generate_pdf($po->Id, -local => 1, -type => 'bill');
    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_bill(
        $po,
        { list => [
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'PURCHASE-ORDER-' . $po->DocNumber, },
          ]
        },
    );


    $self->cache_set($po);

    $self->app->db->notifications->insert($notification);
    $resp->reply(purchase_order => $po);
    $resp->reply(action         => $notification->as_action);
    $resp->success(1);
    $req->finish_response;
    1
}

sub remove {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $resp = $req->response->json(1);
    die "No purchase order ID" unless length $id;

    my $po = $self->app->qbo->bill->query_by_id($id);
    if ($po) {
        LEMA::Object::Bill->extend($po);
        unless (defined $po->error) {


            $self->app->qbo->bill->delete_by_id($id);
        }
        else {
            my $po = $self->app->qbo->bill->delete_by_id($id);
        }
    }

    $self->cache_remove($id);

    $resp->success(1);
    $req->finish_response;
    1
}

sub properties {
    my ($self, $httpd, $req, $id) = @_;
    return 0 if $req->method ne 'POST';

    my $vars = $req->same_vars_struct;
    my $resp = $req->response->json(1);
    die "No invoice ID" unless length $id;

    my $po = $self->app->qbo->bill->query_by_id($id);
    LEMA::Object::Bill->extend($po);
    die "Bill is not controlled by LEMA SMAPP\n"
        if length $po->error;

    $self->app->db->properties->populate_bill($po);


    my %props      = %$vars;
    my $properties = $self->app->db->properties->create($po, %props);
    $po->properties($properties);

    my @list;
    if ($properties->status == LEMA::DB::Properties::Doc::ORDER_ISSUED) {
        my $bin  = $self->_generate_pdf($po->Id, -local => 1, -type => 'po');
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'PURCHASE-ORDER-' . $po->DocNumber, },
        );
    }
    elsif ($properties->status == LEMA::DB::Properties::Doc::ORDER_DEPARTED) {
        my $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'inbound');
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'INBOUND-ORDER-' . $po->DocNumber, },
        );
    }
    elsif ($properties->status == LEMA::DB::Properties::Doc::ORDER_ARRIVED) {
        my $bin = $self->_generate_pdf($po->Id, -local => 1, -type => 'inbound');
        @list = (
            { octets  => $bin,
              is_utf8 => 0,
              type    => 'application/pdf',
              name    => 'INBOUND-ORDER-' . $po->DocNumber, },
        );
    }

    $self->app->db->properties->upsert($properties);

    my $notification = $self->app->db
                                 ->notifications
                                 ->create_notification_from_bill(
        $po,
        { list => \@list },
    );

    $self->cache_set($po);
    $self->app->db->notifications->insert($notification);

    $resp->reply(status => $po->properties->status,
                 action => $notification->as_action);
    $resp->success(1);
    $req->finish_response;
    1
}



sub _generate_html {
    my ($self, $id, %args) = @_;
    die "No purchase order ID" unless length $id;
    die "Invalid document file type: $args{-type}\n"
        unless $args{-type} =~ /^(po|bill|inbound)$/;

    my $po = $self->app->qbo->bill->query_by_id($id);
    LEMA::Object::Bill->extend($po);
    die "Purchase Order is not controlled by LEMA SMAPP: " . $po->error . "\n"
        if length $po->error;

    $self->app->db->properties->populate_bill($po);

    my $vendor = $self->app->qbo->vendor->query_by_id($po->VendorRef->value);

    my $tmpl = LEMA::Template::Static->new(TRIM => 1, NOXSS => 1);
    my %vars = (
        reply => { purchase_order => $po, supplier => $vendor },
    );

    if ($args{-local}) {
        $vars{local_fs}  = LEMA::Static::html5_fs_full_path;
        $vars{local_fs} .= "/" unless $vars{local_fs} =~ m!/$!;
    }

    if (LEMA::Logging::is_debug) {
        $vars{debug} = { data => LEMA::HTTPD::Extended::Response::__json_coder
                                        ->pretty(1)->encode(\%vars) };
    }

    my $tmpl_path = "/suppliers-orders/print.tmpl";
    if ($args{-type} eq 'inbound') {
        $tmpl_path = "/suppliers-orders/print-inbound.tmpl";
    }
    elsif ($args{-type} eq 'bill') {
        $tmpl_path = "/suppliers-orders/print-bill.tmpl";
    }

    $tmpl->process_static($tmpl_path, \%vars, \ my $bin);

    $tmpl->process_static($tmpl_path, \%vars, \ my $bin);

    if (utf8::is_utf8 $bin) {
        utf8::encode $bin;
    }

    if ($args{-local}) {
        $bin =~ s!/lema/v1/!!g;
    }

    return ($po, $bin);
}

sub _generate_pdf {
    my ($self, $id, %args) = @_;

    my ($po, $html) = $self->_generate_html($id, -local => 1,
                                                 -type  => $args{-type});

    my $pdf_bin = LEMA::Util::PDF::generate($html);
    return ($po, $pdf_bin);
}


=head1
sub _generate_html_TO_DELETE {
    my ($self, $id, %args) = @_;

    die "No order ID\n" unless length $id;
    my $po = $self->app->qbo->bill->query_by_id($id);
    LEMA::Object::Bill->extend($po);
    die sprintf "Order is not controlled by LEMA SMAPP: %s\n", $po->error
        if length $po->error;



    $self->app->db->properties->populate_purchase_order($po);

    my $vendor = $self->app->qbo->vendor->query_by_id($po->VendorRef->value);

    my $tmpl = LEMA::Template::Static->new(TRIM => 1, NOXSS => 1);
    my %vars = (
        reply => { purchase_order => $po, supplier => $vendor },
    );
    if ($args{-local}) {
        $vars{local_fs}  = LEMA::Static::html5_fs_full_path;
        $vars{local_fs} .= "/" unless $vars{local_fs} =~ m!/$!;
    }

    if (LEMA::Logging::is_debug) {
        $vars{debug} = { data => LEMA::HTTPD::Extended::Response::__json_coder
                                        ->pretty(1)->encode(\%vars) };
    }

    my $tmpl_path = "/suppliers-orders/print.tmpl";
    if ($args{-inbound}) {
        $tmpl_path = "/suppliers-orders/print-inbound.tmpl";
    }
    $tmpl->process_static($tmpl_path, \%vars, \ my $bin);

    if (utf8::is_utf8 $bin) {
        utf8::encode $bin;
    }

    if ($args{-local}) {
        $bin =~ s!/lema/v1/!!g;
    }

    return ($po, $bin);
}
=cut

sub html {
    my ($self, $httpd, $req, $id, $type) = @_;
    return 0 if $req->method ne 'GET';
    my ($po, $html) = $self->_generate_html($id, -local => 0,
                                                 -type  => $type);
    $req->respond([ 200 => "OK", { 'Content-Type' => "text/html" }, $html ]);
    $req->finish_response;
    1
}


=head1
sub pdf {
    my ($self, $httpd, $req, $id, $is_inbound) = @_;
    return 0 if $req->method ne 'GET';
    my ($po, $html) = $self->_generate_html($id, -local   => 1,
                                                 -inbound => !!$is_inbound);

    my $html_fh = File::Temp->new(UNLINK => 1, SUFFIX => '.html');
    binmode $html_fh;
    print $html_fh $html;
    $html_fh->flush;
    my $html_path = "$html_fh";

    my $pdf_fh   = File::Temp->new(UNLINK => 1, SUFFIX => '.pdf');
    my $pdf_path = "$pdf_fh";

    system("wkhtmltopdf", "--page-size", "A4", $html_path, $pdf_path);

    open my $fh, '<', $pdf_path or die "PDF file is not found: $!\n";
    binmode $fh;
    my $pdf_bin = do { local $/ = undef; <$fh> };
    close $fh;

    close $pdf_fh;
    close $html_fh;

    my $filename = sprintf "%s-%s.pdf",
                           $is_inbound ? 'INBOUND' : 'PO', $po->DocNumber;

    $req->respond([ 200 => "OK", {
        'SC-Trace-Log' => 0,
        'Content-Type' => "application/pdf",
        'Content-Disposition' => qq{attachment; filename="$filename"} },
        $pdf_bin ]);

    $req->finish_response;
    1
}
=cut

sub pdf {
    my ($self, $httpd, $req, $id, $type) = @_;
    return 0 if $req->method ne 'GET';

    my ($po, $pdf_bin) = $self->_generate_pdf($id, -type => $type);

    my $prefix;
    if    ($type eq 'po')      { $prefix = "PURCHASE-ORDER" }
    elsif ($type eq 'inbound') { $prefix = "INBOUND" }
    elsif ($type eq 'bill')    { $prefix = "BILL" }
    else {
        die "Invalid document file type";
    }

    my $filename = sprintf "%s-%s.pdf", $prefix, $po->DocNumber;

    $req->respond([ 200 => "OK", {
        'SC-Trace-Log' => 0,
        'Content-Type' => "application/pdf",
        'Content-Disposition' => qq{attachment; filename="$filename"} },
        $pdf_bin ]);

    $req->finish_response;
    1
}



sub app_cb {
    my $self = shift;
    return sub {
        my ($httpd, $req) = @_;
        AE::log debug => "Supplier Orders app called (%s %s)",
                         $req->method, $req->url;

        $httpd->stop_request;


        my $ok;
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders(\?|$)!) {
            $ok = $self->main($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/new(\?|$)!) {
            $ok = $self->show_new_form($httpd, $req);
        }
        if ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/inbound(\?|$)!) {
            $ok = $self->main($httpd, $req, 'inbound');
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/orders(\?|$)!) {
            $ok = $self->insert($httpd, $req);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)(\?|$)!) {
            $ok = $self->view($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)/delete(\?|$)!) {
            $ok = $self->remove($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)/properties(\?|$)!) {
            $ok = $self->properties($httpd, $req, $1);
        }
        elsif ($req->method eq 'POST' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)(\?|$)!) {
            $ok = $self->update($httpd, $req, $1);
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'po');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/inbound/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'inbound');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/bill/(\d+)/html(\?|$)!) {
            $ok = $self->html($httpd, $req, $1, 'bill');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'po');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/inbound/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'inbound');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/bill/(\d+)/pdf(\?|$)!) {
            $ok = $self->pdf($httpd, $req, $1, 'bill');
        }
        elsif ($req->method eq 'GET' && $req->url =~ m!/lema/v1/suppliers/orders/last-recipients/(\d+)(\.(\d+))?/([ue])(\?|$)!) {
            $ok = $self->last_recipients($httpd, $req, 'supplier', $1, $3, $4);
        }

        $req->respond_404($req) unless $ok;
        ()
    }
}

1;
