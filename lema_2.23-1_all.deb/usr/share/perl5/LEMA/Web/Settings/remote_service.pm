package LEMA::Web::Settings::remote_service;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;
use ACME::Object::Users;

=head1
sub remote_service {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp      = $req->response->json(1);
    my %vars      = $req->vars;
    my $rs_cur    = $self->config->get_remote_service;
    my %cert_req  = (
        O      => delete $vars{'cert_O'},
        OU     => delete $vars{'cert_OU'},
        serial => delete $vars{'cert_serial'},
    );

    if ($rs_cur->cert) {
        $vars{cert} = $rs_cur->cert->cert_b64;
        $vars{key}  = $rs_cur->cert->key_b64;
    }

    my $rs_new = TL::Object::RemoteService->new(\%vars, \%cert_req);

    if ($rs_cur->is_different($rs_new)) {
        AE::log debug => "New config settings for Remote Service provided.";
        if ($rs_new->enabled) {
            my $state = TL::App::start_remote_service($rs_new);
            if ($state > 1) {
                $resp->reply(status => 'restarted');
            } elsif ($state == 1) {
                $resp->reply(status => 'started');
            } else {
                die "Invalid result of remote service start\n";
            }
        } else {
            if (TL::App::stop_remote_service()) {
                $resp->reply(status => 'stopped');
            } else {
                $resp->reply(status => 'not-changed');
            }
        }

        if ($rs_cur->is_different_cert($rs_new->cert)) {
            $resp->reply(cert_status => 'changed');
        } else {
            $resp->reply(cert_status => 'not-changed');
        }

        $self->config->set_remote_service($rs_new);
    } else {
        AE::log debug => "Config settings for Remote Service are not changed.";
        $resp->reply(status => 'not-changed');
    }

    $resp->reply(state => TL::App::get_remote_service_state());

    $resp->success(1);
    $req->finish_response;
    1
}
=cut

sub users {
    my ($self, $httpd, $req) = @_;
    return 0 if $req->method ne 'POST';

    my $resp  = $req->response->json(1);
    my $vars  = $req->same_vars_struct;
    $vars->{users} //= [];

    $self->app->db->settings->active_profile->users->amend_pass($vars->{users});

    my $users = ACME::Object::Users->new(list => $vars->{users});
    my $admin = 1;

    $admin = 0 if $users->count == 0;
    if ($admin) {
        $admin = 0;
        for my $user (@{$users->list}) {
            if ($user->role & $user->ROLE_ADMINISTRATOR) {
                $admin = 1;
                last;
            }
        }
    }

    die "At least one user with Manager role is required\n"
        unless $admin;

    $self->app->db->settings->active_profile->users($users);
    $self->app->db->settings->upsert_active_profile;

    $resp->success(1);
    $req->finish_response;
    1
}

1;
