package LEMA::Web::Settings::base;
use common::sense;
use Carp;
use Data::Dumper;
use Safe::Isa;
use Try::Tiny;

sub new {
    my ($class, %args) = @_;

    die "No config"          unless $args{-config}->$_isa('LEMA::Config');
    die "Invalid app object" unless $args{-app}->$_isa('LEMA::App');

    bless \%args, $class
}

sub config { $_[0]{-config} }
sub app    { $_[0]{-app}    }


1;
