package LEMA::Web::contragent;
use common::sense;
use Data::Dumper;

sub _default_sort { 'DisplayName' }

sub _allowed_sort {
    return qr{^(DisplayName|CurrentBalance|email|person|country)$};
}

sub _filter {
    return 1 unless defined $_[2];
    $_[1]->DisplayName =~ $_[2] ||
    $_[1]->person =~ $_[2]      ||
    $_[1]->email  =~ $_[2]      ||
    $_[1]->phone  =~ $_[2]      ||
    $_[1]->Id     =~ $_[2];
}

sub _validate_query {
    my ($self, $query) = @_;

    my %supported;
    @supported{qw(limit page sort order search Id)} = undef;

    for (keys %$query) {
        delete $query->{$_} unless exists $supported{$_};
    }

    $query->{limit}   = int $query->{limit};
    $query->{limit}   = 100 if $query->{limit} <= 0 || $query->{limit} > 500;
    $query->{page}    = int $query->{page};
    $query->{page}    = 1 if $query->{page} <= 0;
    $query->{sort}    = $self->_default_sort
        unless $query->{sort} =~ $self->_allowed_sort;
    $query->{order}   = 'asc'
        unless $query->{order} =~ /^(desc|asc)$/;

    $query->{search} =~ s/^\s+//;
    $query->{search} =~ s/\s+$//;
    $query->{search} = undef unless length $query->{search};
    ()
}

sub query {
    my ($self, $query, $ptotal) = @_;
    $self->_validate_query($query);


    my $aref = $self->cache_get;
    my @sorted;
    my $func;

    if ($query->{sort} eq 'DisplayName') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->DisplayName // "\x00") cmp lc($a->DisplayName // "\x00")
            };
        } else {
            $func = sub {
                lc($a->DisplayName // "\xFF") cmp lc($b->DisplayName // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'Name') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->Name // "\x00") cmp lc($a->Name // "\x00")
            };
        } else {
            $func = sub {
                lc($a->Name // "\xFF") cmp lc($b->Name // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'Description') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->Description // "\x00") cmp lc($a->Description // "\x00")
            };
        } else {
            $func = sub {
                lc($a->Description // "\xFF") cmp lc($b->Description // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'FullyQualifiedName') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->FullyQualifiedName // "\x00") cmp lc($a->FullyQualifiedName // "\x00")
            };
        } else {
            $func = sub {
                lc($a->FullyQualifiedName // "\xFF") cmp lc($b->FullyQualifiedName // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'name') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->{name} // "\x00") cmp lc($a->{name} // "\x00")
            };
        } else {
            $func = sub {
                lc($a->{name} // "\xFF") cmp lc($b->{name} // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'CurrentBalance') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->CurrentBalance <=> $a->CurrentBalance
            };
        } else {
            $func = sub {
                $a->CurrentBalance <=> $b->CurrentBalance
            };
        }
    } elsif ($query->{sort} eq 'DocNumber') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->DocNumber cmp $a->DocNumber
            };
        } else {
            $func = sub {
                $a->DocNumber cmp $b->DocNumber
            };
        }
    } elsif ($query->{sort} eq 'DepartureDate') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                ($b->properties and $b->properties->departure_date) cmp ($a->properties and $a->properties->departure_date)
            };
        } else {
            $func = sub {
                ($a->properties and $a->properties->departure_date) cmp ($b->properties and $b->properties->departure_date)
            };
        }
    } elsif ($query->{sort} eq 'qty') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->{qty} <=> $a->{qty}
            };
        } else {
            $func = sub {
                $a->{qty} <=> $b->{qty}
            };
        }
    } elsif ($query->{sort} eq 'InventoryQty') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->inventory->Qty <=> $a->inventory->Qty
            };
        } else {
            $func = sub {
                $a->inventory->Qty <=> $b->inventory->Qty
            };
        }
    } elsif ($query->{sort} eq 'RateValue') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                ($b->effective_rate_now // -1) <=> ($a->effective_rate_now // -1)
            };
        } else {
            $func = sub {
                ($a->effective_rate_now // -1 ) <=> ($b->effective_rate_now // -1)
            };
        }
    } elsif ($query->{sort} eq 'TxnDate') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                $b->TxnDate cmp $a->TxnDate
            };
        } else {
            $func = sub {
                $a->TxnDate cmp $b->TxnDate
            };
        }
    } elsif ($query->{sort} eq 'CreationDate') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                ($b->properties and $b->properties->creation_date) cmp ($a->properties and $a->properties->creation_date)
            };
        } else {
            $func = sub {
                ($a->properties and $a->properties->creation_date) cmp ($b->properties and $b->properties->creation_date)
            };
        }
    } elsif ($query->{sort} eq 'CustomerDisplayName') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                ($b->CustomerRef and $b->CustomerRef->name) cmp ($a->CustomerRef and $a->CustomerRef->name)
            };
        } else {
            $func = sub {
                ($a->CustomerRef and $a->CustomerRef->name) cmp ($b->CustomerRef and $b->CustomerRef->name)
            };
        }
    } elsif ($query->{sort} eq 'SupplierDisplayName') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                ($b->VendorRef and $b->VendorRef->name) cmp ($a->VendorRef and $a->VendorRef->name)
            };
        } else {
            $func = sub {
                ($a->VendorRef and $a->VendorRef->name) cmp ($b->VendorRef and $b->VendorRef->name)
            };
        }
    } elsif ($query->{sort} eq 'email') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->email // "\x00") cmp lc($a->email // "\x00")
            };
        } else {
            $func = sub {
                lc($a->email // "\xFF") cmp lc($b->email // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'person') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->person // "\x00") cmp lc($a->person // "\x00")
            };
        } else {
            $func = sub {
                lc($a->person // "\xFF") cmp lc($b->person // "\xFF")
            };
        }
    } elsif ($query->{sort} eq 'country') {
        if ($query->{order} eq 'desc') {
            $func = sub {
                lc($b->country // "\x00") cmp lc($a->country // "\x00")
            };
        } else {
            $func = sub {
                lc($a->country // "\xFF") cmp lc($b->country // "\xFF")
            };
        }
    }
    else {
        $func = sub { };
    }

    my $total = 0;
    my $limit = $query->{limit};
    my $skip  = ($query->{page} - 1) * $query->{limit};
    my $qr    = undef;
    my $id    = undef;

    if ($query->{search} =~ /^id\:(\d+)$/) {
        $id = $1;
    } else {
        $qr = qr{\Q$query->{search}\E}i
            if length $query->{search};
    }

    if (ref $aref eq 'ARRAY') {
        for (sort $func grep {
                my $ret = 1;
                if ($id) {
                    $ret = 0 unless $_->Id == $id;
                }
                    $ret = 0 unless $self->_filter($_, $qr, $query->{search});
                $ret
            } @$aref) {

            $skip--;
            if ($skip < 0 && @sorted < $limit) {
                push @sorted, $_;
            }

            $total++;
        }
    }
    elsif (ref $aref eq 'HASH') {
        for (sort $func grep {
                my $ret = 1;
                if ($id) {
                    $ret = 0 unless $_->Id == $id;
                }
                    $ret = 0 unless $self->_filter($_, $qr, $query->{search});
                $ret
            } values %$aref) {

            $skip--;
            if ($skip < 0 && @sorted < $limit) {
                push @sorted, $_;
            }

            $total++;
        }
    }
    else {
        die "Cache is not available";
    }

    $$ptotal = $total if ref $ptotal eq 'SCALAR';
    return \@sorted;
}

sub _query_hook {
}

sub main {
    my ($self, $httpd, $req, $vars) = @_;
    return 0 if $req->method ne 'GET';

    my $started = AE::time;
    my %vars    = defined $vars ? %$vars : $req->vars;
    my $is_json = delete $vars{is_json};
    my $resp    = $req->response
                      ->template($self->_main_template)
                      ->reply(version => $LEMA::VERSION);

    unless ($is_json =~ /^(1|true)$/i) {
        if ($vars{submit} =~ /reset/i) {
            delete $vars{search};
            delete $vars{limit};
            delete $vars{sort};
            delete $vars{order};
        }

        $self->_validate_query(\%vars);

        my %copy = %vars;
        delete $copy{page};
        delete $copy{limit};

        my $url = URI->new;
        $url->query_form(%copy);

        $vars{is_json} = boolean::false;

        $resp->success(1)
             ->json(0)
             ->reply(query_string => $url->query,
                     query        => \%vars);

        $req->finish_response;
        return 1;
    }

    $resp->json(1)->reply(items => []);

    my %perf = (timing => undef, cache_key => undef);

    my $res = $self->query(\%vars, \ my $total);


    $self->_query_hook($res);

    $resp->success(1)
         ->reply(items => $res,
                 total => $total,
                 query => \%vars,
                 perf  => \%perf);

    $req->finish_response;
    1
}

1;
