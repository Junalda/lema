package Woof;
use strict;
use warnings;
use Carp ();
use Data::Dumper;
use Woof::_Member;
use Woof::_Members;
use Woof::_Validator;
use Woof::_Errors;
use Woof::_Constructor;
use Woof::_Dereference;
use Woof::_Wrapper;
use Woof::_Blesser;

our $VERSION = 0.01;

our $JSON_CODER;

sub FLAG_BUILDING()       { 0x04 }
sub FLAG_INWOOF()         { 0x08 }

sub NOTSET();
sub NOTSET() { \&NOTSET }

sub import {
    my $exporter = shift;
    my ($class)  = caller;

    no strict 'refs';

    my @isa = @{$class . '::ISA'};

    *{$class . '::new'}         = \&Woof::_Constructor::new;
    *{$class . '::WOOF'}        = \&Woof::_Blesser::WOOF;
    *{$class . '::OUTWOOF'}     = \&Woof::_Blesser::OUTWOOF;
    *{$class . '::OUTWOOF_non_recursive'}     = \&Woof::_Blesser::OUTWOOF_non_recursive;
    *{$class . '::TO_JSON'}     = \&Woof::_Blesser::TO_JSON;
    *{$class . '::JSON'}        = \&Woof::_Blesser::JSON;
    *{$class . '::FREEZE'}      = \&Woof::_Blesser::FREEZE;
    *{$class . '::FROM_JSON'}   = \&Woof::_Blesser::FROM_JSON;

    *{$class . '::PUBLIC'}  = \&PUBLIC;
    *{$class . '::PRIVATE'} = \&PRIVATE;
    *{$class . '::CONST'}   = \&CONST;
    *{$class . '::OF'}      = \&OF;
    *{$class . '::DEREF'}   = \&DEREF;
    *{$class . '::UNDEFOK'} = \&UNDEFOK;

    my $members = [];

    for my $isa (@isa) {
        if (exists &{$isa . '::MEMBERS'}) {
            my $pmembers = &{$isa . '::MEMBERS'};

            Carp::croak("No members at your parent `$isa'; maybe you need " .
                        "to use BEGIN { ... } to declare your vars")
                unless @$pmembers;

            for (@$pmembers) {
                my $member = $_->copy;
                push @$members, $member;
            }
        }
    }

    *{$class . '::MEMBERS'}  = sub() { $members };
    *{$class . '::VALIDATE'} = \&Woof::_Validator::validate;
    *{$class . '::BUILDING'} = \&Woof::_Validator::is_building;

    no warnings 'once';
    ${$class . '::ERRORS'} = undef;

    ()
}

sub PUBLIC($;$) : lvalue {
    my ($class) = caller;
    my $member = Woof::_Members::insert($class, @_);
    $member->{public} = 1;

    return $member->{default};
}

sub PRIVATE($;$) : lvalue {
    my ($class) = caller;
    my $member = Woof::_Members::insert($class, @_);
    $member->{private} = 1;

    return $member->{default};
}

sub CONST(;$) {
    my $member = $_[0] || Woof::_Member->new;
    $member->{const} = 1;
    $member
}

sub OF($;$) {
    Carp::croak("Invalid type name")
        unless defined $_[0] && length $_[0] && !ref $_[0];

    my $member = $_[1] || Woof::_Member->new;
    $member->{type} = $_[0];
    $member
}

sub UNDEFOK(;$) {
    my $member = $_[0] || Woof::_Member->new;
    $member->{undefok} = 1;
    $member
}

sub DEREF($;$) {
    my $member = $_[1] || Woof::_Member->new;
    $member->{deref} = defined $_[0] ? !!$_[0] : undef;
    $member
}

sub INWOOF($) {
    goto &Woof::_Dereference::INWOOF;
}

sub json_coder() {
    unless (defined $JSON_CODER) {
        $JSON_CODER = eval { require JSON::XS; JSON::XS->new->utf8 } ||
                       do  { require JSON::PP; JSON::PP->new->utf8 };

        $JSON_CODER->convert_blessed(1);
    }

    return $JSON_CODER;
}

1;
